/**
 * Pure Vanilla JS Animation Controller
 * Handles smooth IntersectionObserver scroll reveals, button click ripples,
 * subtle scroll parallax, and animated counter triggers.
 * Zero external libraries, high performance, respects prefers-reduced-motion.
 */

export function initGlobalAnimations(): () => void {
  // Check if reduced motion is preferred
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // 1. Interactive Button Click Ripple
  const handleRipple = (e: MouseEvent) => {
    const target = (e.target as HTMLElement).closest('.btn-ripple, .btn-shine, .btn-premium, button, a[href^="#"]') as HTMLElement | null;
    if (!target) return;

    // Ensure parent has position relative/overflow hidden
    const rect = target.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    const circle = document.createElement('span');
    circle.classList.add('ripple-circle');
    circle.style.width = `${size}px`;
    circle.style.height = `${size}px`;
    circle.style.left = `${x}px`;
    circle.style.top = `${y}px`;

    // Remove existing ripples if any
    const existing = target.querySelector('.ripple-circle');
    if (existing) existing.remove();

    target.appendChild(circle);

    setTimeout(() => {
      circle.remove();
    }, 600);
  };

  document.addEventListener('click', handleRipple);

  // 2. IntersectionObserver for Scroll Reveals
  let revealObserver: IntersectionObserver | null = null;
  if (!prefersReducedMotion && 'IntersectionObserver' in window) {
    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-revealed');
            // Optional: unobserve once revealed so it doesn't flicker
            revealObserver?.unobserve(entry.target);
          }
        });
      },
      {
        rootMargin: '0px 0px -60px 0px',
        threshold: 0.12,
      }
    );

    const observeElements = () => {
      const elements = document.querySelectorAll('.reveal-on-scroll:not(.is-revealed), .reveal-fade-in:not(.is-revealed)');
      elements.forEach((el) => revealObserver?.observe(el));
    };

    observeElements();

    // Re-check for dynamically rendered elements (like items loaded from API)
    const mutationObserver = new MutationObserver(() => {
      observeElements();
    });

    mutationObserver.observe(document.body, { childList: true, subtree: true });
  } else {
    // If reduced motion is preferred or observer not supported, immediately reveal
    document.querySelectorAll('.reveal-on-scroll, .reveal-fade-in').forEach((el) => {
      el.classList.add('is-revealed');
    });
  }

  // 3. Subtle Parallax Effect on Scroll
  let rafId: number | null = null;
  const handleParallax = () => {
    if (prefersReducedMotion) return;
    
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(() => {
      const scrolled = window.scrollY;
      const parallaxLayers = document.querySelectorAll<HTMLElement>('.parallax-layer');
      parallaxLayers.forEach((layer) => {
        const speed = parseFloat(layer.dataset.parallaxSpeed || '0.15');
        const offset = -(scrolled * speed);
        layer.style.transform = `translate3d(0, ${offset}px, 0)`;
      });
    });
  };

  window.addEventListener('scroll', handleParallax, { passive: true });

  // Cleanup function
  return () => {
    document.removeEventListener('click', handleRipple);
    window.removeEventListener('scroll', handleParallax);
    if (revealObserver) revealObserver.disconnect();
    if (rafId) cancelAnimationFrame(rafId);
  };
}
