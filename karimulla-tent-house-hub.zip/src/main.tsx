import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { LanguageProvider } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import { AdminAuthProvider } from './context/AdminAuthContext';
import { SiteDataProvider } from './context/SiteDataContext';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <ThemeProvider>
    <LanguageProvider>
      <AdminAuthProvider>
        <SiteDataProvider>
          <App />
        </SiteDataProvider>
      </AdminAuthProvider>
    </LanguageProvider>
  </ThemeProvider>
);
