import React, { useState, useEffect, Suspense, lazy } from 'react';
import { ScrollProgressBar } from './components/ScrollProgressBar';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { RentalItemsSection } from './components/RentalItemsSection';
import { ServicesSection } from './components/ServicesSection';
import { GallerySection } from './components/GallerySection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { WhyChooseUsSection } from './components/WhyChooseUsSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { TeamPartnersSection } from './components/TeamPartnersSection';
import { FaqSection } from './components/FaqSection';
import { PricingSection } from './components/PricingSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { QuoteBasketDrawer, BasketItem } from './components/QuoteBasketDrawer';
import { FloatingMobileBar } from './components/FloatingMobileBar';
import { RealEstatePage } from './components/RealEstatePage';
import { ItemsMenuSection } from './components/ItemsMenuSection';
import { OurItemsSection } from './components/OurItemsSection';
import { useAdminAuth } from './context/AdminAuthContext';
import { PageLoader } from './components/PageLoader';
import { initGlobalAnimations } from './utils/animationController';

// Lazy-load owner-only portal chunks so public clients never download admin code
const AdminLogin = lazy(() =>
  import('./components/admin/AdminLogin').then((m) => ({ default: m.AdminLogin }))
);
const AdminDashboard = lazy(() =>
  import('./components/admin/AdminDashboard').then((m) => ({ default: m.AdminDashboard }))
);

export type AppView = 'tent-house' | 'real-estate' | 'admin';

export default function App() {
  const { isAuthenticated } = useAdminAuth();

  const getInitialView = (): AppView => {
    if (typeof window !== 'undefined') {
      const pathname = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (
        pathname === '/admin' ||
        pathname.startsWith('/admin') ||
        hash === '#admin' ||
        hash === '#/admin' ||
        hash.startsWith('#/admin')
      ) {
        return 'admin';
      }
      if (hash.includes('real-estate')) return 'real-estate';
    }
    return 'tent-house';
  };

  const [currentView, setCurrentView] = useState<AppView>(getInitialView);

  const [basketItems, setBasketItems] = useState<BasketItem[]>(() => {
    try {
      const saved = localStorage.getItem('karimulla_quote_basket');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isBasketOpen, setIsBasketOpen] = useState(false);
  const [selectedEventType, setSelectedEventType] = useState<string>('Wedding / Reception');

  // Initialize global vanilla JS animation triggers (IntersectionObserver, button ripple, parallax)
  useEffect(() => {
    const cleanup = initGlobalAnimations();
    return cleanup;
  }, []);

  // Handle route / hash changes
  useEffect(() => {
    const handleLocationChange = () => {
      const pathname = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();

      if (
        pathname === '/admin' ||
        pathname.startsWith('/admin') ||
        hash === '#admin' ||
        hash === '#/admin' ||
        hash.startsWith('#/admin')
      ) {
        setCurrentView('admin');
      } else if (hash.includes('real-estate')) {
        setCurrentView('real-estate');
      } else {
        setCurrentView('tent-house');
        if (hash && hash !== '#home') {
          const targetId = hash.replace('#', '');
          const el = document.getElementById(targetId);
          if (el) {
            setTimeout(() => {
              el.scrollIntoView({ behavior: 'smooth' });
            }, 50);
          }
        }
      }
    };

    window.addEventListener('hashchange', handleLocationChange);
    window.addEventListener('popstate', handleLocationChange);
    return () => {
      window.removeEventListener('hashchange', handleLocationChange);
      window.removeEventListener('popstate', handleLocationChange);
    };
  }, []);

  // Hidden route security: enforce noindex meta tag dynamically on /admin
  useEffect(() => {
    let robotsMeta = document.querySelector('meta[name="robots"]') as HTMLMetaElement | null;
    if (currentView === 'admin') {
      if (!robotsMeta) {
        robotsMeta = document.createElement('meta');
        robotsMeta.setAttribute('name', 'robots');
        document.head.appendChild(robotsMeta);
      }
      robotsMeta.setAttribute('content', 'noindex, nofollow');
    } else {
      if (robotsMeta) {
        robotsMeta.setAttribute('content', 'index, follow');
      }
    }
  }, [currentView]);

  // Persist basket items to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('karimulla_quote_basket', JSON.stringify(basketItems));
    } catch {
      // storage unavailable fallback
    }
  }, [basketItems]);

  const handleSwitchToTentHouse = () => {
    setCurrentView('tent-house');
    if (typeof window !== 'undefined') {
      if (window.location.pathname.toLowerCase().startsWith('/admin')) {
        window.history.pushState(null, '', '/#home');
      } else {
        window.location.hash = '#home';
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSwitchToRealEstate = () => {
    setCurrentView('real-estate');
    window.location.hash = '#real-estate';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToBasket = (item: any) => {
    setBasketItems((prev) => {
      const existing = prev.find((b) => b.item.id === item.id);
      if (existing) {
        return prev.map((b) =>
          b.item.id === item.id ? { ...b, quantity: b.quantity + 1 } : b
        );
      }
      return [...prev, { item, quantity: 1, days: 1, selectedSize: item.selectedSize }];
    });
  };

  const handleUpdateQuantity = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setBasketItems((prev) =>
      prev.map((b) => (b.item.id === itemId ? { ...b, quantity: newQty } : b))
    );
  };

  const handleUpdateDays = (itemId: string, newDays: number) => {
    if (newDays <= 0) return;
    setBasketItems((prev) =>
      prev.map((b) => (b.item.id === itemId ? { ...b, days: newDays } : b))
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setBasketItems((prev) => prev.filter((b) => b.item.id !== itemId));
  };

  const handleClearAll = () => {
    setBasketItems([]);
  };

  const totalBasketItemCount = basketItems.reduce((acc, curr) => acc + curr.quantity, 0);

  // Render Owner-Only Admin View if at hidden /admin route
  if (currentView === 'admin') {
    return (
      <div className="min-h-screen bg-[#120104] text-neutral-100 font-sans selection:bg-[#7A1526] selection:text-white">
        <Suspense
          fallback={
            <div className="min-h-screen flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
            </div>
          }
        >
          {isAuthenticated ? (
            <AdminDashboard onBackToSite={handleSwitchToTentHouse} />
          ) : (
            <AdminLogin onBackToSite={handleSwitchToTentHouse} />
          )}
        </Suspense>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      {/* Luxury Brand Page Preloader */}
      <PageLoader />

      {/* Scroll Progress Bar at the top */}
      <ScrollProgressBar />

      {/* Floating Ambient Blurred Particles & Orbs behind sections */}
      <div
        aria-hidden="true"
        className="fixed top-1/4 -left-20 w-96 h-96 rounded-full bg-[#D4AF37]/5 dark:bg-[#D4AF37]/10 blur-[130px] pointer-events-none anim-float-1 z-0"
      />
      <div
        aria-hidden="true"
        className="fixed bottom-1/3 -right-20 w-96 h-96 rounded-full bg-[#7A1526]/5 dark:bg-[#7A1526]/15 blur-[130px] pointer-events-none anim-float-2 z-0"
      />

      {currentView === 'real-estate' ? (
        /* Real Estate Sister Website View */
        <RealEstatePage onSwitchToTentHouse={handleSwitchToTentHouse} />
      ) : (
        /* Unified Karimulla Tent House Website (Single-Page flow) */
        <div className="bg-[#FCF9F5] dark:bg-[#120104] text-neutral-800 dark:text-neutral-100 font-sans antialiased selection:bg-[#7A1526] selection:text-white transition-colors duration-300 relative z-10">
          
          {/* Top Navbar with clean homepage section links & Real Estate button */}
          <Navbar
            quoteCount={totalBasketItemCount}
            onOpenQuoteBasket={() => setIsBasketOpen(true)}
            onSwitchToRealEstate={handleSwitchToRealEstate}
          />

          <main>
            {/* 1. Hero Section with parallax tent visual and dual CTAs */}
            <Hero />

            {/* 2. Items Menu (Main 8 Items + Item Details with Direct Add to Cart) */}
            <ItemsMenuSection 
              onAddToBasket={handleAddToBasket} 
              onOpenBasket={() => setIsBasketOpen(true)} 
            />

            {/* 2b. Our Items Section (13 Items from Product Catalogue PDF with WhatsApp Enquiry & Lightbox) */}
            <OurItemsSection
              onAddToBasket={handleAddToBasket}
              onOpenBasket={() => setIsBasketOpen(true)}
            />

            {/* 3. About Section: Founder & Director story, 22+ Years heritage, cropped portrait & guarantees */}
            <AboutSection />

            {/* 4. Rental Items & Requirement Catalogue: Filterable cards with Add to Cart */}
            <RentalItemsSection
              basketItems={basketItems}
              onAddToBasket={handleAddToBasket}
              onOpenBasket={() => setIsBasketOpen(true)}
            />

            {/* 5. Services / Events: Weddings, Birthdays, Religious, Corporate */}
            <ServicesSection
              onSelectEventType={(type) => setSelectedEventType(type)}
            />

            {/* 6. Gallery: Masonry Grid with Fullscreen Lightbox Modal */}
            <GallerySection />

            {/* 7. How It Works: Animated 4-Step Timeline */}
            <HowItWorksSection />

            {/* 8. Why Choose Us + Animated Number Counters */}
            <WhyChooseUsSection />

            {/* 9. Ratings & Testimonials: 4.9★ summary, interactive carousel, verified client reviews & leave rating modal */}
            <TestimonialsSection />

            {/* 10. Our Team & Partners Section: Seamless infinite marquee scroll, tap-to-call links, gold border cards */}
            <TeamPartnersSection />

            {/* 11. Collapsible FAQ Section: Delivery policy, cancellation, deposit details, waterproof tents & utensils */}
            <FaqSection />

            {/* 12. Popular Transparent Packages */}
            <PricingSection />

            {/* 13. Contact Section: WhatsApp Enquiry Form + Business info + Google Maps */}
            <ContactSection initialEventType={selectedEventType} />
          </main>

          {/* 14. Footer with full site links, social, and Real Estate sister link */}
          <Footer onSwitchToRealEstate={handleSwitchToRealEstate} />

          {/* Mobile Floating Quick Action Bar (WhatsApp & Call) */}
          <FloatingMobileBar
            quoteCount={totalBasketItemCount}
            onOpenQuoteBasket={() => setIsBasketOpen(true)}
          />

          {/* Slide-over Custom Quote Basket Drawer */}
          <QuoteBasketDrawer
            isOpen={isBasketOpen}
            onClose={() => setIsBasketOpen(false)}
            items={basketItems}
            onUpdateQuantity={handleUpdateQuantity}
            onUpdateDays={handleUpdateDays}
            onRemoveItem={handleRemoveItem}
            onClearAll={handleClearAll}
          />
        </div>
      )}
    </div>
  );
}
