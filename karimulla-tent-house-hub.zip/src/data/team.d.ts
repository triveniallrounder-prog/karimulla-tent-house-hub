export interface TeamProfile {
  name: string;
  brand: string;
  phone: string;
  role: 'Partner' | 'Team Member' | string;
  photo: string;
}

export declare const teamProfiles: TeamProfile[];
export default teamProfiles;
