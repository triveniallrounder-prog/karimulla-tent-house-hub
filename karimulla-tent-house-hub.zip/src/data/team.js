/**
 * Team & Partners Profiles Data File (team.js)
 * 
 * Edit this file to add, edit, or remove profiles.
 * Adding a new profile to this array will automatically add a new card to the scroll on the website.
 * 
 * Each profile contains:
 * - name: Full name (English or Telugu)
 * - brand: Partner or service brand name (e.g. Catering, Flower Decor, Photography)
 * - phone: Contact number (tap-to-call link)
 * - role: Role badge (e.g. "Partner" or "Team Member")
 * - photo: URL or path to photo (placeholder or real image)
 */

export const teamProfiles = [
  {
    name: 'Name 1',
    brand: 'Brand 1',
    phone: '00000 00000',
    role: 'Partner',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Name 2',
    brand: 'Brand 2',
    phone: '00000 00000',
    role: 'Team Member',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Name 3',
    brand: 'Brand 3',
    phone: '00000 00000',
    role: 'Partner',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Name 4',
    brand: 'Brand 4',
    phone: '00000 00000',
    role: 'Team Member',
    photo: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Name 5',
    brand: 'Brand 5',
    phone: '00000 00000',
    role: 'Partner',
    photo: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Name 6',
    brand: 'Brand 6',
    phone: '00000 00000',
    role: 'Team Member',
    photo: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=400&q=80',
  },
];

export default teamProfiles;
