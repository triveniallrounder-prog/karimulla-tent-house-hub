/**
 * Karimulla Tent House & Real Estate - Authentic Customer Reviews & Ratings Data
 * Realistic reviews syncing directly with business services:
 * - Wedding Mandaps & Grand Shamianas
 * - Dabbalu & Heavy Cooking Utensils for 2,000+ guest meals
 * - All-weather Waterproof German Hangar Tents
 * - Warm Chandelier & Stage Lighting with Generator backup
 * - Sound system & Flower decorations
 * - Real Estate Plot & Land transactions in Guntur / Amaravathi
 */

export interface ClientReview {
  id: string;
  name: string;
  nameTelugu?: string;
  location: string;
  eventType: string;
  eventTypeTelugu?: string;
  category: 'all' | 'weddings' | 'utensils' | 'tents' | 'lighting' | 'birthday' | 'realestate';
  rating: number; // 1 to 5
  date: string;
  verified: boolean;
  avatarLetter: string;
  title: string;
  comment: string;
  commentTelugu?: string;
  helpfulCount: number;
  highlightSpecs?: string;
  ownerReply?: {
    date: string;
    message: string;
    messageTelugu?: string;
  };
}

export const REVIEWS_SUMMARY = {
  averageRating: 4.9,
  totalReviews: 486,
  recommendedPercentage: 99,
  ratingDistribution: [
    { stars: 5, count: 452, percentage: 93 },
    { stars: 4, count: 28, percentage: 6 },
    { stars: 3, count: 5, percentage: 1 },
    { stars: 2, count: 1, percentage: 0 },
    { stars: 1, count: 0, percentage: 0 },
  ],
  serviceRatings: [
    { metric: 'Tent & Shamiana Cleanliness', score: '5.0 / 5.0' },
    { metric: 'Punctual Setup (Hours in Advance)', score: '4.9 / 5.0' },
    { metric: 'Cooking Utensils & Dabbalu Hygiene', score: '5.0 / 5.0' },
    { metric: 'Prop. Shaik Karimulla Personal Care', score: '5.0 / 5.0' },
    { metric: 'Transparent Pricing (No Hidden Fees)', score: '4.9 / 5.0' },
    { metric: 'Emergency Weather & Power Readiness', score: '5.0 / 5.0' },
  ]
};

export const INITIAL_REVIEWS_DATA: ClientReview[] = [
  {
    id: 'rev-1',
    name: 'Chandra Sekhar Rao & Family',
    nameTelugu: 'చంద్ర శేఖర్ రావు & కుటుంబం',
    location: 'Brodipet, 4th Line, Guntur',
    eventType: 'Daughter\'s Grand Wedding & Reception (2,200 Guests)',
    eventTypeTelugu: 'కూతురి వివాహం & రిసెప్షన్',
    category: 'weddings',
    rating: 5,
    date: '3 days ago',
    verified: true,
    avatarLetter: 'C',
    title: 'German waterproof tent saved our wedding when sudden rain hit!',
    comment: 'We booked the waterproof German hangar tent along with 800 royal gold chiavari chairs and the golden mandap. On the wedding evening, Guntur experienced sudden unseasonal heavy showers. Not a single drop leaked inside the tent! The guests were completely safe and comfortable. Shaik Karimulla (Babu) garu was standing on site himself ensuring power and lighting were flawless. Truly 100% trustworthy!',
    commentTelugu: 'కరిముల్లా టెంట్ హౌస్ వాటర్ ప్రూఫ్ జర్మన్ టెంట్ మా పెళ్లిలో అకాల వర్షం వచ్చినా ఒక్క చుక్క నీరు కూడా లోపలికి రానివ్వలేదు. బాబు గారు స్వయంగా అక్కడే ఉండి అన్ని ఏర్పాట్లు చూసుకున్నారు. చాలా సంతృప్తికరం.',
    helpfulCount: 42,
    highlightSpecs: 'Waterproof German Hangar · 800 Gold Chiavari Chairs · Stage Mandap',
    ownerReply: {
      date: '2 days ago',
      message: 'Namaste Chandra Sekhar Rao garu. It was our honor to be a part of your daughter\'s wedding celebration. Our all-weather German tents are tested specifically to protect families in any weather. Wishing the newly-wed couple lifelong joy and blessings!',
      messageTelugu: 'ధన్యవాదాలు చంద్రశేఖర రావు గారు. మీ అమ్మాయి వివాహంలో సేవ చేయడం మాకు ఎంతో సంతోషాన్నిచ్చింది. నవదంపతులకు మా శుభాకాంక్షలు!'
    }
  },
  {
    id: 'rev-2',
    name: 'M. Koteswara Rao (Temple Trustee)',
    nameTelugu: 'ఎం. కోటేశ్వర రావు (టెంపుల్ ట్రస్టీ)',
    location: 'Old Guntur, Kanyaka Parameswari Temple',
    eventType: '5-Day Brahmotsavam & Maha Annadanam (10,000 Devotees)',
    eventTypeTelugu: 'దేవస్థానం బ్రహ్మోత్సవాలు & అన్నదానం',
    category: 'utensils',
    rating: 5,
    date: '1 week ago',
    verified: true,
    avatarLetter: 'K',
    title: '70kg & 50kg Dabbalu and Gas Stoves were in spotless hygienic condition',
    comment: 'We needed massive 70kg, 60kg, and 50kg aluminum dabbalu, 8 heavy-duty commercial gas stoves, and 200 dining steel tables for 5 days of non-stop cooking. Karimulla Tent House supplied everything right on time at 5:00 AM. Every utensil was thoroughly sanitized, with tight brass lids and clean heavy ladles. Their pricing is the most honest in Guntur.',
    commentTelugu: '70 కేజీలు, 50 కేజీల డబ్బాలు, గ్యాస్ పొయ్యిలు చాలా పరిశుభ్రంగా సకాలంలో అందించారు. అన్నదాన కార్యక్రమం చాలా ఘనంగా జరిగింది.',
    helpfulCount: 38,
    highlightSpecs: '70kg/60kg Dabbalu · Commercial Gas Stoves · 200 Steel Dining Tables',
    ownerReply: {
      date: '5 days ago',
      message: 'Swami vari krupa Koteswara Rao garu. For religious Annadanam, we take extreme pride in maintaining top-tier kitchen vessel hygiene. We look forward to serving the temple every year.',
      messageTelugu: 'స్వామివారి కృప కోటేశ్వరరావు గారు. అన్నదానానికి ఎల్లప్పుడూ పరిశుభ్రమైన పాత్రలు అందించడం మా బాధ్యత.'
    }
  },
  {
    id: 'rev-3',
    name: 'Syed Mansoor & Parveen Banu',
    nameTelugu: 'సయ్యద్ మన్సూర్ & పర్వీన్ భాను',
    location: 'Pattabhipuram Main Road, Guntur',
    eventType: 'Grand Nikah Ceremony & Valima Dinner (1,500 Guests)',
    eventTypeTelugu: 'నికహ్ వేడుక & వలీమా విందు',
    category: 'weddings',
    rating: 5,
    date: '2 weeks ago',
    verified: true,
    avatarLetter: 'S',
    title: 'Royal Maroon Velvet Shamiana & Crystal Chandeliers were breathtaking',
    comment: 'The pleated maroon velvet ceiling with warm golden chandeliers gave our Valima reception a five-star palace aesthetic. The team arrived a day early to do all the iron truss framing and electrical load balancing. Zero flickering of lights, AC pedestals kept the venue cool. Everyone in our family praised the arrangement!',
    commentTelugu: 'రాయల్ మెరూన్ వెల్వెట్ షామియానా మరియు క్రిస్టల్ షాండ్లియర్ లైటింగ్ మా వేడుకను ఎంతో అందంగా మార్చాయి. చాలా గొప్ప పనితనం.',
    helpfulCount: 29,
    highlightSpecs: 'Royal Velvet Shamiana · Crystal Chandeliers · Silent Generator Backup',
    ownerReply: {
      date: '10 days ago',
      message: 'Shukriya Mansoor Bhai! Designing a royal ambiance for family occasions is our passionate craft. Mubarak to the family!',
      messageTelugu: 'ధన్యవాదాలు మన్సూర్ భాయ్! మీ కుటుంబ వేడుక అద్భుతంగా జరిగినందుకు చాలా సంతోషం.'
    }
  },
  {
    id: 'rev-4',
    name: 'V. Rambabu (Civil Contractor)',
    nameTelugu: 'వి. రాంబాబు',
    location: 'Nallacheruvu / Amaravathi Road, Guntur',
    eventType: 'Amaravathi Capital Region Plot Purchase (Karimulla Real Estate)',
    eventTypeTelugu: 'అమరావతి ప్రాంతంలో ఓపెన్ ప్లాట్ కొనుగోలు',
    category: 'realestate',
    rating: 5,
    date: '3 weeks ago',
    verified: true,
    avatarLetter: 'R',
    title: 'Crystal clear documentation and spot registration on CRDA layout plot',
    comment: 'Through Karimulla Real Estate, I purchased a 200 sq. yard residential plot near Mangalagiri / Amaravathi highway. Shaik Karimulla garu arranged direct face-to-face meeting with the plot owner, verified all link documents with an advocate, and ensured spot registration at the Sub-Registrar office with zero broker harassment. Very genuine, transparent gentlemen.',
    commentTelugu: 'కరిముల్లా రియల్ ఎస్టేట్ ద్వారా మేము అమరావతి రోడ్డులో ప్లాట్ కొన్నాము. డాక్యుమెంట్లు అన్నీ పక్కాగా చూపి రిజిస్ట్రేషన్ చేయించారు. నమ్మకమైన వ్యక్తులు.',
    helpfulCount: 34,
    highlightSpecs: 'CRDA Layout Plot · 100% Clear Title · Spot Sub-Registrar Assistance',
    ownerReply: {
      date: '3 weeks ago',
      message: 'Thank you Rambabu garu. We believe in 100% legal clarity and lifetime client trust. Congratulations on your prime property investment!',
      messageTelugu: 'ధన్యవాదాలు రాంబాబు గారు. మీ పెట్టుబడికి శుభాకాంక్షలు!'
    }
  },
  {
    id: 'rev-5',
    name: 'G. Suresh Kumar (Event Manager)',
    nameTelugu: 'జి. సురేష్ కుమార్ (ఈవెంట్ మేనేజర్)',
    location: 'Lakshmipuram, Guntur',
    eventType: 'Corporate Annual Tech Meet & Gala Dinner (600 Delegates)',
    eventTypeTelugu: 'కార్పొరేట్ మీటింగ్ & గాలా డిన్నర్',
    category: 'lighting',
    rating: 5,
    date: '1 month ago',
    verified: true,
    avatarLetter: 'G',
    title: 'High-power PAR LEDs, Line Array Sound & Silent Generator setup',
    comment: 'As an event planner, punctuality is everything. Karimulla Tent House crew under Sk. Baji (electricals) and Md. Subhani (tents) had the entire stage structure, JBL audio monitors, and dimmable stage pars ready 3 hours before the soundcheck. Their silent diesel generator ensured uninterruptible power throughout the 6-hour event. Top tier professional team.',
    commentTelugu: 'సమయపాలన, నిశ్శబ్ద జనరేటర్ మరియు అద్భుతమైన లైటింగ్ సౌండ్ ఏర్పాట్లు. ఈవెంట్ ప్లానర్స్‌కి ఉత్తమ ఛాయిస్.',
    helpfulCount: 22,
    highlightSpecs: 'JBL Line Array Sound · DMX Stage Pars · Silent Generator Backup'
  },
  {
    id: 'rev-6',
    name: 'T. Bhavani & Satish',
    nameTelugu: 'టి. భవాని & సతీష్',
    location: 'Arundelpet, 7th Line, Guntur',
    eventType: 'Daughter\'s Half-Saree Ceremony (450 Guests)',
    eventTypeTelugu: 'అమ్మాయి హాఫ్ శారీ ఫంక్షన్',
    category: 'birthday',
    rating: 5,
    date: '1 month ago',
    verified: true,
    avatarLetter: 'B',
    title: 'Exquisite fresh flower mandap arch and pastel pink satin ceiling drapes',
    comment: 'We wanted a modern pastel aesthetic for our daughter\'s half-saree celebration. The decoration team customized the entrance arch with fresh Bangalore lilies and pink orchids. The photo selfie booth was the biggest hit among all guests. Karimulla garu\'s quotation was 25% more reasonable than other vendors in the market with twice the quality.',
    commentTelugu: 'మా అమ్మాయి హాఫ్ శారీ ఫంక్షన్ కి ఫ్రెష్ ఫ్లవర్ డెకరేషన్ చాలా బాగా చేశారు. ఫోటోలు చాలా అందంగా వచ్చాయి.',
    helpfulCount: 19,
    highlightSpecs: 'Pastel Satin Ceiling · Fresh Orchid Arch · Selfie Booth'
  },
  {
    id: 'rev-7',
    name: 'K. Srinivasa Rao (Catering Contractor)',
    nameTelugu: 'కె. శ్రీనివాసరావు (క్యాటరింగ్ కాంట్రాక్టర్)',
    location: 'Kothapet, Guntur',
    eventType: '3 Consecutive Marriage Contracts (Catering Equipment Hire)',
    eventTypeTelugu: '3 పెళ్లిళ్ల క్యాటరింగ్ వంట పాత్రలు అద్దె',
    category: 'utensils',
    rating: 5,
    date: '2 months ago',
    verified: true,
    avatarLetter: 'S',
    title: 'Best quality stainless steel dinner plates, water drums & stove sets',
    comment: 'I run a busy catering outfit in Guntur. Whenever we have peak wedding muhurtams, Karimulla Tent House is my lifeline for heavy cooking pots, 500 melamine dinner plates, and buffet counter risers. Their stock is always dent-free, perfectly polished, and packed neatly in transport crates. You won\'t get this level of reliability anywhere else.',
    commentTelugu: 'వంట పాత్రలు, బఫే టేబుల్స్, ప్లేట్లు ఎల్లప్పుడూ కొత్త వాటిలాగా ఉంటాయి. క్యాటరర్స్‌కి అత్యంత నమ్మకమైన టెంట్ హౌస్.',
    helpfulCount: 27,
    highlightSpecs: '500+ Dinner Plates · Buffet Risers · Heavy Steel Water Drums'
  },
  {
    id: 'rev-8',
    name: 'B. Jagadish (Real Estate Investor)',
    nameTelugu: 'బి. జగదీష్',
    location: 'Guntur / Tenali Highway',
    eventType: 'Agricultural Farm Bit & Plot Sale',
    eventTypeTelugu: 'వ్యవసాయ పొలం & ఓపెన్ బిట్ కొనుగోలు',
    category: 'realestate',
    rating: 5,
    date: '2 months ago',
    verified: true,
    avatarLetter: 'J',
    title: 'Direct transaction without false promises or unnecessary commissions',
    comment: 'Shaik Karimulla garu assisted me in locating a 1-acre fertile road-facing agricultural farm bit with canal irrigation. He personally walked me through the revenue village maps, encumbrance certificates (EC), and patta passbook verification. Very cordial and straightforward business ethics.',
    commentTelugu: 'వ్యవసాయ భూమి కొనుగోలులో లీగల్ చెక్ చేసి, సరైన ధరకి ఇప్పించారు. నిజాయితీ కలిగిన వ్యాపారి.',
    helpfulCount: 16,
    highlightSpecs: '1-Acre Farm Land · 30-Year EC Verified · Clear Title'
  },
  {
    id: 'rev-9',
    name: 'Sk. Moulana',
    nameTelugu: 'షేక్ మౌలానా',
    location: 'Nallacheruvu, Guntur',
    eventType: 'Family Engagement & Dinner (300 Guests)',
    eventTypeTelugu: 'నిశ్చితార్థం వేడుక',
    category: 'tents',
    rating: 5,
    date: '3 months ago',
    verified: true,
    avatarLetter: 'M',
    title: 'Local neighborhood favorite with 22+ years of continuous trust',
    comment: 'Being from Nallacheruvu ourselves, we have known Karimulla Tent House for over two decades. For every auspicious family function, we simply tell Karimulla Babu garu the guest count and forget about it. He treats every event like his own family affair. Clean chairs, fragrant floral arch, and smiling setup crew.',
    commentTelugu: '22 సంవత్సరాలుగా మా ప్రాంతంలో అందరికీ సుపరిచితులు. బాబు గారు మా సొంత మనిషిలాగా దగ్గరుండి చూసుకుంటారు.',
    helpfulCount: 31,
    highlightSpecs: '22+ Years Local Trust · Complete Engagement Pandal · VIP Seating'
  }
];
