/**
 * Karimulla Tent House - Master Items Menu & Rental Inventory Data
 * Store everything in one editable file (items.js) so you can change it later.
 * 
 * NOTE: Prices and pictures are left empty for you to add/upload later:
 * "And you do not add price list and pictures I will upload pictures after sometime"
 * 
 * TOP SECTION: Main Items (8 cards)
 * 1. డబ్బాలు (Dabbalu / Drums or Boxes)
 * 2. టెంట్లు (Tents)
 * 3. గ్యాస్ స్టవ్ (Gas Stove)
 * 4. స్టౌ బిళ్లలు (Stove plates / Burners)
 * 5. బెంచీలు (Benches)
 * 6. కుర్చీలు (Chairs)
 * 7. లైటింగ్‌లు (Lightings)
 * 8. ఫ్యాన్లు (Fans)
 * 
 * BOTTOM SECTION: Item Details
 * 1) డబ్బాలు (Dabbalu / Drums or Boxes). Sizes:
 * 70 kgs, 60 kgs, 50 kgs, 40 kgs, 30 kgs, 25 kgs, 20 kgs, 15 kgs, 10 kgs, 5 kgs
 * 2) Tents (Water Proof Tents Available). Sizes:
 * 30 × 15, 12 × 24, 9 × 18
 */

export const itemsData = {
  // TOP SECTION: Main Items (8 cards)
  mainItems: [
    {
      id: "dabbalu",
      number: 1,
      telugu: "డబ్బాలు",
      english: "(Dabbalu / Drums or Boxes)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Hygienic stainless steel catering, storage and cooking drums available in 10 standard capacities.",
      specs: "Available sizes: 70kg, 60kg, 50kg, 40kg, 30kg, 25kg, 20kg, 15kg, 10kg, 5kg",
      image: "/images/products/11-drums.jpg",
      images: ["/images/products/11-drums.jpg"],
      price: "",
      unit: "per drum / day",
      targetId: "details-dabbalu",
      hasDetails: true,
      badge: "Cooking & Catering Storage",
      sizes: [
        { label: "70 kgs", price: "" },
        { label: "60 kgs", price: "" },
        { label: "50 kgs", price: "" },
        { label: "40 kgs", price: "" },
        { label: "30 kgs", price: "" },
        { label: "25 kgs", price: "" },
        { label: "20 kgs", price: "" },
        { label: "15 kgs", price: "" },
        { label: "10 kgs", price: "" },
        { label: "5 kgs", price: "" }
      ]
    },
    {
      id: "tents",
      number: 2,
      telugu: "టెంట్లు",
      english: "(Tents)",
      category: "Tents & Canopies",
      categoryTelugu: "వాటర్‌ప్రూఫ్ టెంట్లు",
      description: "Heavy-duty outdoor weather-resistant shamianas and water-proof PVC tents for functions and weddings.",
      specs: "Available sizes: 30 × 15, 12 × 24, 9 × 18 | Water Proof Tents Available",
      image: "/images/products/05-quilts.jpg",
      images: ["/images/products/05-quilts.jpg"],
      price: "",
      unit: "per tent / day",
      targetId: "details-tents",
      hasDetails: true,
      badge: "Water Proof Tents Available",
      sizes: [
        { label: "30 × 15", price: "" },
        { label: "12 × 24", price: "" },
        { label: "9 × 18", price: "" }
      ]
    },
    {
      id: "gas-stove",
      number: 3,
      telugu: "గ్యాస్ స్టవ్",
      english: "(Gas Stove)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "High-pressure commercial single & double burners with heavy frame designed for fast large-scale event cooking.",
      specs: "Industrial brass/cast burner with heavy support frame and regulator valve",
      image: "/images/products/13-gas-stoves.jpg",
      images: ["/images/products/13-gas-stoves.jpg"],
      price: "",
      unit: "per stove / day",
      targetId: "details-gas-stove",
      hasDetails: false,
      badge: "Single & Double Burners Available",
      sizes: []
    },
    {
      id: "stove-plates",
      number: 4,
      telugu: "స్టౌ బిళ్లలు",
      english: "(Stove plates / Burners)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Heavy cast-iron high flame burner plates and replacement grids for large cooking pots and deghs.",
      specs: "Heavy cast iron | High thermal resistance for large cooking vessels",
      image: "/images/products/13-gas-stoves.jpg",
      images: ["/images/products/13-gas-stoves.jpg"],
      price: "",
      unit: "per piece / day",
      targetId: "details-stove-plates",
      hasDetails: false,
      badge: "Heavy Cast Iron Burners",
      sizes: []
    },
    {
      id: "benches",
      number: 5,
      telugu: "బెంచీలు",
      english: "(Benches)",
      category: "Seating & Furniture",
      categoryTelugu: "కుర్చీలు & బెంచీలు",
      description: "Sturdy long dining and sitting benches for Annadanam feasts, prayer halls, dining pandals, and outdoor events.",
      specs: "Length: 6 ft | Sturdy iron frame with polished wooden/metal top",
      image: "/images/products/04-table-cloth-set.jpg",
      images: ["/images/products/04-table-cloth-set.jpg"],
      price: "",
      unit: "per bench / day",
      targetId: "details-benches",
      hasDetails: false,
      badge: "Dining & Seating Benches",
      sizes: []
    },
    {
      id: "chairs",
      number: 6,
      telugu: "కుర్చీలు",
      english: "(Chairs)",
      category: "Seating & Furniture",
      categoryTelugu: "కుర్చీలు & బెంచీలు",
      description: "Royal gold chiavari chairs, cushioned steel banquet chairs with satin covers, and sturdy plastic chairs.",
      specs: "Clean, sanitized, with optional organza bow ribbons and cushioned pads",
      image: "/images/products/01-plastic-chairs.jpg",
      images: ["/images/products/01-plastic-chairs.jpg"],
      price: "",
      unit: "per chair / day",
      targetId: "details-chairs",
      hasDetails: false,
      badge: "Banquet & Plastic Chairs",
      sizes: []
    },
    {
      id: "lightings",
      number: 7,
      telugu: "లైటింగ్లు",
      english: "(Lightings)",
      category: "Lighting & Cooling",
      categoryTelugu: "లైటింగ్ & కూలింగ్",
      description: "Warm LED focus lighting, stage par cans, decorative fairy lights, chandeliers, and high-mast floodlights.",
      specs: "Dimmable warm glow | Includes stands, heavy wiring and breaker panel",
      image: "/images/products/lightings.jpg",
      images: ["/images/products/lightings.jpg"],
      price: "",
      unit: "per set / day",
      targetId: "details-lightings",
      hasDetails: false,
      badge: "Focus LED, Halogen & Chandeliers",
      sizes: []
    },
    {
      id: "fans",
      number: 8,
      telugu: "ఫ్యాన్లు",
      english: "(Fans)",
      category: "Lighting & Cooling",
      categoryTelugu: "లైటింగ్ & కూలింగ్",
      description: "High-speed heavy pedestal fans, outdoor water misting fans, and jumbo desert air coolers for hot weather.",
      specs: "High air delivery | Auto-oscillation | Low noise commercial motor",
      image: "/images/products/fans.jpg",
      images: ["/images/products/fans.jpg"],
      price: "",
      unit: "per fan / day",
      targetId: "details-fans",
      hasDetails: false,
      badge: "Pedestal & Jumbo Air Coolers",
      sizes: []
    }
  ],

  // BOTTOM SECTION: Item Details
  itemDetails: {
    // 1) డబ్బాలు (Dabbalu / Drums or Boxes)
    dabbalu: {
      id: "details-dabbalu",
      title: "1) డబ్బాలు (Dabbalu / Drums or Boxes)",
      telugu: "డబ్బాలు",
      english: "(Dabbalu / Drums or Boxes)",
      badge: "Cooking & Catering Storage",
      sizes: [
        { label: "70 kgs", price: "" },
        { label: "60 kgs", price: "" },
        { label: "50 kgs", price: "" },
        { label: "40 kgs", price: "" },
        { label: "30 kgs", price: "" },
        { label: "25 kgs", price: "" },
        { label: "20 kgs", price: "" },
        { label: "15 kgs", price: "" },
        { label: "10 kgs", price: "" },
        { label: "5 kgs", price: "" }
      ]
    },

    // 2) Tents (Water Proof Tents Available)
    tents: {
      id: "details-tents",
      title: "2) Tents (Water Proof Tents Available)",
      telugu: "టెంట్లు",
      english: "(Tents)",
      badge: "Water Proof Tents Available",
      sizes: [
        { label: "30 × 15", price: "" },
        { label: "12 × 24", price: "" },
        { label: "9 × 18", price: "" }
      ]
    },

    // Additional items from the list for smooth-scrolling & enquiry
    otherItems: [
      {
        id: "details-gas-stove",
        title: "3) గ్యాస్ స్టవ్ (Gas Stove)",
        telugu: "గ్యాస్ స్టవ్",
        english: "(Gas Stove)",
        badge: "Single & Double Burners Available"
      },
      {
        id: "details-stove-plates",
        title: "4) స్టౌ బిళ్లలు (Stove plates / Burners)",
        telugu: "స్టౌ బిళ్లలు",
        english: "(Stove plates / Burners)",
        badge: "Heavy Cast Iron Burners"
      },
      {
        id: "details-benches",
        title: "5) బెంచీలు (Benches)",
        telugu: "బెంచీలు",
        english: "(Benches)",
        badge: "Dining & Seating Benches"
      },
      {
        id: "details-chairs",
        title: "6) కుర్చీలు (Chairs)",
        telugu: "కుర్చీలు",
        english: "(Chairs)",
        badge: "Banquet & Plastic Chairs"
      },
      {
        id: "details-lightings",
        title: "7) లైటింగ్లు (Lightings)",
        telugu: "లైటింగ్లు",
        english: "(Lightings)",
        badge: "Focus LED, Halogen & Chandeliers"
      },
      {
        id: "details-fans",
        title: "8) ఫ్యాన్లు (Fans)",
        telugu: "ఫ్యాన్లు",
        english: "(Fans)",
        badge: "Pedestal & Jumbo Air Coolers"
      }
    ]
  }
};

export default itemsData;
