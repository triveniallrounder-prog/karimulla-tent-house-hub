/**
 * Karimulla Real Estate - Master Property & Business Data
 * Complete listings for plots, villas, commercial and farm lands in Guntur & Amaravathi.
 */

import reHeroImg from '../assets/images/real_estate_hero_1790921293068.jpg';
import villaImg from '../assets/images/luxury_villa_duplex_1790921308932.jpg';

export interface PropertyListing {
  id: string;
  title: string;
  teluguTitle: string;
  type: 'Open Plots' | 'Residential Villas' | 'Commercial Land' | 'Farm Land';
  location: string;
  price: string;
  priceRaw: number;
  extent: string;
  facing: string;
  approval: string; // CRDA / RERA / DTCP / Municipal
  features: string[];
  description: string;
  image: string;
  isFeatured?: boolean;
}

export const REAL_ESTATE_BUSINESS = {
  name: "Karimulla Real Estate",
  nameTelugu: "కరిముల్లా రియల్ ఎస్టేట్",
  tagline: "Open plots, farm lands, houses, apartments — contact us for buying & selling.",
  taglineTelugu: "ఓపెన్ ప్లాట్లు, పొలాలు, ఇల్లులు, అపార్ట్‌మెంట్స్, అమ్మదలచిన, కొనదలచిన సంప్రదించగలరు.",
  taglineEnglish: "Open plots, farm lands, houses, apartments — contact us for buying & selling.",
  subtitle: "22+ Years of Unwavering Trust, 100% Clear Titles & Transparent Property Deals",
  subtitleTelugu: "గుంటూరు & అమరావతిలో 22+ ఏళ్ల నమ్మకం, 100% క్లియర్ టైటిల్స్ మరియు పారదర్శక లావాదేవీలు",
  subtitleEnglish: "22+ Years of Unwavering Trust, 100% Clear Titles & Transparent Property Deals",
  ownerTelugu: "ప్రొ॥ షేక్ కరిముల్లా (బాబు)",
  ownerEnglish: "Prop. Shaik Karimulla (Babu)",
  owner: "ప్రొ॥ షేక్ కరిముల్లా (బాబు) / Prop. Shaik Karimulla (Babu)",
  phone1: "9030 610 877",
  phone1Raw: "919030610877",
  phone2: "98481 47203",
  phone2Raw: "919848147203",
  phone: "9030 610 877",
  phoneRaw: "919030610877",
  alternatePhone: "98481 47203",
  alternatePhoneRaw: "919848147203",
  email: "karimullarealestate@gmail.com",
  addressTelugu: "నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరు.",
  addressEnglish: "Nallacheruvu, 12th Line, Main Road, Guntur.",
  address: "నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరు (Nallacheruvu, 12th Line, Main Road, Guntur)",
  city: "Guntur",
  state: "Andhra Pradesh",
  pincode: "522003",
  workingHours: "Mon – Sun: 8:00 AM – 8:30 PM (Site Visits Available All 7 Days)",
  stats: {
    plotsSold: 480,
    investorsServed: 2400,
    acresDeveloped: 120,
    experienceYears: 22,
  }
};

export const PROPERTIES_DATA: PropertyListing[] = [
  {
    id: 'prop-1',
    title: 'Amaravathi Capital Pride CRDA Plots',
    teluguTitle: 'అమరావతి క్యాపిటల్ సిటీ CRDA ప్లాట్లు',
    type: 'Open Plots',
    location: 'Near AIIMS & Inner Ring Road, Mangalagiri / Kaza',
    price: '₹22,500 / Sq. Yd',
    priceRaw: 3712500,
    extent: '165 to 330 Sq. Yards',
    facing: 'East & North Facing Available',
    approval: 'CRDA & RERA Approved Layout',
    features: [
      '40 & 60 ft Blacktop BT Roads',
      'Underground Drainage & Water Pipelines',
      'Avenue Plantations & Landscaped Parks',
      'Immediate Spot Registration Available',
      'Bank Loan Facility up to 75%'
    ],
    description: 'High-growth residential layout strategically situated just 10 minutes from Amaravathi Core Secretariat and AIIMS Mangalagiri. Exceptional appreciation potential for investors.',
    image: reHeroImg,
    isFeatured: true,
  },
  {
    id: 'prop-2',
    title: 'Royal Greens 4BHK Luxury Duplex Villa',
    teluguTitle: 'రాయల్ గ్రీన్స్ 4BHK లగ్జరీ డ్యూప్లెక్స్ విల్లా',
    type: 'Residential Villas',
    location: 'Brodipet Extension, Guntur',
    price: '₹1.45 Crore',
    priceRaw: 14500000,
    extent: '220 Sq. Yds (2,750 Sq. Ft Built-up)',
    facing: 'East Facing, 100% Vastu Compliant',
    approval: 'Guntur Municipal Corporation Approved',
    features: [
      'G+1 Independent Duplex with Private Terrace Garden',
      'Italian Marble Flooring & Teakwood Doors',
      'Covered 2-Car Parking with EV Charging Point',
      '24/7 Gated Security with CCTV Surveillance',
      'Individual Borewell and Municipal Drinking Water'
    ],
    description: 'Architecturally crafted luxury duplex in Guntur’s most prestigious residential neighborhood. Walking distance from reputed schools, banks, and shopping centers.',
    image: villaImg,
    isFeatured: true,
  },
  {
    id: 'prop-3',
    title: 'NH-16 Highway Frontage Commercial Bit',
    teluguTitle: 'NH-16 హైవే ఫ్రంటేజ్ కమర్షియల్ బిట్',
    type: 'Commercial Land',
    location: 'Kaza Toll Plaza / Guntur Bypass, NH-16',
    price: '₹4.8 Crore (Negotiable)',
    priceRaw: 48000000,
    extent: '1.25 Acres (6,050 Sq. Yds)',
    facing: 'National Highway Direct Frontage (180 ft)',
    approval: 'Commercial Conversion Clear Title',
    features: [
      '180 Feet Direct NH-16 Highway Frontage',
      'Ideal for Star Hotel, Auto Showroom, or Hospital',
      'Single Owner Clear Patta Title & Link Documents',
      '3-Phase Heavy Industrial Power Connection Feasible',
      'High Rental Yield and Strategic Visibility'
    ],
    description: 'Rare opportunity to acquire clear-title highway commercial land situated on the busiest golden quadrilateral stretch between Vijayawada and Guntur.',
    image: reHeroImg,
    isFeatured: true,
  },
  {
    id: 'prop-4',
    title: 'Pattabhipuram Premium Residential Plot',
    teluguTitle: 'పట్టాభిపురం రెసిడెన్షియల్ ప్లాట్',
    type: 'Open Plots',
    location: 'Pattabhipuram Main Road, Guntur',
    price: '₹38,000 / Sq. Yd',
    priceRaw: 7600000,
    extent: '200 Sq. Yards (36 x 50 ft)',
    facing: 'North-East Corner Bit',
    approval: 'Municipal Approved Layout',
    features: [
      'Corner Plot with Dual 33ft Wide Roads',
      'Surrounded by Upscale Independent Houses',
      'Zero Waterlogging & Elevated Ground',
      'Ready for Immediate House Construction',
      'Clear Legal Title verified by Senior Advocate'
    ],
    description: 'A prized residential corner plot located in a peaceful, fully-developed colony with municipal tap connection, streetlights, and prime connectivity.',
    image: reHeroImg,
    isFeatured: false,
  },
  {
    id: 'prop-5',
    title: 'Amaravathi Riverfront Fertile Agri/Farm Land',
    teluguTitle: 'అమరావతి రివర్‌ఫ్రంట్ వ్యవసాయ / ఫామ్‌ల్యాండ్',
    type: 'Farm Land',
    location: 'Thullur / Vykuntapuram Road, Amaravathi',
    price: '₹42 Lakhs / Half Acre',
    priceRaw: 4200000,
    extent: '0.5 Acre (24 Guntas)',
    facing: '40 ft Tar Road Access',
    approval: 'Agricultural Clear Title (Passbook & 1B)',
    features: [
      'Fertile Black Cotton Soil with Sweet Borewell Water',
      'Existing Teak and Coconut Border Plantations',
      'Chain-link Fencing with Metal Gate Completed',
      'Ideal for Weekend Farmhouse or Organic Orchard',
      'Scenic Greenery Near River Krishna'
    ],
    description: 'Picturesque farm land plot suitable for building your dream weekend retreat or organic farming, situated close to the Amaravathi capital expressway.',
    image: reHeroImg,
    isFeatured: false,
  },
  {
    id: 'prop-6',
    title: 'Guntur Clock Tower Commercial Showroom Space',
    teluguTitle: 'క్లాక్ టవర్ కమర్షియల్ షాప్ / షోరూమ్',
    type: 'Commercial Land',
    location: 'Main Bazar Road, Near Clock Tower, Guntur',
    price: '₹75 Lakhs',
    priceRaw: 7500000,
    extent: '950 Sq. Feet Carpet Area (Ground Floor)',
    facing: 'Main Market Road Facing',
    approval: 'Commercial Municipal Approved',
    features: [
      'Prime Ground Floor Retail Showroom with Glass Front',
      'Currently Earning ₹38,000/month Rental Income',
      'High Footfall Commercial Gold Market Corridor',
      'Dedicated Basement Two-Wheeler Parking',
      'Instant Transfer of Tenancy and Rent Receipts'
    ],
    description: 'High-earning commercial shop space located right in the heart of Guntur’s bustling retail market, providing immediate cash flow and capital safety.',
    image: villaImg,
    isFeatured: false,
  }
];

export const REAL_ESTATE_FAQS = [
  {
    question: "How does Karimulla Real Estate verify land documents and titles?",
    questionTelugu: "భూమి పత్రాలు మరియు టైటిల్స్‌ను కరిముల్లా రియల్ ఎస్టేట్ ఎలా ధృవీకరిస్తుంది?",
    answer: "Every property we showcase undergoes strict legal scrutiny by senior high-court advocates in Guntur. We verify 30-year Encumbrance Certificates (EC), original registered link deeds, Revenue 1B/Adangal records, and DTCP/CRDA master plans before presenting to any buyer.",
    answerTelugu: "మేము ప్రదర్శించే ప్రతి ప్రాపర్టీని గుంటూరులోని సీనియర్ న్యాయవాదులచే సమగ్ర న్యాయ పరిశీలన చేయిస్తాము. 30 ఏళ్ల EC, ఒరిజినల్ రిజిస్టర్డ్ లింక్ డాక్యుమెంట్లు, రెవెన్యూ 1B/అడంగల్ రికార్డులు మరియు DTCP/CRDA లేఅవుట్ అనుమతులను క్షుణ్ణంగా తనిఖీ చేస్తాము."
  },
  {
    question: "Do you arrange site visits for prospective buyers?",
    questionTelugu: "కొనుగోలుదారులకు ఉచిత సైట్ విజిట్ సదుపాయం కల్పిస్తారా?",
    answer: "Yes! We provide complimentary chauffeur-driven site inspection visits 7 days a week from our Guntur office. Karimulla garu or our senior field coordinators accompany you to explain the boundaries, road alignments, and local development prospects.",
    answerTelugu: "అవును! మా గుంటూరు కార్యాలయం నుండి వారంలో 7 రోజులు ఉచిత ఫోర్-వీలర్ సైట్ ఇన్‌స్పెక్షన్ సౌకర్యం అందిస్తాము. కరిముల్లా గారు స్వయంగా సరిహద్దులు, రోడ్లు మరియు భవిష్యత్ అభివృద్ధి అవకాశాలను వివరిస్తారు."
  },
  {
    question: "Can I get a bank loan for purchasing plots or villas?",
    questionTelugu: "ప్లాట్లు లేదా విల్లాల కొనుగోలుకు బ్యాంక్ లోన్ సౌకర్యం లభిస్తుందా?",
    answer: "Yes, our CRDA and GMC approved layouts have pre-approved project loans from major nationalized and private banks including SBI, HDFC, ICICI, and Canara Bank with loan funding up to 70–80% of the property value.",
    answerTelugu: "అవును, మా CRDA మరియు GMC ఆమోదిత లేఅవుట్లకు SBI, HDFC, ICICI, కెనరా బ్యాంక్ వంటి ప్రముఖ బ్యాంకుల నుండి 70% నుండి 80% వరకు ప్రాజెక్ట్ లోన్ సదుపాయం కలదు."
  },
  {
    question: "Do you assist with registration and revenue mutation?",
    questionTelugu: "రిజిస్ట్రేషన్ మరియు రెవెన్యూ మ్యుటేషన్‌లో సహాయం అందిస్తారా?",
    answer: "From drafting sales agreements and paying stamp duty to biometric spot registration at the Sub-Registrar Office and subsequent municipality mutation, our team handles the entire process end-to-end.",
    answerTelugu: "సేల్ అగ్రిమెంట్ డ్రాఫ్టింగ్, స్టాంప్ డ్యూటీ చెల్లింపు, సబ్-రిజిస్ట్రార్ కార్యాలయంలో బయోమెట్రిక్ స్పాట్ రిజిస్ట్రేషన్ మరియు మున్సిపల్ మ్యుటేషన్ వరకు పూర్తి ప్రక్రియను మా బృందం దగ్గరుండి పూర్తి చేస్తుంది."
  }
];
