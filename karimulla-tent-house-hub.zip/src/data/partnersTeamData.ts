/**
 * Karimulla Tent House - Trusted Partners & Team Members Data
 * Easily edit team member names, phone numbers, photos, and roles here.
 */

export interface TeamMember {
  id: string;
  name: string;
  teluguName?: string;
  role: string;
  roleTelugu?: string;
  phone: string;
  phoneRaw: string;
  experience: string;
  photo: string; // Leave empty for photo upload slot
  speciality: string;
}

export interface SpecificTeam {
  id: string;
  name: string;
  teluguName: string;
  description: string;
  leadName: string;
  leadPhone: string;
  leadPhoneRaw: string;
  badge: string;
  members: TeamMember[];
}

export interface TrustedPartner {
  id: string;
  businessName: string;
  teluguName: string;
  category: string;
  contactPerson: string;
  phone: string;
  phoneRaw: string;
  location: string;
  badge: string;
  photo: string;
  services: string[];
}

export const TRUSTED_PARTNERS_DATA: TrustedPartner[] = [
  {
    id: 'partner-floral',
    businessName: 'Sri Venkateswara Fresh Flower Decorators',
    teluguName: 'శ్రీ వెంకటేశ్వర ఫ్రెష్ ఫ్లవర్ డెకరేటర్స్',
    category: 'Fresh Flower Mandap & Garlands',
    contactPerson: 'K. Rama Krishna',
    phone: '98481 47203',
    phoneRaw: '919848147203',
    location: 'Flower Market, Kothapet, Guntur',
    badge: '18+ Years Association',
    photo: '', // Add partner photo here
    services: [
      'Bangalore Orchid & Rose Mandaps',
      'Fresh Jasmine & Marigold Garlands',
      'Traditional Temple Kalyana Mandap Decor',
      'Car & Welcome Arch Decoration'
    ]
  },
  {
    id: 'partner-catering',
    businessName: 'Annapurna Royal Catering Chefs',
    teluguName: 'అన్నపూర్ణ రాయల్ క్యాటరింగ్ మాస్టర్స్',
    category: 'Authentic Traditional Catering',
    contactPerson: 'M. Subba Rao Master',
    phone: '90306 10877',
    phoneRaw: '919030610877',
    location: 'Brodipet, Guntur',
    badge: 'Pure Veg & Non-Veg Feasts',
    photo: '', // Add partner photo here
    services: [
      'Authentic Andhra Wedding Meals',
      'Hyderabadi Dum Biryani Specialties',
      'Live Dosa, Tandoori & Sweet Stalls',
      'Annadanam Bulk Cooking Setup'
    ]
  },
  {
    id: 'partner-sound',
    businessName: 'Devi Pro Sound & DJ Entertainment',
    teluguName: 'దేవి ప్రో సౌండ్ & డిజె ఎంటర్‌టైన్‌మెంట్',
    category: 'Pro Line Array Sound & Stage DJ',
    contactPerson: 'B. Suresh Kumar',
    phone: '98481 47203',
    phoneRaw: '919848147203',
    location: 'Arundelpet, Guntur',
    badge: 'High-Fidelity Sound',
    photo: '', // Add partner photo here
    services: [
      'JBL / RCF Line Array Audio Systems',
      'Cordless Mics & Stage Monitors',
      'Sangeet & Reception DJ Lighting',
      'Devotional Bhajana Audio Systems'
    ]
  },
  {
    id: 'partner-photo',
    businessName: 'Prism Wedding Cinematic Studios',
    teluguName: 'ప్రిజమ్ వెడ్డింగ్ సినిమాటిక్ స్టూడియోస్',
    category: 'Cinematic Video & Drone Coverage',
    contactPerson: 'T. Rajesh',
    phone: '90306 10877',
    phoneRaw: '919030610877',
    location: 'Lakshmipuram, Guntur',
    badge: '4K Cinematic Quality',
    photo: '', // Add partner photo here
    services: [
      '4K Cinematic Wedding Films',
      '4K Aerial Drone Coverage',
      'Traditional Candid Photography',
      'Live LED Screen Webcasting'
    ]
  }
];

export const SPECIFIC_TEAMS_DATA: SpecificTeam[] = [
  {
    id: 'team-decoration',
    name: 'Decoration & Mandap Team',
    teluguName: 'డెకరేషన్ & స్టేజ్ మండపం టీమ్',
    description: 'Expert fabricators, floral stylists, and reception backdrop craftsmen with decades of wedding artistry.',
    leadName: 'K. Venkatesh (Senior Stage & Floral Lead)',
    leadPhone: '98481 47203',
    leadPhoneRaw: '919848147203',
    badge: 'Grand Stage Specialists',
    members: [
      {
        id: 'dec-1',
        name: 'K. Venkatesh',
        teluguName: 'కె. వెంకటేష్',
        role: 'Team Lead & Mandap Architect',
        roleTelugu: 'టీమ్ లీడ్ & మండపం డిజైనర్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '16 Years',
        photo: '', // Upload photo
        speciality: 'Royal Mandaps & Golden Pillars'
      },
      {
        id: 'dec-2',
        name: 'Sk. Munna',
        teluguName: 'షేక్ మున్నా',
        role: 'Floral Styling Specialist',
        roleTelugu: 'ఫ్లవర్ డెకరేషన్ స్పెషలిస్ట్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '12 Years',
        photo: '', // Upload photo
        speciality: 'Exotic Flower Garlands & Arches'
      },
      {
        id: 'dec-3',
        name: 'M. Ravi Teja',
        teluguName: 'ఎం. రవితేజ',
        role: 'Fabric & Satin Draper',
        roleTelugu: 'శాటిన్ క్లాత్ డ్రేపింగ్ ఎక్స్‌పర్ట్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '9 Years',
        photo: '', // Upload photo
        speciality: 'Pleated Velvet Ceiling & Backdrops'
      },
      {
        id: 'dec-4',
        name: 'G. Appa Rao',
        teluguName: 'జి. అప్పారావు',
        role: 'Entrance & Selfie Booth Artist',
        roleTelugu: 'ఎంట్రన్స్ & సెల్ఫీ బూత్ స్పెషలిస్ట్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '8 Years',
        photo: '', // Upload photo
        speciality: 'Grand Theme Arches & Pathway Tunnel'
      }
    ]
  },
  {
    id: 'team-lighting',
    name: 'Lighting & Electricals Team',
    teluguName: 'లైటింగ్ & ఎలక్ట్రికల్స్ టీమ్',
    description: 'Certified electrical riggers managing ambient warm illumination, crystal chandeliers, RGBW pars, and generator backup.',
    leadName: 'Sk. Baji (Master Electrical Engineer)',
    leadPhone: '90306 10877',
    leadPhoneRaw: '919030610877',
    badge: '24/7 Power Safety Assured',
    members: [
      {
        id: 'light-1',
        name: 'Sk. Baji',
        teluguName: 'షేక్ బాజీ',
        role: 'Chief Electrician & Lighting Head',
        roleTelugu: 'చీఫ్ ఎలక్ట్రీషియన్ & లైటింగ్ హెడ్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '18 Years',
        photo: '', // Upload photo
        speciality: 'High-Tension Wiring & Phase Load Balancing'
      },
      {
        id: 'light-2',
        name: 'D. Srinivas',
        teluguName: 'డి. శ్రీనివాస్',
        role: 'Focus & Par LED Light Technician',
        roleTelugu: 'LED ఫోకస్ & పార్ టెక్నీషియన్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '11 Years',
        photo: '', // Upload photo
        speciality: 'Warm Ambience & Stage Illumination'
      },
      {
        id: 'light-3',
        name: 'K. Prasad',
        teluguName: 'కె. ప్రసాద్',
        role: 'Chandelier & Fairy Light Rigger',
        roleTelugu: 'షాండ్లియర్ & సీలింగ్ లైట్స్ ఎక్స్‌పర్ట్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '7 Years',
        photo: '', // Upload photo
        speciality: 'Crystal Chandeliers & Tree Fairy Lights'
      },
      {
        id: 'light-4',
        name: 'Sk. Khaza',
        teluguName: 'షేక్ ఖాజా',
        role: 'Silent Generator & Safety Tech',
        roleTelugu: 'జనరేటర్ & సర్క్యూట్ సేఫ్టీ టెక్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '10 Years',
        photo: '', // Upload photo
        speciality: 'Zero-Blackout Generator Switchover'
      }
    ]
  },
  {
    id: 'team-tents',
    name: 'Tent & Shamiana Setup Crew',
    teluguName: 'టెంట్ & షామియానా ఫిట్టింగ్ టీమ్',
    description: 'Specialized pandal erectors for heavy iron pipe structures, waterproof PVC German hangars, and traditional festive shamianas.',
    leadName: 'Md. Subhani (Chief Structural Rigger)',
    leadPhone: '98481 47203',
    leadPhoneRaw: '919848147203',
    badge: 'Weatherproof Specialists',
    members: [
      {
        id: 'tent-1',
        name: 'Md. Subhani',
        teluguName: 'ఎండీ. సుభాని',
        role: 'Chief Structural Rigger & Pandal Head',
        roleTelugu: 'చీఫ్ స్ట్రక్చరల్ రిగ్గర్ & పందిరి హెడ్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '20 Years',
        photo: '', // Upload photo
        speciality: 'Wind-Resistant Heavy Iron Pandal Setup'
      },
      {
        id: 'tent-2',
        name: 'A. Rambabu',
        teluguName: 'ఎ. రాంబాబు',
        role: 'Waterproof Tent Specialist',
        roleTelugu: 'వాటర్‌ప్రూఫ్ టెంట్ స్పెషలిస్ట్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '14 Years',
        photo: '', // Upload photo
        speciality: 'German Pagoda & Heavy PVC Tarpaulins'
      },
      {
        id: 'tent-3',
        name: 'Sk. Mastan',
        teluguName: 'షేక్ మస్తాన్',
        role: 'Side Wall & Drapery Fitter',
        roleTelugu: 'సైడ్ వాల్ & స్క్రీన్ ఫిట్టర్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '10 Years',
        photo: '', // Upload photo
        speciality: 'Pleated Side Walls & Privacy Curtains'
      },
      {
        id: 'tent-4',
        name: 'Ch. Nageswara Rao',
        teluguName: 'సిహెచ్. నాగేశ్వరరావు',
        role: 'Ground Leveling & Carpeting Lead',
        roleTelugu: 'ఫ్లోరింగ్ & కార్పెట్ లీడ్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '8 Years',
        photo: '', // Upload photo
        speciality: 'Red Carpet, Synthetic Turf & Wooden Base'
      }
    ]
  },
  {
    id: 'team-utensils',
    name: 'Catering Equipment & Utensils Team',
    teluguName: 'వంటసామానులు & డబ్బాలు టీమ్',
    description: 'Managing hygienic cleaning, quality inspection, and dispatch of cooking drums (5kg-70kg), high-pressure stoves, and burners.',
    leadName: 'P. Srinivasa Rao (Catering Logistics Supervisor)',
    leadPhone: '90306 10877',
    leadPhoneRaw: '919030610877',
    badge: '100% Sanitized Utensils',
    members: [
      {
        id: 'ut-1',
        name: 'P. Srinivasa Rao',
        teluguName: 'పి. శ్రీనివాసరావు',
        role: 'Inventory & Hygiene Supervisor',
        roleTelugu: 'ఇన్వెంటరీ & హైజీన్ సూపర్‌వైజర్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '15 Years',
        photo: '', // Upload photo
        speciality: 'Steam Sanitization & Stock Accuracy'
      },
      {
        id: 'ut-2',
        name: 'Sk. Jani',
        teluguName: 'షేక్ జానీ',
        role: 'Gas Stove & Burner Safety Specialist',
        roleTelugu: 'గ్యాస్ స్టవ్ & బర్నర్ సేఫ్టీ స్పెషలిస్ట్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '13 Years',
        photo: '', // Upload photo
        speciality: 'Commercial Burner Flame Testing & Regulators'
      },
      {
        id: 'ut-3',
        name: 'B. Narayana',
        teluguName: 'బి. నారాయణ',
        role: 'Stainless Steel Drums & Degh Handler',
        roleTelugu: 'డబ్బాలు & బిర్యానీ డేగాలు హ్యాండ్లర్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '9 Years',
        photo: '', // Upload photo
        speciality: 'Dabbalu Capacity Calibration (5kg - 70kg)'
      },
      {
        id: 'ut-4',
        name: 'M. Govind',
        teluguName: 'ఎం. గోవింద్',
        role: 'Dining Benches & Chairs Stacker',
        roleTelugu: 'డైనింగ్ బెంచీలు & కుర్చీల స్టాకర్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '6 Years',
        photo: '', // Upload photo
        speciality: 'Rapid Dining Hall Setup for Annadanam'
      }
    ]
  },
  {
    id: 'team-logistics',
    name: 'Transport & Logistics Team',
    teluguName: 'రవాణా & డెలివరీ టీమ్',
    description: 'Fleet drivers and dispatch crew ensuring punctual arrival, safe transit, and rapid post-event retrieval across Guntur district.',
    leadName: 'Sk. Rabbani (Fleet & Transport Dispatcher)',
    leadPhone: '98481 47203',
    leadPhoneRaw: '919848147203',
    badge: 'On-Time Venue Delivery',
    members: [
      {
        id: 'log-1',
        name: 'Sk. Rabbani',
        teluguName: 'షేక్ రబ్బానీ',
        role: 'Fleet Manager & Transport Dispatcher',
        roleTelugu: 'ఫ్లీట్ మేనేజర్ & ట్రాన్స్‌పోర్ట్ డిస్పాచర్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '14 Years',
        photo: '', // Upload photo
        speciality: 'Route Optimization & Punctual Dispatch'
      },
      {
        id: 'log-2',
        name: 'K. Venkateswarlu',
        teluguName: 'కె. వెంకటేశ్వర్లు',
        role: 'Heavy Vehicle Senior Driver',
        roleTelugu: 'భారీ వాహనాల సీనియర్ డ్రైవర్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '16 Years',
        photo: '', // Upload photo
        speciality: 'Rural & Highway Safe Navigation'
      },
      {
        id: 'log-3',
        name: 'Sk. Chand',
        teluguName: 'షేక్ చాంద్',
        role: 'Loading & Securing Specialist',
        roleTelugu: 'లోడింగ్ & అన్‌లోడింగ్ స్పెషలిస్ట్',
        phone: '98481 47203',
        phoneRaw: '919848147203',
        experience: '8 Years',
        photo: '', // Upload photo
        speciality: 'Zero-Damage Stacking & Tie-Downs'
      },
      {
        id: 'log-4',
        name: 'T. Shiva Kumar',
        teluguName: 'టి. శివకుమార్',
        role: 'Night Retrieval & Clearance Lead',
        roleTelugu: 'నైట్ రిట్రీవల్ & క్లియరెన్స్ లీడ్',
        phone: '90306 10877',
        phoneRaw: '919030610877',
        experience: '7 Years',
        photo: '', // Upload photo
        speciality: 'Post-Event Fast Venue Clearance'
      }
    ]
  }
];
