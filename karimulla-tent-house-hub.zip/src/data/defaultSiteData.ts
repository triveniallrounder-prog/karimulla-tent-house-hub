export interface SizeVariant {
  label: string;
  price: string;
}

export interface ProductItem {
  id: string;
  number: number;
  telugu: string;
  english: string;
  category: string;
  categoryTelugu: string;
  description: string;
  specs: string;
  image: string; // main display image
  images: string[]; // multiple images array
  price: string;
  unit: string;
  targetId: string;
  hasDetails: boolean;
  badge: string;
  visible: boolean; // visibility toggle
  sizes: SizeVariant[];
}

export interface FounderData {
  name: string;
  nameTelugu: string;
  title: string;
  titleTelugu: string;
  bio: string;
  bioTelugu: string;
  experienceYears: number;
  phone1: string;
  phone1Raw: string;
  phone2: string;
  phone2Raw: string;
  photo: string;
  showPhoto: boolean;
  addressTelugu: string;
  addressEnglish: string;
  socialLinks: {
    instagram: string;
    facebook: string;
    whatsapp: string;
  };
}

export interface Teammate {
  id: string;
  name: string;
  role: string;
  phone: string;
  photo: string;
  details: string;
}

export interface Partner {
  id: string;
  name: string;
  brand: string;
  role: string;
  phone: string;
  photo: string;
  website?: string;
  details?: string;
}

export interface PartnershipData {
  heading: string;
  headingTelugu: string;
  description: string;
  descriptionTelugu: string;
  contactNote: string;
}

export interface WebsiteSettings {
  siteTitle: string;
  siteName: string;
  siteNameTelugu: string;
  tagline: string;
  taglineTelugu: string;
  heroHeading: string;
  heroSubheading: string;
  heroBannerImage: string;
  phone1: string;
  phone1Raw: string;
  phone2: string;
  phone2Raw: string;
  email: string;
  addressEnglish: string;
  addressTelugu: string;
  footerText: string;
}

export interface SiteData {
  items: ProductItem[];
  founder: FounderData;
  team: Teammate[];
  partners: Partner[];
  partnership: PartnershipData;
  settings: WebsiteSettings;
  lastUpdated: string;
}

export const DEFAULT_SITE_DATA: SiteData = {
  items: [
    {
      id: "dabbalu",
      number: 1,
      telugu: "డబ్బాలు",
      english: "(Dabbalu / Drums or Boxes)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Hygienic stainless steel catering, storage and cooking drums available in 10 standard capacities.",
      specs: "Available sizes: 70kg, 60kg, 50kg, 40kg, 30kg, 25kg, 20kg, 15kg, 10kg, 5kg",
      image: "/images/products/11-drums.jpg",
      images: ["/images/products/11-drums.jpg"],
      price: "",
      unit: "per drum / day",
      targetId: "details-dabbalu",
      hasDetails: true,
      badge: "Cooking & Catering Storage",
      visible: true,
      sizes: [
        { label: "70 kgs", price: "" },
        { label: "60 kgs", price: "" },
        { label: "50 kgs", price: "" },
        { label: "40 kgs", price: "" },
        { label: "30 kgs", price: "" },
        { label: "25 kgs", price: "" },
        { label: "20 kgs", price: "" },
        { label: "15 kgs", price: "" },
        { label: "10 kgs", price: "" },
        { label: "5 kgs", price: "" }
      ]
    },
    {
      id: "tents",
      number: 2,
      telugu: "టెంట్లు",
      english: "(Tents)",
      category: "Tents & Canopies",
      categoryTelugu: "వాటర్‌ప్రూఫ్ టెంట్లు",
      description: "All-weather waterproof German pagoda canopies and traditional iron pipe shamianas for rainproof protection.",
      specs: "Water Proof Tents Available. Standard sizes: 30 × 15, 12 × 24, 9 × 18",
      image: "/images/products/05-quilts.jpg",
      images: ["/images/products/05-quilts.jpg"],
      price: "",
      unit: "per tent / day",
      targetId: "details-tents",
      hasDetails: true,
      badge: "100% All-Weather Rainproof",
      visible: true,
      sizes: [
        { label: "30 × 15", price: "" },
        { label: "12 × 24", price: "" },
        { label: "9 × 18", price: "" }
      ]
    },
    {
      id: "gas-stove",
      number: 3,
      telugu: "గ్యాస్ స్టవ్",
      english: "(Gas Stove)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Heavy-duty commercial brass burner gas stoves engineered for large-scale wedding feast preparations.",
      specs: "High-pressure industrial burner with regulator hose pipe included",
      image: "/images/products/13-gas-stoves.jpg",
      images: ["/images/products/13-gas-stoves.jpg"],
      price: "",
      unit: "per stove / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Heavy Feasts & Catering",
      visible: true,
      sizes: []
    },
    {
      id: "stove-plates",
      number: 4,
      telugu: "స్టౌ బిళ్లలు",
      english: "(Stove plates / Burners)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Solid cast-iron cooking burner tops and rings providing stable support for heavy cooking vessels.",
      specs: "Heavy cast-iron high-heat distribution plates",
      image: "/images/products/13-gas-stoves.jpg",
      images: ["/images/products/13-gas-stoves.jpg"],
      price: "",
      unit: "per plate / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Heavy Cooking Rings",
      visible: true,
      sizes: []
    },
    {
      id: "benches",
      number: 5,
      telugu: "బెంచీలు",
      english: "(Benches)",
      category: "Seating & Furniture",
      categoryTelugu: "కుర్చీలు & బెంచీలు",
      description: "Sturdy dining and seating benches for communal dining, wedding pandals, and religious gatherings.",
      specs: "6-ft length steel/wood reinforced dining bench",
      image: "/images/products/04-table-cloth-set.jpg",
      images: ["/images/products/04-table-cloth-set.jpg"],
      price: "",
      unit: "per bench / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Communal Banquet Dining",
      visible: true,
      sizes: []
    },
    {
      id: "chairs",
      number: 6,
      telugu: "కుర్చీలు",
      english: "(Chairs)",
      category: "Seating & Furniture",
      categoryTelugu: "కుర్చీలు & బెంచీలు",
      description: "Premium VIP banquet chairs and comfortable plastic molded armchairs with optional stain-resistant covers.",
      specs: "Available with satin frill cloth covers and bows",
      image: "/images/products/01-plastic-chairs.jpg",
      images: ["/images/products/01-plastic-chairs.jpg"],
      price: "",
      unit: "per chair / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Banquet & VIP Seating",
      visible: true,
      sizes: []
    },
    {
      id: "lightings",
      number: 7,
      telugu: "లైటింగ్‌లు",
      english: "(Lightings)",
      category: "Lighting & Cooling",
      categoryTelugu: "లైటింగ్ & కూలింగ్",
      description: "Festive fairy rice-bulb serial strings, bright floodlights, and decorative chandeliers.",
      specs: "High-lumen outdoor LED series with power distribution cables",
      image: "/images/products/lightings.jpg",
      images: ["/images/products/lightings.jpg"],
      price: "",
      unit: "per set / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Festive Ambience & Flood",
      visible: true,
      sizes: []
    },
    {
      id: "fans",
      number: 8,
      telugu: "ఫ్యాన్లు",
      english: "(Fans)",
      category: "Lighting & Cooling",
      categoryTelugu: "లైటింగ్ & కూలింగ్",
      description: "High-velocity industrial pedestal fans and high-volume cooling mist fans to keep outdoor guests cool.",
      specs: "3-speed heavy oscillation pedestal fan with safety guard",
      image: "/images/products/fans.jpg",
      images: ["/images/products/fans.jpg"],
      price: "",
      unit: "per fan / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "High-Velocity Cooling",
      visible: true,
      sizes: []
    },
    {
      id: "stage-green-mat",
      number: 9,
      telugu: "స్టేజ్ గ్రీన్ మ్యాట్",
      english: "(Stage Green Mat)",
      category: "Stage & Flooring",
      categoryTelugu: "స్టేజ్ & ఫ్లోరింగ్",
      description: "Lush green artificial turf mat rolls for stage platform decoration and walkway runners.",
      specs: "High Density Green Grass | Clean & Well Maintained",
      image: "/images/products/02-stage-green-mat.jpg",
      images: ["/images/products/02-stage-green-mat.jpg"],
      price: "",
      unit: "per roll / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Stage & Walkway Turf",
      visible: true,
      sizes: []
    },
    {
      id: "table-cloths",
      number: 10,
      telugu: "టేబుల్ క్లాత్స్",
      english: "(Table Cloths – Different Types)",
      category: "Linen & Bedding",
      categoryTelugu: "టేబుల్ క్లాత్స్ & డెకరేషన్",
      description: "Vibrant patterned and colored table cloths in multiple styles for buffet counters and guest tables.",
      specs: "Multiple Color Patterns | Freshly Laundered & Ironed",
      image: "/images/products/03-table-cloths.jpg",
      images: ["/images/products/03-table-cloths.jpg"],
      price: "",
      unit: "per piece / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "All Colors & Patterns",
      visible: true,
      sizes: []
    },
    {
      id: "plates",
      number: 11,
      telugu: "భోజనం ప్లేట్లు",
      english: "(Plates)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Mirror-finish, heavy-gauge stainless steel dining plates for large-scale wedding feasts.",
      specs: "Heavy Food-Grade Stainless Steel | Ultra Clean",
      image: "/images/products/06-plates.jpg",
      images: ["/images/products/06-plates.jpg"],
      price: "",
      unit: "per 100 pcs / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Mirror Polish Steel",
      visible: true,
      sizes: []
    },
    {
      id: "bowls",
      number: 12,
      telugu: "బౌల్స్ (బాషన్లు)",
      english: "(Bowls / Bashan)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Stainless steel curry bowls, sambar vessels, and food service bashans in varied capacities.",
      specs: "Assorted Sizes & Depths | Mirror Polish Steel",
      image: "/images/products/07-bowls.jpg",
      images: ["/images/products/07-bowls.jpg"],
      price: "",
      unit: "per set / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Assorted Capacities",
      visible: true,
      sizes: []
    },
    {
      id: "spoons",
      number: 13,
      telugu: "స్పూన్లు",
      english: "(Spoons)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Serving spoons, soup spoons, dessert spoons, and large catering cooking ladles.",
      specs: "Food-Grade Stainless Steel | Sturdy Handles",
      image: "/images/products/08-spoons.jpg",
      images: ["/images/products/08-spoons.jpg"],
      price: "",
      unit: "per set / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Serving & Dining Sets",
      visible: true,
      sizes: []
    },
    {
      id: "jugs",
      number: 14,
      telugu: "జగ్గులు",
      english: "(Jugs)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Sturdy stainless steel water jugs with ergonomic handles for convenient drinking water table service.",
      specs: "2-Litre & 3-Litre Capacities | Ergonomic Spout",
      image: "/images/products/09-jugs.jpg",
      images: ["/images/products/09-jugs.jpg"],
      price: "",
      unit: "per piece / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Table Water Service",
      visible: true,
      sizes: []
    },
    {
      id: "buckets",
      number: 15,
      telugu: "బకెట్లు",
      english: "(Buckets)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Heavy stainless steel buckets with sturdy brass/steel handles for serving rasam, dal, and water.",
      specs: "Strong Grip Handle | Heavy Gauge Base",
      image: "/images/products/10-buckets.jpg",
      images: ["/images/products/10-buckets.jpg"],
      price: "",
      unit: "per piece / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Serving & Utility",
      visible: true,
      sizes: []
    },
    {
      id: "hot-flask",
      number: 16,
      telugu: "టీ / కాఫీ హాట్ ఫ్లాస్క్",
      english: "(Tea / Coffee Hot Flask)",
      category: "Catering & Utensils",
      categoryTelugu: "వంటసామానులు",
      description: "Heavy insulated commercial tea and coffee dispensers with tap to keep beverages piping hot.",
      specs: "Double Wall Thermal Insulated | Smooth Dispenser Tap",
      image: "/images/products/12-tea-coffee-hot-flask.jpg",
      images: ["/images/products/12-tea-coffee-hot-flask.jpg"],
      price: "",
      unit: "per flask / day",
      targetId: "item-details-section",
      hasDetails: false,
      badge: "Keeps Hot for 8+ Hours",
      visible: true,
      sizes: []
    }
  ],
  founder: {
    name: "Prop. Shaik Karimulla (Babu)",
    nameTelugu: "ప్రొ॥ షేక్ కరిముల్లా (బాబు)",
    title: "Founder & Proprietor",
    titleTelugu: "వ్యవస్థాపకులు & డైరెక్టర్",
    bio: "Under the direct leadership of Prop. Shaik Karimulla (Babu), Karimulla Tent House has served thousands of weddings, family milestones, and grand celebrations across Guntur for over 22 years.",
    bioTelugu: "షేక్ కరిముల్లా గారి ఆధ్వర్యంలో 22 ఏళ్ల విశ్వసనీయ సేవలు. వివాహాలు, శుభకార్యాలు, మరియు భారీ ఆధ్యాత్మిక కార్యక్రమాలకు కావాల్సిన వాటర్‌ప్రూఫ్ టెంట్లు, నాణ్యమైన వంట డబ్బాలు, కుర్చీలు మరియు లైటింగ్ సదుపాయాలు మా వద్ద లభించును.",
    experienceYears: 22,
    phone1: "98481 47203",
    phone1Raw: "919848147203",
    phone2: "98481 47203",
    phone2Raw: "919848147203",
    photo: "",
    showPhoto: false, // User requested no founder photo by default, but admin can toggle or upload if desired!
    addressTelugu: "నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరు.",
    addressEnglish: "Nallacheruvu, 12th Line, Main Road, Guntur.",
    socialLinks: {
      instagram: "https://instagram.com/karimullatents",
      facebook: "https://facebook.com/karimullatents",
      whatsapp: "919848147203"
    }
  },
  team: [
    {
      id: "team-1",
      name: "Shaik Karimulla",
      role: "Managing Director",
      phone: "98481 47203",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80",
      details: "Overseeing all event operations, inventory allocations, and client satisfaction."
    },
    {
      id: "team-2",
      name: "Ramesh Naidu",
      role: "Operations Supervisor",
      phone: "98481 47203",
      photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80",
      details: "Head of on-site transport, team scheduling, and early 12-hour pandal setup."
    },
    {
      id: "team-3",
      name: "Syed Mastan",
      role: "Lighting & Audio Technician",
      phone: "98481 47203",
      photo: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=400&q=80",
      details: "Electrical safety, generator backup maintenance, and festive stage lighting."
    }
  ],
  partners: [
    {
      id: "partner-1",
      name: "Royal Catering Services",
      brand: "Traditional Andhra Feasts",
      role: "Catering Partner",
      phone: "98481 47203",
      photo: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=400&q=80",
      website: "https://wa.me/919848147203",
      details: "Master chefs specialized in vegetarian and non-vegetarian wedding menus."
    },
    {
      id: "partner-2",
      name: "Sri Lakshmi Flower Decorators",
      brand: "Fresh Botanical Mandaps",
      role: "Floral Decor Partner",
      phone: "98481 47203",
      photo: "https://images.unsplash.com/photo-1519225448526-0b815617300f?auto=format&fit=crop&w=400&q=80",
      website: "https://wa.me/919848147203",
      details: "Exquisite jasmine, rose, and orchid entrance arches and reception stage backdrops."
    },
    {
      id: "partner-3",
      name: "Amaravathi Photography & Films",
      brand: "Candid Moments Studio",
      role: "Media Partner",
      phone: "98481 47203",
      photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80",
      website: "https://wa.me/919848147203",
      details: "Drone coverage, 4K cinematic wedding highlight films, and live LED streaming."
    }
  ],
  partnership: {
    heading: "Collaborate With Karimulla Tent House",
    headingTelugu: "మా విశ్వసనీయ ఈవెంట్ భాగస్వామ్య నెట్‌వర్క్",
    description: "We work hand-in-hand with reputed catering teams, flower artisans, event managers, and wedding halls to deliver seamless 360-degree event production.",
    descriptionTelugu: "క్యాటరర్లు, డెకరేటర్లు, ఫోటోగ్రాఫర్లు మరియు ఫంక్షన్ హాల్ యజమానులతో సమన్వయంతో పరిపూర్ణమైన సేవలందించడం మా ప్రత్యేకత.",
    contactNote: "Are you an event vendor in Guntur or Amaravathi? Join our trusted partner network by contacting Karimulla garu directly."
  },
  settings: {
    siteTitle: "Karimulla Tent House | Premium Wedding & Event Rentals",
    siteName: "Karimulla Tent House",
    siteNameTelugu: "కరిముల్లా టెంట్ హౌస్",
    tagline: "Waterproof German Tents, Dabbalu, Banquet Chairs & Lighting for Auspicious Events",
    taglineTelugu: "వాటర్‌ప్రూఫ్ జర్మన్ టెంట్లు, డబ్బాలు, కుర్చీలు, లైటింగ్ మరియు ఈవెంట్ సామగ్రి అద్దెకు లభించును.",
    heroHeading: "Karimulla Tent House",
    heroSubheading: "Premier Tent House & Event Equipment Rentals · Guntur",
    heroBannerImage: "/images/hero-banner.jpg",
    phone1: "98481 47203",
    phone1Raw: "919848147203",
    phone2: "98481 47203",
    phone2Raw: "919848147203",
    email: "karimullatents@gmail.com",
    addressEnglish: "Nallacheruvu, 12th Line, Main Road, Guntur, Andhra Pradesh 522003",
    addressTelugu: "నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరు.",
    footerText: "© 2026 Karimulla Tent House. All Rights Reserved. Guntur, Andhra Pradesh."
  },
  lastUpdated: new Date().toISOString()
};
