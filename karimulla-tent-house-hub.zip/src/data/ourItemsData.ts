export interface CatalogItem {
  id: string;
  order: number;
  sequence: string;
  name: string;
  nameTelugu: string;
  image: string;
  alt: string;
  category: 'Furniture & Seating' | 'Stage & Flooring' | 'Linen & Bedding' | 'Catering Utensils' | 'Cooking Equipment';
  categoryTelugu: string;
  description: string;
  descriptionTelugu: string;
  highlights?: string[];
}

/**
 * Karimulla Tent House - Our Items Catalog
 * Extracted directly from Product_Catalogue.pdf (Pages 2-14)
 * WhatsApp enquiries sent directly with prefilled product message.
 */
export const OUR_ITEMS_CATALOG: CatalogItem[] = [
  {
    id: 'item-01',
    order: 1,
    sequence: '01',
    name: 'Plastic Chairs',
    nameTelugu: 'ప్లాస్టిక్ కుర్చీలు',
    image: '/images/products/01-plastic-chairs.jpg',
    alt: 'Stack of blue and red heavy-duty plastic chairs for event seating',
    category: 'Furniture & Seating',
    categoryTelugu: 'కుర్చీలు & ఫర్నిచర్',
    description: 'High-quality heavy duty plastic chairs suitable for marriages, receptions, and public gatherings. Bulk quantities available.',
    descriptionTelugu: 'పెళ్లిళ్లు, రిసెప్షన్లు మరియు ఫంక్షన్లకు అనువైన దృఢమైన ప్లాస్టిక్ కుర్చీలు. పెద్ద మొత్తంలో లభించును.',
    highlights: ['Heavy Duty Molded Plastic', 'Comfortable Backrest', 'Bulk Stock Available'],
  },
  {
    id: 'item-02',
    order: 2,
    sequence: '02',
    name: 'Stage Green Mat',
    nameTelugu: 'స్టేజ్ గ్రీన్ మ్యాట్',
    image: '/images/products/02-stage-green-mat.jpg',
    alt: 'Roll of premium stage green artificial grass carpet mat for event decoration',
    category: 'Stage & Flooring',
    categoryTelugu: 'స్టేజ్ & ఫ్లోరింగ్',
    description: 'Lush green artificial turf mat rolls for stage platform decoration, walkway runners, and VIP guest seating areas.',
    descriptionTelugu: 'స్టేజ్ డెకరేషన్, నడక దారి మరియు వి.ఐ.పి ఏరియాలకు ఉపయోగించే హై క్వాలిటీ గ్రీన్ మ్యాట్.',
    highlights: ['High Density Green Grass', 'Clean & Well Maintained', 'Custom Stage Sizes'],
  },
  {
    id: 'item-03',
    order: 3,
    sequence: '03',
    name: 'Table Cloths – Different Types',
    nameTelugu: 'టేబుల్ క్లాత్స్ – రకరకాల మోడల్స్',
    image: '/images/products/03-table-cloths.jpg',
    alt: 'Different types and vibrant patterned decorative table cloths with Telugu and English text',
    category: 'Linen & Bedding',
    categoryTelugu: 'టేబుల్ క్లాత్స్ & డెకరేషన్',
    description: 'Vibrant patterned and colored table cloths in multiple styles, textures, and prints for buffet counters and guest tables.',
    descriptionTelugu: 'వివిధ రకాల అందమైన డిజైన్లు మరియు కలర్స్ లో డైనింగ్, బఫే టేబుల్ క్లాత్స్ అందుబాటులో ఉన్నాయి.',
    highlights: ['Multiple Color Patterns', 'Freshly Laundered & Ironed', 'Standard Buffet Sizes'],
  },
  {
    id: 'item-04',
    order: 4,
    sequence: '04',
    name: 'Table Cloth Set (Folded)',
    nameTelugu: 'టేబుల్ క్లాత్ సెట్ (ఫోల్డెడ్)',
    image: '/images/products/04-table-cloth-set.jpg',
    alt: 'Neatly folded banquet dining table cloth set ready for event dining tables',
    category: 'Linen & Bedding',
    categoryTelugu: 'టేబుల్ క్లాత్స్ & డెకరేషన్',
    description: 'Complete matched set of folded banquet dining table covers, perfectly sized and pressed for dining rows and banquets.',
    descriptionTelugu: 'నీట్ గా మడతపెట్టిన డైనింగ్ టేబుల్ క్లాత్ సెట్లు, బఫే మరియు విందు భోజనాల టేబుల్లకు సరైనవి.',
    highlights: ['Complete Matching Set', 'Wrinkle Free Pressing', 'Durable Fabric'],
  },
  {
    id: 'item-05',
    order: 5,
    sequence: '05',
    name: 'Tents – All Models & Sizes',
    nameTelugu: 'టెంట్లు – అన్ని రకాలు & సైజులు',
    image: '/images/products/05-quilts.jpg',
    alt: 'Tents in all models, designs, and sizes for events with Telugu and English text',
    category: 'Linen & Bedding',
    categoryTelugu: 'టెంట్లు & డెకరేషన్',
    description: 'All-weather waterproof tents and canopies available in all models, designs, and custom sizes for weddings, receptions, and functions.',
    descriptionTelugu: 'పెళ్లిళ్లు, శుభకార్యాలు మరియు ఫంక్షన్లకు అన్ని రకాల మోడల్స్, డిజైన్లు మరియు సైజులలో వాటర్‌ప్రూఫ్ టెంట్లు అందుబాటులో ఉన్నాయి.',
    highlights: ['All Models & Designs', 'All Sizes Available', 'Waterproof & Durable'],
  },
  {
    id: 'item-06',
    order: 6,
    sequence: '06',
    name: 'Plates',
    nameTelugu: 'భోజనం ప్లేట్లు (స్టీల్ ప్లేట్స్)',
    image: '/images/products/06-plates.jpg',
    alt: 'Stack of stainless steel catering dining plates for wedding feasts',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Mirror-finish, heavy-gauge stainless steel dining plates for large-scale wedding feasts, banquets, and family gatherings.',
    descriptionTelugu: 'హెవీ గేజ్ స్టెయిన్‌లెస్ స్టీల్ డైనింగ్ ప్లేట్లు. వేల సంఖ్యలో పెళ్లిళ్లు మరియు ఫంక్షన్లకు అందుబాటులో ఉన్నాయి.',
    highlights: ['Heavy Food-Grade Stainless Steel', 'Ultra Clean & Sparkling', 'Bulk Numbers for 1000+ Guests'],
  },
  {
    id: 'item-07',
    order: 7,
    sequence: '07',
    name: 'Bowls (Bashan)',
    nameTelugu: 'బౌల్స్ / బాషన్లు (వంట సామాగ్రి)',
    image: '/images/products/07-bowls.jpg',
    alt: 'Stainless steel bowls and bashan vessels for catering and food service',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Traditional and modern stainless steel curry bowls, sambar bowls, and food service bashans in varied capacities.',
    descriptionTelugu: 'కూరలు, సాంబార్, స్వీట్లు వడ్డించడానికి ఉపయోగించే నాణ్యమైన స్టీల్ బాషన్లు మరియు బౌల్స్.',
    highlights: ['Assorted Sizes & Depths', 'Mirror Polish Steel', 'Easy To Handle'],
  },
  {
    id: 'item-08',
    order: 8,
    sequence: '08',
    name: 'Spoons',
    nameTelugu: 'స్పూన్లు / గరిటెలు',
    image: '/images/products/08-spoons.jpg',
    alt: 'Assorted stainless steel serving and dining spoons for catering',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Serving spoons, soup spoons, dessert spoons, and large catering cooking ladles in sturdy stainless steel.',
    descriptionTelugu: 'భోజనానికి మరియు వడ్డించడానికి ఉపయోగించే అన్ని రకాల స్టీల్ స్పూన్లు, గరిటెలు.',
    highlights: ['Food-Grade Quality', 'Sturdy Non-Bendable Handles', 'Complete Sets'],
  },
  {
    id: 'item-09',
    order: 9,
    sequence: '09',
    name: 'Jugs',
    nameTelugu: 'వాటర్ జగ్గులు',
    image: '/images/products/09-jugs.jpg',
    alt: 'Stainless steel water jugs and carafes for guest table dining',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Sturdy stainless steel water jugs with ergonomic handles and spouts for convenient drinking water table service.',
    descriptionTelugu: 'డైనింగ్ టేబుల్స్ పై మంచినీటి సర్వీస్ కోసం దృఢమైన స్టెయిన్‌లెస్ స్టీల్ వాటర్ జగ్గులు.',
    highlights: ['2-Litre & 3-Litre Capacities', 'Ergonomic Pouring Spout', 'Hygienic Clean Condition'],
  },
  {
    id: 'item-10',
    order: 10,
    sequence: '10',
    name: 'Buckets',
    nameTelugu: 'బకెట్లు (స్టీల్ & ప్లాస్టిక్)',
    image: '/images/products/10-buckets.jpg',
    alt: 'Heavy-duty stainless steel and utility buckets for cooking and washing',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Heavy stainless steel buckets with sturdy brass/steel handles for serving rasam, dal, water, and kitchen utility needs.',
    descriptionTelugu: 'సాంబార్, రసం, వాటర్ సర్వింగ్ మరియు వంటశాల కోసం ఉపయోగించే హెవీ డ్యూటీ స్టీల్ బకెట్లు.',
    highlights: ['Strong Grip Handle', 'Heavy Gauge Base', 'Multi-Purpose Use'],
  },
  {
    id: 'item-11',
    order: 11,
    sequence: '11',
    name: 'Drums',
    nameTelugu: 'డ్రమ్ములు / వాటర్ స్టోరేజ్ డ్రమ్స్',
    image: '/images/products/11-drums.jpg',
    alt: 'Large stainless steel storage drums and water containers for event kitchens',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Large-capacity stainless steel drums for clean drinking water storage, rice storage, and cooking prep at event venues.',
    descriptionTelugu: 'పెద్ద ఎత్తున మంచినీటి నిల్వ మరియు ఆహార తయారీ కోసం ఉపయోగించే భారీ సైజు స్టీల్ డ్రమ్ములు.',
    highlights: ['50L to 200L Capacities', 'Leak-Proof Welding', 'Cover Lids Included'],
  },
  {
    id: 'item-12',
    order: 12,
    sequence: '12',
    name: 'Tea / Coffee Hot Flask',
    nameTelugu: 'టీ / కాఫీ హాట్ ఫ్లాస్క్',
    image: '/images/products/12-tea-coffee-hot-flask.jpg',
    alt: 'Insulated stainless steel tea and coffee hot flasks and dispensers',
    category: 'Catering Utensils',
    categoryTelugu: 'వంట & డైనింగ్ సామాగ్రి',
    description: 'Heavy insulated commercial tea and coffee dispensers with tap dispensers to keep beverages piping hot for hours.',
    descriptionTelugu: 'టీ మరియు కాఫీ గంటల తరబడి వేడిగా ఉంచే కమర్షియల్ ఇన్సులేటెడ్ హాట్ ఫ్లాస్క్‌లు టాప్ డిస్పెన్సర్‌తో.',
    highlights: ['Thermal Insulated Double Wall', 'Smooth Flow Dispenser Tap', '10L, 20L & 30L Capacities'],
  },
  {
    id: 'item-13',
    order: 13,
    sequence: '13',
    name: 'Gas Stoves – Different Models',
    nameTelugu: 'గ్యాస్ స్టవ్‌లు – రకరకాల మోడల్స్',
    image: '/images/products/13-gas-stoves.jpg',
    alt: 'Heavy commercial catering bhatti gas stoves in different burner models',
    category: 'Cooking Equipment',
    categoryTelugu: 'వంట స్టవ్‌లు & భట్టీలు',
    description: 'Heavy duty high-flame catering gas stoves, single burner bhattis, double burners, and large cooking ranges for master chefs.',
    descriptionTelugu: 'పెద్ద వంటకాల కోసం హై ఫ్లేమ్ కమర్షియల్ గ్యాస్ స్టవ్‌లు మరియు భట్టీలు అన్ని మోడల్స్ లో లభించును.',
    highlights: ['High Pressure Flame', 'Cast Iron Burners', 'Heavy Vessel Support Frames'],
  },
];

/**
 * Helper to build prefilled WhatsApp enquiry URL for a product
 */
export function getProductWhatsAppUrl(
  productName: string, 
  phoneRaw: string = '919848147203'
): string {
  const message = `Hello, I want to enquire about ${productName}`;
  return `https://wa.me/${phoneRaw}?text=${encodeURIComponent(message)}`;
}
