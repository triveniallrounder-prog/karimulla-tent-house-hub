/**
 * Karimulla Tent House - Master Business & Rental Inventory Data
 * Easily edit prices, items, business contact details, and categories here.
 */

// Generated high-resolution image assets
import heroTentImg from '../assets/images/hero_grand_tent_1790867003430.jpg';
import germanTentImg from '../assets/images/waterproof_german_tent_1790867016343.jpg';
import banquetChairsImg from '../assets/images/banquet_chairs_setup_1790867028075.jpg';
import royalStageImg from '../assets/images/royal_mandap_stage_1790867039652.jpg';

export interface BusinessDetails {
  name: string;
  nameTelugu: string;
  tagline: string;
  taglineTelugu: string;
  subtitle: string;
  ownerTelugu: string;
  ownerEnglish: string;
  owner: string;
  phone1: string;
  phone1Raw: string;
  phone2: string;
  phone2Raw: string;
  phone: string;
  phoneRaw: string;
  alternatePhone: string;
  alternatePhoneRaw: string;
  email: string;
  addressTelugu: string;
  addressEnglish: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  workingHours: string;
  googleMapsEmbedUrl: string;
  realEstateLabelTelugu: string;
  realEstateLabelEnglish: string;
  realEstateLineTelugu: string;
  realEstateUrl: string;
  realEstateLabel: string;
  experienceYears: number;
  eventsCompleted: number;
  happyClients: number;
  inventoryCount: number;
}

export const BUSINESS_DETAILS: BusinessDetails = {
  name: "Karimulla Tent House",
  nameTelugu: "కరిముల్లా టెంట్హౌస్",
  tagline: "టెంట్లు, కుర్చీలు, టేబుళ్ళు, స్టేజ్ డెకరేషన్, వంటసామానులు అద్దెకు ఇవ్వబడును",
  taglineTelugu: "టెంట్లు, కుర్చీలు, టేబుళ్ళు, స్టేజ్ డెకరేషన్, వంటసామానులు అద్దెకు ఇవ్వబడును",
  subtitle: "Tents, Chairs, Tables, Stage Decoration & Cooking Utensils on Rental",
  ownerTelugu: "ప్రొ॥ షేక్ కరిముల్లా (బాబు)",
  ownerEnglish: "Prop. Shaik Karimulla (Babu)",
  owner: "ప్రొ॥ షేక్ కరిముల్లా (బాబు) / Prop. Shaik Karimulla (Babu)",
  phone1: "98481 47203",
  phone1Raw: "919848147203",
  phone2: "90306 10877",
  phone2Raw: "919030610877",
  phone: "98481 47203",
  phoneRaw: "919848147203",
  alternatePhone: "90306 10877",
  alternatePhoneRaw: "919030610877",
  email: "karimullatents@gmail.com",
  addressTelugu: "నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరు.",
  addressEnglish: "Nallacheruvu, 12th Line, Main Road, Guntur.",
  address: "నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరు (Nallacheruvu, 12th Line, Main Road, Guntur)",
  city: "Guntur",
  state: "Andhra Pradesh",
  pincode: "522003",
  workingHours: "Mon – Sun: 7:00 AM – 10:00 PM (24/7 Event Setup Support)",
  // Embed map pointing to Nallacheruvu 12th Line Main Road Guntur
  googleMapsEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15318.067341235123!2d80.428784!3d16.295245!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a4a7541b0b533a1%3A0x7c73b22cf3ffcf18!2sNallacheruvu%2C%20Guntur%2C%20Andhra%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin",
  realEstateLabelTelugu: "రియల్ ఎస్టేట్",
  realEstateLabelEnglish: "Karimulla Real Estate",
  realEstateLineTelugu: "ఓపెన్ ప్లాట్లు, పొలాలు, ఇల్లులు, అపార్ట్మెంట్స్, అమ్మదలచిన, కొనదలచిన సంప్రదించగలరు.",
  realEstateUrl: "https://karimullarealestate.com",
  realEstateLabel: "రియల్ ఎస్టేట్ (Karimulla Real Estate)",
  experienceYears: 22,
  eventsCompleted: 3850,
  happyClients: 14200,
  inventoryCount: 65000,
};

export type ItemCategory = 
  | 'All'
  | 'Tents'
  | 'Chairs'
  | 'Tables'
  | 'Stage'
  | 'Lighting'
  | 'Sound'
  | 'Utensils'
  | 'Cooling';

export interface RentalItem {
  id: string;
  name: string;
  teluguName?: string;
  category: ItemCategory;
  pricePerDay: number;
  unit: string;
  description: string;
  specs: string;
  image: string;
  isPopular?: boolean;
}

export const RENTAL_ITEMS: RentalItem[] = [
  {
    id: 'cat-dabbalu',
    name: 'డబ్బాలు (Dabbalu / Drums or Boxes)',
    teluguName: 'డబ్బాలు (5 kgs to 70 kgs)',
    category: 'Utensils',
    pricePerDay: 250,
    unit: 'per vessel / day',
    description: 'Hygienic stainless steel cooking, storage and biryani drums available in 10 standard capacities from 5 kgs up to 70 kgs.',
    specs: 'Available sizes: 70kg, 60kg, 50kg, 40kg, 30kg, 25kg, 20kg, 15kg, 10kg, 5kg',
    image: banquetChairsImg,
    isPopular: true,
  },
  {
    id: 'cat-tents',
    name: 'టెంట్లు (Tents / Water Proof Tents)',
    teluguName: 'టెంట్లు (వాటర్‌ప్రూఫ్ అందుబాటులో కలవు)',
    category: 'Tents',
    pricePerDay: 3500,
    unit: 'per unit / day',
    description: 'Weatherproof shamianas and water-proof PVC tents for outdoor lawns, wedding ceremonies, and functions.',
    specs: 'Available sizes: 30 × 15 ft, 12 × 24 ft, 9 × 18 ft | Water Proof Available',
    image: germanTentImg,
    isPopular: true,
  },
  {
    id: 'cat-gas-stove',
    name: 'గ్యాస్ స్టవ్ (Gas Stove)',
    teluguName: 'గ్యాస్ స్టవ్ (హెవీ కమర్షియల్)',
    category: 'Utensils',
    pricePerDay: 400,
    unit: 'per stove / day',
    description: 'Heavy-duty single and double commercial high-pressure gas stoves for wedding catering and event cooking.',
    specs: 'Industrial brass/cast burner with heavy support frame and regulator valve',
    image: banquetChairsImg,
    isPopular: true,
  },
  {
    id: 'cat-stove-plates',
    name: 'స్టౌ బిళ్లలు (Stove plates / Burners)',
    teluguName: 'స్టౌ బిళ్లలు (బర్నర్స్)',
    category: 'Utensils',
    pricePerDay: 150,
    unit: 'per piece / day',
    description: 'Heavy cast-iron high flame burner plates and replacement grids for bulk food preparation.',
    specs: 'Heavy cast iron | High thermal resistance for large cooking pots',
    image: banquetChairsImg,
    isPopular: false,
  },
  {
    id: 'cat-benches',
    name: 'బెంచీలు (Benches)',
    teluguName: 'డైనింగ్ & సిట్టింగ్ బెంచీలు',
    category: 'Tables',
    pricePerDay: 80,
    unit: 'per bench / day',
    description: 'Comfortable long dining and seating benches for Annadanam feasts, prayer halls, and outdoor functions.',
    specs: 'Length: 6 ft | Sturdy iron frame with polished wooden/metal top',
    image: banquetChairsImg,
    isPopular: true,
  },
  {
    id: 'cat-chairs',
    name: 'కుర్చీలు (Chairs - Banquet, Chiavari & Plastic)',
    teluguName: 'కుర్చీలు (బాంక్వెట్ & కియవారి)',
    category: 'Chairs',
    pricePerDay: 25,
    unit: 'per chair / day',
    description: 'Royal gold chiavari chairs, cushioned steel banquet chairs with satin covers, and sturdy plastic chairs.',
    specs: 'Clean, sanitized, with optional organza bow ribbons and cushioned pads',
    image: banquetChairsImg,
    isPopular: true,
  },
  {
    id: 'cat-lightings',
    name: 'లైటింగ్లు (Lightings - LED, Halogen & Chandeliers)',
    teluguName: 'లైటింగ్లు (LED & షాండ్లియర్స్)',
    category: 'Lighting',
    pricePerDay: 1500,
    unit: 'per set / day',
    description: 'Ambient warm white focus lights, crystal chandeliers, RGBW stage pars, and outdoor halogen floodlights.',
    specs: 'Dimmable warm glow | Includes stands, heavy wiring and breaker panel',
    image: heroTentImg,
    isPopular: true,
  },
  {
    id: 'cat-fans',
    name: 'ఫ్యాన్లు (Fans - Pedestal & Jumbo Coolers)',
    teluguName: 'ఫ్యాన్లు & జంబో ఎయిర్ కూలర్స్',
    category: 'Cooling',
    pricePerDay: 450,
    unit: 'per fan / day',
    description: 'High-speed heavy pedestal fans, outdoor water misting fans, and jumbo desert air coolers.',
    specs: 'High air delivery | Auto-oscillation | Low noise commercial motor',
    image: germanTentImg,
    isPopular: true,
  },
  {
    id: 'tent-shamiana',
    name: 'Royal Velvet Wedding Shamiana & Pandal',
    teluguName: 'రాయల్ పెళ్లి షామియానా',
    category: 'Tents',
    pricePerDay: 4500,
    unit: 'per 18x36 ft section / day',
    description: 'Traditional royal maroon and gold pleated satin ceiling with ornamental frills, side curtains, and matching structural column wraps.',
    specs: 'Standard 18x36 ft | Customizable ceiling drape colors | Heavy iron frame poles',
    image: heroTentImg,
    isPopular: true,
  },
  {
    id: 'chair-chiavari-gold',
    name: 'Royal Gold Chiavari Banquet Chairs',
    teluguName: 'రాయల్ గోల్డ్ కుర్చీలు',
    category: 'Chairs',
    pricePerDay: 45,
    unit: 'per chair / day',
    description: 'Metallic champagne gold chiavari chairs fitted with premium ivory cushioned seat pads. Standard choice for VIP seating and main reception.',
    specs: 'Material: Heavy Resin Resin / Wood | Weight cap: 180kg | Cushion included',
    image: banquetChairsImg,
    isPopular: true,
  },
  {
    id: 'chair-banquet-cushioned',
    name: 'Steel Banquet Chairs with Satin Cover',
    teluguName: 'స్టీల్ బాంక్వెట్ చైర్స్',
    category: 'Chairs',
    pricePerDay: 25,
    unit: 'per chair / day',
    description: 'Comfortable cushioned steel banquet chairs available with pure white, maroon, or gold stretch satin covers with organza tie bow ribbons.',
    specs: 'High-density foam | Rust-proof chrome frame | Bow ribbon choices',
    image: banquetChairsImg,
    isPopular: false,
  },
  {
    id: 'table-round-dining',
    name: 'Round 5ft Dining Tables with Linen & Frill',
    teluguName: 'రౌండ్ డైనింగ్ టేబుల్స్',
    category: 'Tables',
    pricePerDay: 180,
    unit: 'per table / day',
    description: 'Seats 6 to 8 guests comfortably. Furnished with double layered floor-length pleated tablecloth and contrasting runner overlay.',
    specs: 'Diameter: 5 ft (60 inch) | Heavy plywood top with folding steel legs',
    image: banquetChairsImg,
    isPopular: true,
  },
  {
    id: 'table-buffet-rect',
    name: '6ft Heavy Buffet & Food Counter Tables',
    teluguName: 'బఫే కౌంటర్ టేబుల్స్',
    category: 'Tables',
    pricePerDay: 150,
    unit: 'per table / day',
    description: 'Sturdy long banquet buffet tables with clean spill-proof covers and pleated skirt panels, ideal for hot chafing dish presentation.',
    specs: 'Length: 6 ft x 2.5 ft width | Supports up to 250kg weight',
    image: banquetChairsImg,
    isPopular: false,
  },
  {
    id: 'stage-royal-mandap',
    name: 'Royal Reception Stage & Wedding Mandap Setup',
    teluguName: 'రాయల్ స్టేజ్ & కళ్యాణ మండపం',
    category: 'Stage',
    pricePerDay: 18500,
    unit: 'per setup / day',
    description: 'Complete 30x16 ft elevated wooden platform with red royal carpeting, carved golden pillars, floral arch background, and spotlight rigging.',
    specs: 'Modular height: 1.5 ft to 3 ft | Includes 2 ceremonial sofa thrones & stage steps',
    image: royalStageImg,
    isPopular: true,
  },
  {
    id: 'stage-vip-sofa',
    name: 'Handcrafted Golden Maharaja Stage Sofa',
    teluguName: 'మహారాజా సోఫా సెట్',
    category: 'Stage',
    pricePerDay: 2500,
    unit: 'per pair / day',
    description: 'Exquisite 3-seater bride & groom throne sofa finished in antique gold foil leafing with deep maroon velvet button tufting.',
    specs: 'Solid teakwood frame | High-resilience latex foam | 2 matching accent side stools',
    image: royalStageImg,
    isPopular: false,
  },
  {
    id: 'lighting-crystal-chandelier',
    name: 'Grand Crystal Chandeliers & Warm LED Matrix',
    teluguName: 'క్రిస్టల్ షాండ్లియర్స్ & లైటింగ్',
    category: 'Lighting',
    pricePerDay: 3500,
    unit: 'set of 4 chandeliers / day',
    description: 'Stunning faceted crystal chandeliers with warm golden LED filament bulbs, dimmable control, and ceiling truss hanging chains.',
    specs: 'Diameter: 3 ft each | Warm White 2700K | Low heat emission LED',
    image: heroTentImg,
    isPopular: true,
  },
  {
    id: 'lighting-focus-par',
    name: 'RGBW Stage Focus Par & Halogen Floodlights',
    teluguName: 'స్టేజ్ పార్ లైట్లు & ఫ్లడ్ లైట్లు',
    category: 'Lighting',
    pricePerDay: 2200,
    unit: 'pack of 8 fixtures / day',
    description: 'High-power 54x3W LED stage wash pars with DMX controller for ambient color mixing, plus outdoor LED floodlights for parking & walkways.',
    specs: 'Includes cabling, DMX console, tripod stands, and circuit breaker panel',
    image: heroTentImg,
    isPopular: false,
  },
  {
    id: 'sound-pro-audio',
    name: 'JBL Professional Line-Array Sound & Wireless Mics',
    teluguName: 'సౌండ్ సిస్టమ్ & మైక్స్',
    category: 'Sound',
    pricePerDay: 6500,
    unit: 'per event day',
    description: 'Crystal-clear audio coverage for 100 to 1,500 guests. Includes 2 top speakers, 2 subwoofers, digital mixer, Bluetooth, and 4 UHF wireless microphones.',
    specs: 'Total 4000W RMS | Feedback suppression | Dedicated audio sound technician included',
    image: heroTentImg,
    isPopular: true,
  },
  {
    id: 'utensils-catering-set',
    name: 'Stainless Steel Catering & Chafing Dish Set',
    teluguName: 'స్టీల్ వంట పాత్రలు & బఫే సెట్',
    category: 'Utensils',
    pricePerDay: 4000,
    unit: 'complete set (500 guest cap) / day',
    description: 'Hygienic 304-grade stainless steel roll-top chafing warmers, huge biryani degchas, serving spoons, water dispensers, and dinner plate racks.',
    specs: '8 chafing dishes + 4 giant cooking vessels + 500 melamine dinner plates & glasses',
    image: banquetChairsImg,
    isPopular: false,
  },
  {
    id: 'cooling-jumbo-cooler',
    name: 'High-Velocity Jumbo Desert Coolers',
    teluguName: 'జంబో ఎయిర్ కూలర్స్',
    category: 'Cooling',
    pricePerDay: 800,
    unit: 'per cooler / day',
    description: 'Powerful outdoor heavy-duty cooling fans with honeycomb cooling pads and 120-liter water reservoirs. Keeps guests cool during daytime ceremonies.',
    specs: 'Air throw: 50 feet | Auto-swing louvers | Silent industrial motor',
    image: germanTentImg,
    isPopular: true,
  },
  {
    id: 'cooling-misting-fan',
    name: 'High-Pressure Outdoor Water Misting Fans',
    teluguName: 'మిస్టింగ్ ఫ్యాన్స్',
    category: 'Cooling',
    pricePerDay: 1200,
    unit: 'per fan / day',
    description: 'Centrifugal ultra-fine misting technology drops ambient outdoor tent temperature by up to 8°C without wetting clothes.',
    specs: 'Coverage: 400 sq.ft | 3-speed heavy oscillation | Built-in water tank',
    image: germanTentImg,
    isPopular: false,
  }
];

export interface EventService {
  id: string;
  title: string;
  teluguTitle: string;
  subtitle: string;
  description: string;
  recommendedSetup: string[];
  capacity: string;
  image: string;
}

export const EVENT_SERVICES: EventService[] = [
  {
    id: 'weddings',
    title: 'Royal Weddings & Receptions',
    teluguTitle: 'రాయల్ పెళ్లిళ్లు & రిసెప్షన్స్',
    subtitle: 'From grand mandap architecture to lavish dining shamianas',
    description: 'We orchestrate end-to-end wedding infrastructure with opulent floral mandaps, air-cooled guest lounges, royal gold chiavari chairs, and ambient chandelier lighting that creates memories for a lifetime.',
    recommendedSetup: [
      'Grand German Hangar Tent or Maroon Velvet Shamiana',
      'Handcrafted Golden Maharaja Bride & Groom Stage',
      'VIP Chiavari Seating & 5ft Round Banqueting Tables',
      'Crystal Chandeliers & Ambient Warm Stage Lighting'
    ],
    capacity: '250 to 5,000+ Guests',
    image: royalStageImg,
  },
  {
    id: 'birthdays',
    title: 'Birthdays & Family Milestones',
    teluguTitle: 'పుట్టినరోజు & కుటుంబ వేడుకలు',
    subtitle: 'Vibrant, joyous and customized thematic setups',
    description: 'Whether it is a first birthday, half-saree celebration, or a 60th Shashti Poorthi, we provide colorful stage backdrops, balloon & flower trusses, comfortable seating, sound setup, and party lighting.',
    recommendedSetup: [
      'Custom Backdrop Theme with Name Monogram',
      'Surround Sound Audio System with DJ Console',
      'Compact Pagoda Canopy for Cake Cutting Area',
      'Cushioned Banqueting Chairs with Satin Covers'
    ],
    capacity: '50 to 800 Guests',
    image: banquetChairsImg,
  },
  {
    id: 'religious',
    title: 'Religious Functions & Cultural Poojas',
    teluguTitle: 'మతపరమైన పూజలు & సాంస్కృతిక ఉత్సవాలు',
    subtitle: 'Respectful, serene, and spacious arrangements',
    description: 'Specialized arrangements for Temple Brahmotsavams, Ganapathi & Devi Navaratri Pandals, Milad-un-Nabi, Christmas carols, and community Annadanam meal distribution with weather-proof coverage.',
    recommendedSetup: [
      'All-Weather Fire-Retardant German Waterproof Tent',
      'Traditional Cloth Ceilings & Red Carpet Walkways',
      'Heavy Stainless Steel Bulk Cooking Utensils',
      'High-Throw Horn & Box Sound Speakers'
    ],
    capacity: '500 to 10,000+ Devotees',
    image: germanTentImg,
  },
  {
    id: 'corporate',
    title: 'Corporate Events & Public Expos',
    teluguTitle: 'కార్పొరేట్ మీటింగ్స్ & ఎగ్జిబిషన్స్',
    subtitle: 'Sleek, orderly, and executive-grade production',
    description: 'Professional setup for product launches, ground-breaking ceremonies, annual shareholder meets, and commercial expos with clean modular layouts, stage audio-visuals, and branded signage stands.',
    recommendedSetup: [
      'Spacious Pagoda & Exhibition Stalls',
      'Professional Line-Array JBL Audio & Podium Mics',
      'Heavy-Duty Industrial Floor Carpeting',
      'Executive Velvet Chairs and Reception Desks'
    ],
    capacity: '100 to 3,000 Delegates',
    image: heroTentImg,
  }
];

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  location: string;
  image: string;
  description: string;
}

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Grand Palace Lawn Wedding Reception',
    category: 'Weddings',
    location: 'NTR Stadium Grounds, Guntur',
    image: heroTentImg,
    description: 'A 2,500 guest celebration featuring our 40x120 ft Velvet Shamiana with 8 crystal chandeliers.'
  },
  {
    id: 'gal-2',
    title: 'Waterproof German Pagoda Tent Setup',
    category: 'Tents',
    location: 'Amaravathi Road Convention Lawn',
    image: germanTentImg,
    description: 'Monsoon-proof all-weather hangar tent structure keeping guests comfortable and dry.'
  },
  {
    id: 'gal-3',
    title: 'Royal Mandap & Floral Carved Stage',
    category: 'Stage',
    location: 'Hotel Grand Nagarjuna Hall',
    image: royalStageImg,
    description: 'Handcrafted golden pillars with fresh marigold and jasmine garlands and dual Maharaja thrones.'
  },
  {
    id: 'gal-4',
    title: 'VIP Banquet Dining & Golden Chiavari Chairs',
    category: 'Chairs',
    location: 'Kalyana Mandapam, Guntur',
    image: banquetChairsImg,
    description: 'Intimate 500-seat banqueting layout with satin table runners and centerpieces.'
  },
  {
    id: 'gal-5',
    title: 'Evening Chandelier & Ambient Lighting',
    category: 'Lighting',
    location: 'Private Villa Estate, Vijayawada Highway',
    image: heroTentImg,
    description: 'Fairy light ceiling canopy with 2700K warm glow for an unforgettable sangeet night.'
  },
  {
    id: 'gal-6',
    title: 'Annadanam & Mega Community Feast Setup',
    category: 'Utensils',
    location: 'Sri Venkateswara Swamy Temple Grounds',
    image: banquetChairsImg,
    description: 'Catering lines, stainless steel hot-buffet vessels, and seated dining arrangement for 4,000 visitors.'
  }
];

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  eventType: string;
  comment: string;
  rating: number;
  date: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Chandra Sekhar Rao',
    role: 'Bride\'s Father',
    location: 'Brodipet, Guntur',
    eventType: 'Daughter\'s Wedding (1,800 Guests)',
    comment: 'Karimulla Tent House delivered beyond our highest expectations! The German waterproof tent stood firm even with a sudden passing drizzle, and the gold chiavari chairs gave our reception hall a royal palace feel. Karimulla garu was present personally to oversee every detail.',
    rating: 5,
    date: 'February 2026'
  },
  {
    id: 'test-2',
    name: 'Syed Mansoor Ali',
    role: 'Event Coordinator',
    location: 'Pattabhipuram, Guntur',
    eventType: 'Grand Nikah Ceremony & Valima',
    comment: 'Most reliable tent house in the district. Their team arrived 14 hours ahead of schedule, set up the complete velvet shamiana and crystal chandeliers flawlessly, and the sound clarity was crystal clear. Highly recommended for any serious event.',
    rating: 5,
    date: 'January 2026'
  },
  {
    id: 'test-3',
    name: 'K. Lakshmi Narayana',
    role: 'Managing Trustee',
    location: 'Old Guntur',
    eventType: 'Annual Temple Brahmotsavam (5 Days)',
    comment: 'For the last 8 consecutive years, we have entrusted Karimulla Tent House with our 5-day temple festival. From stage setup to 3,000 chairs and giant cooking degchas, their equipment is pristine and their prices are very reasonable.',
    rating: 5,
    date: 'November 2025'
  },
  {
    id: 'test-4',
    name: 'P. V. Ramana Murthy',
    role: 'Business Owner',
    location: 'Autonagar, Guntur',
    eventType: 'Corporate Expo & Factory Opening',
    comment: 'Spotless white German tents, punctual setup, and cordial staff. The client was thoroughly impressed by the cleanliness of the linens and chairs. Karimulla Tent House is our go-to partner for all corporate events.',
    rating: 5,
    date: 'December 2025'
  }
];

export interface TimelineStep {
  step: string;
  title: string;
  subtitle: string;
  description: string;
}

export const HOW_IT_WORKS_STEPS: TimelineStep[] = [
  {
    step: '01',
    title: 'Select Your Items or Package',
    subtitle: 'Browse & Choose Equipment',
    description: 'Browse our catalog of shamianas, German tents, royal chairs, tables, sound, and lighting. Pick items individually or ask for a custom event package.'
  },
  {
    step: '02',
    title: 'Instant Quote & Date Booking',
    subtitle: 'Direct WhatsApp Confirmation',
    description: 'Submit your requirements via WhatsApp or call Karimulla garu directly. We provide a transparent itemized quotation and lock your event dates immediately.'
  },
  {
    step: '03',
    title: 'Punctual Delivery & Expert Setup',
    subtitle: 'Trained Crew On-Site',
    description: 'Our experienced team arrives hours in advance to erect the canopies, arrange furniture, set up lighting, and test audio so your venue is ready well before guests arrive.'
  },
  {
    step: '04',
    title: 'Seamless Teardown & Pickup',
    subtitle: 'Zero Hassle for You',
    description: 'Once your celebration wraps up, our crew quietly dismantles the setup and clears the premises, leaving the venue clean and stress-free for your family.'
  }
];
