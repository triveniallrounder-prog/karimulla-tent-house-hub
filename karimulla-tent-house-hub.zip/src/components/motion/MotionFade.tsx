import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';

interface MotionFadeUpProps extends HTMLMotionProps<'div'> {
  delay?: number;
  duration?: number;
  yOffset?: number;
  className?: string;
  children: React.ReactNode;
}

/**
 * Reusable Framer Motion entrance animation component.
 * Slides up and fades in dynamically as the element scrolls into view.
 */
export const MotionFadeUp: React.FC<MotionFadeUpProps> = ({
  children,
  delay = 0,
  duration = 0.6,
  yOffset = 30,
  className = '',
  ...props
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: yOffset }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
};

/**
 * Reusable Motion wrapper specifically tuned for section headings (badge, title, subtitle).
 */
export const MotionHeading: React.FC<MotionFadeUpProps> = ({
  children,
  delay = 0.05,
  className = '',
  ...props
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 25 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
};

/**
 * Reusable Motion wrapper for section containers (grids, cards, forms, carousels).
 */
export const MotionContainer: React.FC<MotionFadeUpProps> = ({
  children,
  delay = 0.15,
  className = '',
  ...props
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
};
