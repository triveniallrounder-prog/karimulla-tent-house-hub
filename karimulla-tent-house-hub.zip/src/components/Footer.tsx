import React from 'react';
import { 
  Building2, 
  ArrowRight, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Instagram,
  Facebook,
  Youtube
} from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { useSiteData } from '../context/SiteDataContext';

interface FooterProps {
  onSwitchToRealEstate: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSwitchToRealEstate }) => {
  const { siteData } = useSiteData();
  const settings = siteData?.settings;

  const siteName = settings?.siteName || BUSINESS_DETAILS.name;
  const siteNameTelugu = settings?.siteNameTelugu || BUSINESS_DETAILS.nameTelugu;
  const taglineTelugu = settings?.taglineTelugu || BUSINESS_DETAILS.taglineTelugu;
  const phone1 = settings?.phone1 || BUSINESS_DETAILS.phone1;
  const phone1Raw = settings?.phone1Raw || BUSINESS_DETAILS.phone1Raw;
  const phone2 = settings?.phone2 || BUSINESS_DETAILS.phone2;
  const phone2Raw = settings?.phone2Raw || BUSINESS_DETAILS.phone2Raw;
  const email = settings?.email || 'karimullatents@gmail.com';
  const addressEnglish = settings?.addressEnglish || BUSINESS_DETAILS.addressEnglish;
  const footerText = settings?.footerText || `© ${new Date().getFullYear()} ${siteName}. All Rights Reserved.`;
  return (
    <footer className="bg-[#1C0105] text-neutral-300 pt-16 pb-24 lg:pb-12 border-t-2 border-[#D4AF37]/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Prominent Cross-Promotion Banner: Karimulla Real Estate with exact line */}
        <div className="mb-14 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950/90 via-emerald-900/80 to-[#2A0208] border border-emerald-400/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-14 h-14 rounded-2xl bg-emerald-800/80 border border-emerald-400/50 flex items-center justify-center text-emerald-200 shrink-0 shadow-lg">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[11px] uppercase tracking-widest text-emerald-300 font-bold">
                Sister Business Venture
              </span>
              <h3 className="font-telugu text-xl sm:text-2xl font-bold text-white mt-0.5">
                {BUSINESS_DETAILS.realEstateLabelTelugu} <span className="font-sans text-sm font-semibold opacity-90">({BUSINESS_DETAILS.realEstateLabelEnglish})</span>
              </h3>
              <p className="font-telugu text-xs sm:text-sm text-emerald-100 mt-1 max-w-2xl leading-relaxed">
                &ldquo;{BUSINESS_DETAILS.realEstateLineTelugu}&rdquo;
              </p>
            </div>
          </div>

          <button
            onClick={onSwitchToRealEstate}
            className="btn-premium btn-shine flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-xl shadow-emerald-950/50 border border-emerald-300 shrink-0 cursor-pointer"
          >
            <span className="font-telugu">{BUSINESS_DETAILS.realEstateLabelTelugu} వెబ్‌సైట్</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4-Column Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-white/10 text-xs sm:text-sm">
          
          {/* Column 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 text-white">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#E5C158] to-[#B8860B] flex items-center justify-center text-[#3E030B] font-bold text-base font-serif">
                K
              </div>
              <div className="leading-tight">
                <span className="font-telugu text-base font-bold tracking-tight text-white block">
                  {BUSINESS_DETAILS.nameTelugu}
                </span>
                <span className="font-sans text-xs text-neutral-300 block">
                  {BUSINESS_DETAILS.name}
                </span>
              </div>
            </div>

            <p className="font-telugu text-neutral-300 leading-relaxed text-xs">
              &ldquo;{BUSINESS_DETAILS.taglineTelugu}&rdquo;
            </p>

            <p className="font-sans text-neutral-400 text-xs">
              Tents, Chairs, Tables, Stage Decoration & Cooking Utensils on Rental in Guntur.
            </p>

            <div className="flex items-center gap-3 pt-1">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li><a href="#home" className="hover:text-[#F3DE8A] transition-colors">Home Page</a></li>
              <li><a href="#our-items" className="hover:text-[#F3DE8A] transition-colors font-medium text-amber-200/90">Our Items (మా సామాగ్రి 13)</a></li>
              <li><a href="#items-menu" className="hover:text-[#F3DE8A] transition-colors">Items Menu (సామాగ్రి జాబితా)</a></li>
              <li><a href="#about" className="hover:text-[#F3DE8A] transition-colors">About Our 22-Yr Journey</a></li>
              <li><a href="#items" className="hover:text-[#F3DE8A] transition-colors">Rental Items Catalog</a></li>
              <li><a href="#services" className="hover:text-[#F3DE8A] transition-colors">Wedding & Event Packages</a></li>
              <li><a href="#gallery" className="hover:text-[#F3DE8A] transition-colors">Photo Gallery & Stages</a></li>
              <li><a href="#contact" className="hover:text-[#F3DE8A] transition-colors">Booking & Quotations</a></li>
            </ul>
          </div>

          {/* Column 3: Popular Inventory Rentals */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider">
              Popular Rentals
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li><a href="#items-menu" className="hover:text-[#F3DE8A] transition-colors">డబ్బాలు (Dabbalu / 5kg - 70kg)</a></li>
              <li><a href="#items-menu" className="hover:text-[#F3DE8A] transition-colors">టెంట్లు (Water Proof Tents)</a></li>
              <li><a href="#items-menu" className="hover:text-[#F3DE8A] transition-colors">గ్యాస్ స్టవ్ & స్టౌ బిళ్లలు</a></li>
              <li><a href="#items-menu" className="hover:text-[#F3DE8A] transition-colors">బెంచీలు & కుర్చీలు</a></li>
              <li><a href="#items-menu" className="hover:text-[#F3DE8A] transition-colors">లైటింగ్లు & ఫ్యాన్లు</a></li>
              <li><a href="#items" className="hover:text-[#F3DE8A] transition-colors">రాయల్ వెల్వెట్ షామియానా</a></li>
              <li><a href="#items" className="hover:text-[#F3DE8A] transition-colors">గోల్డెన్ కియవారి చైర్స్</a></li>
            </ul>
          </div>

          {/* Column 4: Contact & Hours with Exact Owner and Phones */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm font-bold text-white uppercase tracking-wider">
              Direct Contact
            </h4>
            <div className="space-y-2.5 text-neutral-400">
              <div>
                <p className="font-telugu text-white font-bold text-sm">
                  {BUSINESS_DETAILS.ownerTelugu}
                </p>
                <p className="text-xs text-neutral-400">
                  {BUSINESS_DETAILS.ownerEnglish}
                </p>
              </div>

              {/* Both Phones as tap-to-call links */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#E5C158] shrink-0" />
                  <a href={`tel:+${phone1Raw}`} className="hover:text-white transition-colors font-mono font-semibold">
                    {phone1}
                  </a>
                </div>
                {phone2 && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#E5C158] shrink-0" />
                    <a href={`tel:+${phone2Raw}`} className="hover:text-white transition-colors font-mono font-semibold">
                      {phone2}
                    </a>
                  </div>
                )}
                {email && (
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-[#E5C158] shrink-0" />
                    <a href={`mailto:${email}`} className="hover:text-white transition-colors text-xs font-mono">
                      {email}
                    </a>
                  </div>
                )}
              </div>

              <div className="flex items-start gap-2 pt-1 border-t border-white/10">
                <MapPin className="w-3.5 h-3.5 text-[#E5C158] shrink-0 mt-0.5" />
                <div>
                  <span className="font-telugu text-white text-xs block">
                    {BUSINESS_DETAILS.addressTelugu}
                  </span>
                  <span className="text-[11px] text-neutral-400 block mt-0.5">
                    {BUSINESS_DETAILS.addressEnglish}
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-[#E5C158] shrink-0 mt-0.5" />
                <span>Open Everyday: 7:00 AM – 10:00 PM</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Copyright & Sister Business Credit */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <p>
            {footerText}
          </p>

          <div className="flex items-center gap-4">
            <button
              onClick={onSwitchToRealEstate}
              className="text-[#E5C158] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>{BUSINESS_DETAILS.realEstateLabelTelugu} (Karimulla Real Estate)</span>
            </button>
            <span className="hidden sm:inline">·</span>
            <span className="font-telugu">గుంటూరు</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
