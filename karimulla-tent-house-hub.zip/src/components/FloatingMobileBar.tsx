import React from 'react';
import { Phone, MessageCircle, ShoppingBag } from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';

interface FloatingMobileBarProps {
  quoteCount: number;
  onOpenQuoteBasket: () => void;
}

export const FloatingMobileBar: React.FC<FloatingMobileBarProps> = ({
  quoteCount,
  onOpenQuoteBasket,
}) => {
  const whatsappUrl = `https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(
    'Hello Karimulla garu, I need tent house rental assistance for an event.'
  )}`;

  return (
    <aside aria-label="Mobile quick actions" className="sm:hidden fixed bottom-3 left-3 right-3 z-30 pointer-events-none">
      <div className="flex items-center gap-2 justify-end pointer-events-auto">
        
        {/* Quote Basket Floating Button (if items chosen) */}
        {quoteCount > 0 && (
          <button
            onClick={onOpenQuoteBasket}
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-full bg-[#38030B] text-[#F3DE8A] border border-[#D4AF37] shadow-xl text-xs font-bold active:scale-95 transition-transform"
            aria-label={`View quote basket with ${quoteCount} items`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="bg-[#9E1B32] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-mono">
              {quoteCount}
            </span>
          </button>
        )}

        {/* Call Now Button */}
        <a
          href={`tel:+${BUSINESS_DETAILS.phone1Raw}`}
          className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] shadow-xl text-xs font-bold active:scale-95 transition-transform border border-amber-200"
          aria-label="Call Karimulla"
        >
          <Phone className="w-4 h-4" />
          <span>Call</span>
        </a>

        {/* WhatsApp Button */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-[#25D366] text-white shadow-xl text-xs font-bold active:scale-95 transition-transform border border-emerald-400"
          aria-label="Chat on WhatsApp"
        >
          <MessageCircle className="w-4 h-4 fill-current" />
          <span>WhatsApp</span>
        </a>

      </div>
    </aside>
  );
};
