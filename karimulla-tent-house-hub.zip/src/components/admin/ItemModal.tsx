import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Upload, Eye, EyeOff, Sparkles } from 'lucide-react';
import { ProductItem, SizeVariant } from '../../data/defaultSiteData';
import { compressImage } from '../../utils/imageCompressor';

interface ItemModalProps {
  isOpen: boolean;
  item: ProductItem | null;
  onSave: (savedItem: ProductItem) => void;
  onClose: () => void;
}

const PRESET_CATEGORIES = [
  'Catering & Utensils',
  'Tents & Canopies',
  'Seating & Furniture',
  'Lighting & Cooling',
  'Stage & Decoration',
  'Audio & Sound',
];

export const ItemModal: React.FC<ItemModalProps> = ({
  isOpen,
  item,
  onSave,
  onClose,
}) => {
  const [formData, setFormData] = useState<Partial<ProductItem>>({
    telugu: '',
    english: '',
    category: 'Catering & Utensils',
    categoryTelugu: 'వంటసామానులు',
    price: '',
    unit: 'per day',
    description: '',
    specs: '',
    badge: '',
    image: '',
    images: [],
    visible: true,
    hasDetails: true,
    sizes: [],
  });

  const [newSizeLabel, setNewSizeLabel] = useState('');
  const [newSizePrice, setNewSizePrice] = useState('');
  const [isCompressing, setIsCompressing] = useState(false);
  const [modalError, setModalError] = useState('');

  useEffect(() => {
    setModalError('');
    if (item) {
      setFormData({
        ...item,
        images: item.images || (item.image ? [item.image] : []),
        sizes: item.sizes ? [...item.sizes] : []
      });
    } else {
      setFormData({
        id: `item-${Date.now()}`,
        number: 99,
        telugu: '',
        english: '',
        category: 'Catering & Utensils',
        categoryTelugu: 'వంటసామానులు',
        price: '',
        unit: 'per day',
        description: '',
        specs: '',
        badge: '',
        image: '',
        images: [],
        visible: true,
        hasDetails: false,
        targetId: 'item-details-section',
        sizes: [],
      });
    }
    setNewSizeLabel('');
    setNewSizePrice('');
  }, [item, isOpen]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleToggleVisible = () => {
    setFormData((prev) => ({ ...prev, visible: !prev.visible }));
  };

  const handleAddSize = () => {
    if (!newSizeLabel.trim()) return;
    const newVariant: SizeVariant = {
      label: newSizeLabel.trim(),
      price: newSizePrice.trim(),
    };
    setFormData((prev) => ({
      ...prev,
      sizes: [...(prev.sizes || []), newVariant],
      hasDetails: true
    }));
    setNewSizeLabel('');
    setNewSizePrice('');
  };

  const handleRemoveSize = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      sizes: (prev.sizes || []).filter((_, i) => i !== index)
    }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setModalError('');
    setIsCompressing(true);
    try {
      const compressedUrls: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const compressed = await compressImage(files[i]);
        compressedUrls.push(compressed);
      }

      setFormData((prev) => {
        const existing = prev.images || [];
        const merged = [...existing, ...compressedUrls];
        return {
          ...prev,
          image: prev.image || merged[0],
          images: merged
        };
      });
    } catch (err) {
      console.error('Image compression failed:', err);
      setModalError('Could not compress image. Please try a different photo.');
    } finally {
      setIsCompressing(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.english?.trim() && !formData.telugu?.trim()) {
      setModalError('Please provide at least an English or Telugu title for the item.');
      return;
    }

    const finalItem: ProductItem = {
      id: formData.id || `item-${Date.now()}`,
      number: formData.number || 99,
      telugu: formData.telugu?.trim() || '',
      english: formData.english?.trim() || '',
      category: formData.category || 'Catering & Utensils',
      categoryTelugu: formData.categoryTelugu || 'వంటసామానులు',
      description: formData.description?.trim() || '',
      specs: formData.specs?.trim() || '',
      image: formData.image || (formData.images && formData.images[0]) || '',
      images: formData.images || [],
      price: formData.price?.trim() || '',
      unit: formData.unit?.trim() || 'per day',
      targetId: formData.targetId || 'item-details-section',
      hasDetails: (formData.sizes && formData.sizes.length > 0) || false,
      badge: formData.badge?.trim() || '',
      visible: formData.visible !== undefined ? formData.visible : true,
      sizes: formData.sizes || [],
    };

    onSave(finalItem);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#1C0206] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-white my-auto max-h-[92vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#F3DE8A]" />
              <span>{item ? 'Edit Rental Item' : 'Add New Rental Item'}</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Changes update immediately on the public website.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {modalError && (
            <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs">
              {modalError}
            </div>
          )}
          
          {/* Visibility Switch */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-black/40 border border-white/10">
            <div>
              <span className="text-xs font-bold text-white block">
                Public Website Visibility
              </span>
              <span className="text-[11px] text-neutral-400">
                {formData.visible ? 'Visible on catalog and items menu' : 'Hidden from public visitors (draft)'}
              </span>
            </div>
            <button
              type="button"
              onClick={handleToggleVisible}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                formData.visible
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              {formData.visible ? (
                <>
                  <Eye className="w-3.5 h-3.5" />
                  <span>Visible</span>
                </>
              ) : (
                <>
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>Hidden</span>
                </>
              )}
            </button>
          </div>

          {/* Titles (English & Telugu) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                English Name *
              </label>
              <input
                type="text"
                name="english"
                required
                placeholder="e.g. Waterproof German Tents"
                value={formData.english}
                onChange={handleChange}
                className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                తెలుగు పేరు (Telugu Name) *
              </label>
              <input
                type="text"
                name="telugu"
                required
                placeholder="ఉదా. వాటర్‌ప్రూఫ్ టెంట్లు"
                value={formData.telugu}
                onChange={handleChange}
                className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
              />
            </div>
          </div>

          {/* Category & Badge */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                Category
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              >
                {PRESET_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat} className="bg-neutral-900 text-white">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                Badge / Highlight Tag
              </label>
              <input
                type="text"
                name="badge"
                placeholder="e.g. 100% All-Weather Rainproof"
                value={formData.badge}
                onChange={handleChange}
                className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          </div>

          {/* Price & Unit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                Price (Optional / Leave empty for custom quote)
              </label>
              <input
                type="text"
                name="price"
                placeholder="e.g. ₹250 or Contact for Rate"
                value={formData.price}
                onChange={handleChange}
                className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                Pricing Unit
              </label>
              <input
                type="text"
                name="unit"
                placeholder="e.g. per drum / day or per tent"
                value={formData.unit}
                onChange={handleChange}
                className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          </div>

          {/* Description & Specifications */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
              Description
            </label>
            <textarea
              name="description"
              rows={2}
              placeholder="Detailed description of features, quality, and suitable events..."
              value={formData.description}
              onChange={handleChange}
              className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
              Specifications Note
            </label>
            <input
              type="text"
              name="specs"
              placeholder="e.g. Heavy-gauge stainless steel with lid"
              value={formData.specs}
              onChange={handleChange}
              className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          {/* Image Upload & Preview */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-2">
              Item Images (Upload with auto-compression)
            </label>

            <div className="flex flex-wrap items-center gap-3">
              {formData.images && formData.images.map((imgUrl, idx) => (
                <div key={idx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-white/20 group">
                  <img src={imgUrl} alt="Item" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => {
                      const updated = (formData.images || []).filter((_, i) => i !== idx);
                      setFormData((prev) => ({
                        ...prev,
                        images: updated,
                        image: updated[0] || ''
                      }));
                    }}
                    className="absolute top-1 right-1 p-1 rounded-full bg-black/70 text-rose-300 hover:text-rose-100 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                  {idx === 0 && (
                    <span className="absolute bottom-0 left-0 right-0 bg-[#D4AF37] text-[#240106] text-[9px] font-bold text-center">
                      Main
                    </span>
                  )}
                </div>
              ))}

              <label className="w-20 h-20 rounded-xl border-2 border-dashed border-[#D4AF37]/50 hover:border-[#D4AF37] flex flex-col items-center justify-center p-2 text-center text-neutral-400 hover:text-[#F3DE8A] transition-colors cursor-pointer bg-white/5">
                <Upload className="w-5 h-5 mb-1" />
                <span className="text-[10px] font-semibold">{isCompressing ? 'Working...' : 'Upload'}</span>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isCompressing}
                  className="hidden"
                />
              </label>
            </div>
            <p className="text-[11px] text-neutral-400 mt-1.5">
              Photos are automatically compressed to lightweight web formats without sacrificing clarity.
            </p>
          </div>

          {/* Size Variants Builder */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Size Variants & Specific Capacities (Optional)
            </span>

            {/* List of existing sizes */}
            {formData.sizes && formData.sizes.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {formData.sizes.map((s, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/10 border border-white/15 text-xs text-white"
                  >
                    <strong>{s.label}</strong>
                    {s.price && <span className="text-[#F3DE8A]">({s.price})</span>}
                    <button
                      type="button"
                      onClick={() => handleRemoveSize(idx)}
                      className="text-neutral-400 hover:text-rose-300 ml-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-neutral-500 italic">No specific sizes added yet (e.g. 70kg, 60kg, 30x15).</p>
            )}

            {/* Add Size row */}
            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                placeholder="Size label (e.g. 50 kgs or 30 × 15)"
                value={newSizeLabel}
                onChange={(e) => setNewSizeLabel(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              />
              <input
                type="text"
                placeholder="Price (Optional)"
                value={newSizePrice}
                onChange={(e) => setNewSizePrice(e.target.value)}
                className="w-28 px-3 py-1.5 text-xs rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                type="button"
                onClick={handleAddSize}
                className="px-3 py-1.5 rounded-lg bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-white/10 hover:bg-white/15 text-neutral-300 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] shadow-lg transition-transform active:scale-95 cursor-pointer"
            >
              Save Item Changes
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
