import React, { useState } from 'react';
import { X, Upload, Star, Trash2, ArrowLeft, ArrowRight, Image as ImageIcon, Check } from 'lucide-react';
import { ProductItem } from '../../data/defaultSiteData';
import { compressImage } from '../../utils/imageCompressor';

interface ItemImagesModalProps {
  isOpen: boolean;
  item: ProductItem | null;
  onSaveImages: (itemId: string, images: string[], mainImage: string) => void;
  onClose: () => void;
}

export const ItemImagesModal: React.FC<ItemImagesModalProps> = ({
  isOpen,
  item,
  onSaveImages,
  onClose,
}) => {
  if (!isOpen || !item) return null;

  const [images, setImages] = useState<string[]>(() => {
    const list = item.images && item.images.length > 0 ? [...item.images] : [];
    if (item.image && !list.includes(item.image)) {
      list.unshift(item.image);
    }
    return list;
  });

  const [mainImage, setMainImage] = useState<string>(item.image || (images[0] || ''));
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadError('');
    setIsUploading(true);
    try {
      const compressedList: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const compressed = await compressImage(files[i]);
        compressedList.push(compressed);
      }

      setImages((prev) => {
        const updated = [...prev, ...compressedList];
        if (!mainImage && updated.length > 0) {
          setMainImage(updated[0]);
        }
        return updated;
      });
    } catch (err) {
      console.error('Failed to compress images:', err);
      setUploadError('Failed to process image. Please try another file.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = (index: number) => {
    const target = images[index];
    const updated = images.filter((_, i) => i !== index);
    setImages(updated);

    if (mainImage === target) {
      setMainImage(updated[0] || '');
    }
  };

  const handleSetMain = (url: string) => {
    setMainImage(url);
    // Bring main image to front
    const filtered = images.filter((img) => img !== url);
    setImages([url, ...filtered]);
  };

  const handleMove = (index: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= images.length) return;

    const copy = [...images];
    const temp = copy[index];
    copy[index] = copy[targetIndex];
    copy[targetIndex] = temp;
    setImages(copy);

    if (index === 0 || targetIndex === 0) {
      setMainImage(copy[0]);
    }
  };

  const handleSave = () => {
    onSaveImages(item.id, images, mainImage || images[0] || '');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-3xl bg-[#1C0206] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl text-white my-auto max-h-[90vh] overflow-y-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
          <div>
            <span className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold block">
              Multi-Image Gallery Manager
            </span>
            <h3 className="text-xl font-bold text-white flex items-center gap-2 mt-0.5">
              <ImageIcon className="w-5 h-5 text-[#F3DE8A]" />
              <span>{item.telugu} {item.english}</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {uploadError && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs">
            {uploadError}
          </div>
        )}

        {/* Upload Drop Zone */}
        <div className="mb-6">
          <label className="border-2 border-dashed border-[#D4AF37]/40 hover:border-[#D4AF37] rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center text-center cursor-pointer bg-white/5 hover:bg-white/10 transition-colors">
            <Upload className="w-8 h-8 text-[#F3DE8A] mb-2" />
            <span className="text-sm font-bold text-white">
              {isUploading ? 'Auto-Compressing Images...' : 'Click to Upload Multiple Photos'}
            </span>
            <span className="text-xs text-neutral-400 mt-1">
              Supports JPG, PNG, WEBP. Photos are automatically compressed to lightweight, high-performance web formats.
            </span>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleUpload}
              disabled={isUploading}
              className="hidden"
            />
          </label>
        </div>

        {/* Images Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
            <span>{images.length} Image{images.length === 1 ? '' : 's'} Uploaded</span>
            <span>⭐ Star sets main display image · ◀ ▶ arrows reorder</span>
          </div>

          {images.length === 0 ? (
            <div className="p-8 rounded-2xl bg-black/30 border border-white/5 text-center text-neutral-500 text-xs">
              No photos currently uploaded for this item. Upload above to add photos.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {images.map((imgUrl, idx) => {
                const isMain = mainImage === imgUrl || idx === 0;

                return (
                  <div
                    key={idx}
                    className={`relative rounded-2xl overflow-hidden border bg-neutral-900 shadow-md group transition-all ${
                      isMain ? 'border-[#D4AF37] ring-2 ring-[#D4AF37]/50' : 'border-white/10'
                    }`}
                  >
                    <div className="h-36 w-full overflow-hidden">
                      <img
                        src={imgUrl}
                        alt={`Item photo ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>

                    {/* Main Badge */}
                    {isMain && (
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-[#D4AF37] text-[#240106] text-[10px] font-extrabold flex items-center gap-1 shadow-md">
                        <Check className="w-3 h-3 stroke-[3]" />
                        <span>MAIN</span>
                      </span>
                    )}

                    {/* Overlay Action Bar */}
                    <div className="p-2 bg-[#120104]/90 border-t border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => handleMove(idx, 'left')}
                          className="p-1 rounded hover:bg-white/10 text-neutral-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
                          title="Move left"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === images.length - 1}
                          onClick={() => handleMove(idx, 'right')}
                          className="p-1 rounded hover:bg-white/10 text-neutral-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
                          title="Move right"
                        >
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-1">
                        {!isMain && (
                          <button
                            type="button"
                            onClick={() => handleSetMain(imgUrl)}
                            className="p-1 rounded hover:bg-white/10 text-neutral-400 hover:text-[#F3DE8A]"
                            title="Set as main display image"
                          >
                            <Star className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDelete(idx)}
                          className="p-1 rounded hover:bg-rose-500/20 text-neutral-400 hover:text-rose-300"
                          title="Delete photo"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 pt-6 border-t border-white/10 mt-6">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-white/10 hover:bg-white/15 text-neutral-300 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] shadow-lg transition-transform active:scale-95 cursor-pointer"
          >
            Apply Image Changes
          </button>
        </div>

      </div>
    </div>
  );
};
