import React, { useState, useMemo, useRef } from 'react';
import {
  LayoutDashboard,
  Package,
  UserCheck,
  Users,
  HeartHandshake,
  Settings,
  ShieldCheck,
  LogOut,
  Plus,
  Edit2,
  Trash2,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Download,
  Upload,
  FolderOpen,
  RefreshCw,
  Search,
  ExternalLink,
  Clock,
  Sparkles,
  Phone,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  Menu,
  X,
  Layers,
  Crown
} from 'lucide-react';
import { useAdminAuth } from '../../context/AdminAuthContext';
import { useSiteData } from '../../context/SiteDataContext';
import { ProductItem, Teammate, Partner } from '../../data/defaultSiteData';
import { ItemModal } from './ItemModal';
import { ItemImagesModal } from './ItemImagesModal';
import { ConfirmModal } from './ConfirmModal';
import { Toast, ToastMessage } from './Toast';
import { compressImage } from '../../utils/imageCompressor';

type AdminTab = 'overview' | 'items' | 'founder' | 'team' | 'partners' | 'settings' | 'backup';

interface AdminDashboardProps {
  onBackToSite: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToSite }) => {
  const {
    adminUser,
    sessionExpiresIn,
    configuredViaEnv,
    changePassword,
    logout,
    extendSession,
  } = useAdminAuth();
  const {
    siteData,
    updateItems,
    updateFounder,
    updateTeam,
    updatePartners,
    updatePartnership,
    updateSettings,
    importBackup,
    resetToDefaults,
  } = useSiteData();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Search and filter for items
  const [itemSearch, setItemSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [visibilityFilter, setVisibilityFilter] = useState('All');

  // Modals state
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ProductItem | null>(null);

  const [isImagesModalOpen, setIsImagesModalOpen] = useState(false);
  const [imageManagingItem, setImageManagingItem] = useState<ProductItem | null>(null);

  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  // Toast notifications
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const showToast = (type: 'success' | 'error' | 'info', text: string) => {
    setToast({ id: String(Date.now()), type, text });
  };

  // Teammate modal state
  const [editingTeammate, setEditingTeammate] = useState<Teammate | null>(null);
  const [isTeammateModalOpen, setIsTeammateModalOpen] = useState(false);

  // Partner modal state
  const [editingPartner, setEditingPartner] = useState<Partner | null>(null);
  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState(false);

  // Owner password change state
  const [currentPassInput, setCurrentPassInput] = useState('');
  const [newUserInput, setNewUserInput] = useState(adminUser || '');
  const [newPassInput, setNewPassInput] = useState('');
  const [confirmPassInput, setConfirmPassInput] = useState('');
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  // Chairman / Founder Files App upload state & ref
  const chairmanFileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingChairmanPhoto, setIsUploadingChairmanPhoto] = useState(false);
  const [isDraggingChairmanPhoto, setIsDraggingChairmanPhoto] = useState(false);

  // Format session time
  const formatSessionTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Filtered items list
  const filteredItems = useMemo(() => {
    return siteData.items.filter((item) => {
      const matchesSearch =
        !itemSearch ||
        item.english.toLowerCase().includes(itemSearch.toLowerCase()) ||
        item.telugu.includes(itemSearch) ||
        item.category.toLowerCase().includes(itemSearch.toLowerCase());

      const matchesCat = categoryFilter === 'All' || item.category === categoryFilter;
      const matchesVis =
        visibilityFilter === 'All' ||
        (visibilityFilter === 'Visible' && item.visible) ||
        (visibilityFilter === 'Hidden' && !item.visible);

      return matchesSearch && matchesCat && matchesVis;
    });
  }, [siteData.items, itemSearch, categoryFilter, visibilityFilter]);

  // Categories list
  const allCategories = useMemo(() => {
    const set = new Set<string>();
    siteData.items.forEach((it) => set.add(it.category));
    return ['All', ...Array.from(set)];
  }, [siteData.items]);

  // -------------------------------------------------------------
  // Item Actions
  // -------------------------------------------------------------
  const handleSaveItem = async (savedItem: ProductItem) => {
    let updatedList: ProductItem[] = [];
    const exists = siteData.items.some((i) => i.id === savedItem.id);

    if (exists) {
      updatedList = siteData.items.map((i) => (i.id === savedItem.id ? savedItem : i));
    } else {
      updatedList = [...siteData.items, savedItem];
    }

    const res = await updateItems(updatedList);
    if (res.success) {
      showToast('success', `Item "${savedItem.english || savedItem.telugu}" saved successfully.`);
      setIsItemModalOpen(false);
      setEditingItem(null);
    } else {
      showToast('error', res.error || 'Failed to save item.');
    }
  };

  const handleDeleteItem = (itemId: string, itemTitle: string) => {
    setConfirmModalState({
      isOpen: true,
      title: 'Delete Rental Item',
      message: `Are you sure you want to permanently delete "${itemTitle}" from your website inventory? This action is irreversible.`,
      action: async () => {
        const updated = siteData.items.filter((i) => i.id !== itemId);
        const res = await updateItems(updated);
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
        if (res.success) {
          showToast('success', `"${itemTitle}" was deleted.`);
        } else {
          showToast('error', res.error || 'Failed to delete item.');
        }
      },
    });
  };

  const handleToggleItemVisibility = async (itemId: string) => {
    const updated = siteData.items.map((it) =>
      it.id === itemId ? { ...it, visible: !it.visible } : it
    );
    const target = updated.find((i) => i.id === itemId);
    const res = await updateItems(updated);
    if (res.success) {
      showToast('success', `Item is now ${target?.visible ? 'Visible' : 'Hidden'} on website.`);
    }
  };

  const handleReorderItem = async (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= siteData.items.length) return;

    const copy = [...siteData.items];
    const temp = copy[index];
    copy[index] = copy[targetIndex];
    copy[targetIndex] = temp;

    // re-index numbers
    copy.forEach((it, idx) => {
      it.number = idx + 1;
    });

    const res = await updateItems(copy);
    if (res.success) {
      showToast('success', 'Items reordered successfully.');
    }
  };

  const handleSaveItemImages = async (itemId: string, images: string[], mainImage: string) => {
    const updated = siteData.items.map((it) =>
      it.id === itemId ? { ...it, images, image: mainImage } : it
    );
    const res = await updateItems(updated);
    if (res.success) {
      showToast('success', 'Item gallery updated successfully.');
    } else {
      showToast('error', res.error || 'Failed to update images.');
    }
  };

  // -------------------------------------------------------------
  // Founder Actions
  // -------------------------------------------------------------
  const handleSaveFounder = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);

    const updated = {
      ...siteData.founder,
      name: (fd.get('name') as string) || siteData.founder.name,
      nameTelugu: (fd.get('nameTelugu') as string) || siteData.founder.nameTelugu,
      title: (fd.get('title') as string) || siteData.founder.title,
      titleTelugu: (fd.get('titleTelugu') as string) || siteData.founder.titleTelugu,
      experienceYears: parseInt((fd.get('experienceYears') as string) || '22', 10),
      phone1: (fd.get('phone1') as string) || siteData.founder.phone1,
      phone1Raw: (fd.get('phone1') as string).replace(/\D/g, '') || siteData.founder.phone1Raw,
      phone2: (fd.get('phone2') as string) || siteData.founder.phone2,
      phone2Raw: (fd.get('phone2') as string).replace(/\D/g, '') || siteData.founder.phone2Raw,
      bio: (fd.get('bio') as string) || siteData.founder.bio,
      bioTelugu: (fd.get('bioTelugu') as string) || siteData.founder.bioTelugu,
      addressEnglish: (fd.get('addressEnglish') as string) || siteData.founder.addressEnglish,
      addressTelugu: (fd.get('addressTelugu') as string) || siteData.founder.addressTelugu,
      socialLinks: {
        instagram: (fd.get('instagram') as string) || '',
        facebook: (fd.get('facebook') as string) || '',
        whatsapp: (fd.get('whatsapp') as string) || '',
      },
    };

    const res = await updateFounder(updated);
    if (res.success) {
      showToast('success', 'Founder & Director profile updated.');
    } else {
      showToast('error', res.error || 'Failed to update founder details.');
    }
  };

  const processChairmanPhotoFile = async (file: File) => {
    if (!file.type.startsWith('image/') && !/\.(jpe?g|png|webp|gif|heic|avif)$/i.test(file.name)) {
      showToast('error', 'Please select a valid image file (JPG, PNG, WebP, or GIF) from your Files app.');
      return;
    }

    setIsUploadingChairmanPhoto(true);
    try {
      const compressed = await compressImage(file, { maxWidth: 800, maxHeight: 800 });
      const updated = {
        ...siteData.founder,
        photo: compressed,
        showPhoto: true,
      };
      const res = await updateFounder(updated);
      if (res.success) {
        showToast('success', 'Chairman photo uploaded from Files app and is now live!');
      } else {
        showToast('error', res.error || 'Failed to save Chairman photo.');
      }
    } catch {
      showToast('error', 'Could not process this image file. Please try JPG or PNG.');
    } finally {
      setIsUploadingChairmanPhoto(false);
    }
  };

  const handleFounderPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    await processChairmanPhotoFile(file);
  };

  const handleOpenFilesAppForChairman = async () => {
    const picker = (window as any).showOpenFilePicker;
    if (typeof picker === 'function') {
      try {
        const [fileHandle] = await picker({
          multiple: false,
          types: [
            {
              description: 'Image Files (JPG, PNG, WebP)',
              accept: {
                'image/*': ['.png', '.jpg', '.jpeg', '.webp', '.gif'],
              },
            },
          ],
        });
        if (fileHandle) {
          const file = await fileHandle.getFile();
          await processChairmanPhotoFile(file);
          return;
        }
      } catch (err: any) {
        // If user cancelled the native Files picker, do nothing; if iframe/security blocked, fall back to standard input
        if (err?.name === 'AbortError') return;
      }
    }
    chairmanFileInputRef.current?.click();
  };

  const handleRemoveFounderPhoto = async () => {
    const updated = {
      ...siteData.founder,
      photo: '',
      showPhoto: false,
    };
    const res = await updateFounder(updated);
    if (res.success) {
      showToast('success', 'Chairman photo removed. Switched back to Royal Crest.');
    } else {
      showToast('error', res.error || 'Failed to remove Chairman photo.');
    }
  };

  const handleToggleFounderPhotoDisplay = async () => {
    if (!siteData.founder.showPhoto && !siteData.founder.photo) {
      showToast('info', 'Please select a Chairman photo from your Files app first.');
      handleOpenFilesAppForChairman();
      return;
    }
    const updated = {
      ...siteData.founder,
      showPhoto: !siteData.founder.showPhoto,
    };
    const res = await updateFounder(updated);
    if (res.success) {
      showToast('success', `Chairman photo display is now ${updated.showPhoto ? 'Enabled' : 'Disabled (using royal crest)'}.`);
    } else {
      showToast('error', res.error || 'Failed to update display mode.');
    }
  };

  // -------------------------------------------------------------
  // Teammates Actions
  // -------------------------------------------------------------
  const handleSaveTeammate = async (teammate: Teammate) => {
    let updated: Teammate[];
    if (siteData.team.some((t) => t.id === teammate.id)) {
      updated = siteData.team.map((t) => (t.id === teammate.id ? teammate : t));
    } else {
      updated = [...siteData.team, teammate];
    }

    const res = await updateTeam(updated);
    if (res.success) {
      showToast('success', `Teammate "${teammate.name}" saved.`);
      setIsTeammateModalOpen(false);
      setEditingTeammate(null);
    }
  };

  const handleDeleteTeammate = (id: string, name: string) => {
    setConfirmModalState({
      isOpen: true,
      title: 'Remove Teammate',
      message: `Are you sure you want to remove "${name}" from the team roster?`,
      action: async () => {
        const updated = siteData.team.filter((t) => t.id !== id);
        const res = await updateTeam(updated);
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
        if (res.success) {
          showToast('success', `Removed "${name}".`);
        }
      },
    });
  };

  // -------------------------------------------------------------
  // Partners Actions
  // -------------------------------------------------------------
  const handleSavePartner = async (partner: Partner) => {
    let updated: Partner[];
    if (siteData.partners.some((p) => p.id === partner.id)) {
      updated = siteData.partners.map((p) => (p.id === partner.id ? partner : p));
    } else {
      updated = [...siteData.partners, partner];
    }

    const res = await updatePartners(updated);
    if (res.success) {
      showToast('success', `Partner "${partner.name}" saved.`);
      setIsPartnerModalOpen(false);
      setEditingPartner(null);
    }
  };

  const handleDeletePartner = (id: string, name: string) => {
    setConfirmModalState({
      isOpen: true,
      title: 'Remove Partner',
      message: `Are you sure you want to remove partner "${name}"?`,
      action: async () => {
        const updated = siteData.partners.filter((p) => p.id !== id);
        const res = await updatePartners(updated);
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
        if (res.success) {
          showToast('success', `Removed partner "${name}".`);
        }
      },
    });
  };

  // -------------------------------------------------------------
  // Settings Actions
  // -------------------------------------------------------------
  const handleSaveSettings = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);

    const updated = {
      ...siteData.settings,
      siteTitle: (fd.get('siteTitle') as string) || siteData.settings.siteTitle,
      siteName: (fd.get('siteName') as string) || siteData.settings.siteName,
      siteNameTelugu: (fd.get('siteNameTelugu') as string) || siteData.settings.siteNameTelugu,
      tagline: (fd.get('tagline') as string) || siteData.settings.tagline,
      taglineTelugu: (fd.get('taglineTelugu') as string) || siteData.settings.taglineTelugu,
      heroHeading: (fd.get('heroHeading') as string) || siteData.settings.heroHeading,
      heroSubheading: (fd.get('heroSubheading') as string) || siteData.settings.heroSubheading,
      phone1: (fd.get('phone1') as string) || siteData.settings.phone1,
      phone1Raw: (fd.get('phone1') as string).replace(/\D/g, '') || siteData.settings.phone1Raw,
      phone2: (fd.get('phone2') as string) || siteData.settings.phone2,
      phone2Raw: (fd.get('phone2') as string).replace(/\D/g, '') || siteData.settings.phone2Raw,
      email: (fd.get('email') as string) || siteData.settings.email,
      addressEnglish: (fd.get('addressEnglish') as string) || siteData.settings.addressEnglish,
      addressTelugu: (fd.get('addressTelugu') as string) || siteData.settings.addressTelugu,
      footerText: (fd.get('footerText') as string) || siteData.settings.footerText,
    };

    const res = await updateSettings(updated);
    if (res.success) {
      showToast('success', 'Website settings updated successfully.');
    } else {
      showToast('error', res.error || 'Failed to update settings.');
    }
  };

  // -------------------------------------------------------------
  // Backup & Restore Actions
  // -------------------------------------------------------------
  const handleExportBackup = () => {
    const jsonStr = JSON.stringify(siteData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `karimulla-tent-house-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('success', 'Backup JSON file downloaded.');
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (!parsed || !parsed.items || !parsed.settings) {
          throw new Error('Invalid backup file structure.');
        }

        setConfirmModalState({
          isOpen: true,
          title: 'Restore Database Backup',
          message: 'Restoring this backup will replace current inventory items, founder data, and website settings with the contents of the backup file. Proceed?',
          action: async () => {
            const res = await importBackup(parsed);
            setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
            if (res.success) {
              showToast('success', 'Backup successfully restored and live!');
            } else {
              showToast('error', res.error || 'Failed to restore backup.');
            }
          },
        });
      } catch (err: any) {
        showToast('error', 'Corrupted or invalid JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetToDefaults = () => {
    setConfirmModalState({
      isOpen: true,
      title: 'Reset to Factory Defaults',
      message: 'Are you sure you want to reset all site data to the initial factory seed? All custom additions will be reverted.',
      action: async () => {
        const res = await resetToDefaults();
        setConfirmModalState((prev) => ({ ...prev, isOpen: false }));
        if (res.success) {
          showToast('success', 'Site data restored to default settings.');
        }
      },
    });
  };

  return (
    <div className="min-h-screen bg-[#110104] text-neutral-100 flex flex-col font-sans selection:bg-[#7A1526] selection:text-white">
      
      {/* Toast Notification */}
      <Toast toast={toast} onClose={() => setToast(null)} />

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={confirmModalState.action}
        onCancel={() => setConfirmModalState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Item Edit Modal */}
      <ItemModal
        isOpen={isItemModalOpen}
        item={editingItem}
        onSave={handleSaveItem}
        onClose={() => {
          setIsItemModalOpen(false);
          setEditingItem(null);
        }}
      />

      {/* Item Images Modal */}
      <ItemImagesModal
        isOpen={isImagesModalOpen}
        item={imageManagingItem}
        onSaveImages={handleSaveItemImages}
        onClose={() => {
          setIsImagesModalOpen(false);
          setImageManagingItem(null);
        }}
      />

      {/* Teammate Edit Modal */}
      {isTeammateModalOpen && editingTeammate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#1C0206] border border-[#D4AF37]/30 rounded-3xl p-6 shadow-2xl text-white">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <h3 className="text-lg font-bold">Edit Teammate</h3>
              <button
                type="button"
                onClick={() => {
                  setIsTeammateModalOpen(false);
                  setEditingTeammate(null);
                }}
                className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveTeammate(editingTeammate);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editingTeammate.name}
                  onChange={(e) => setEditingTeammate({ ...editingTeammate, name: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Role / Designation</label>
                <input
                  type="text"
                  required
                  value={editingTeammate.role}
                  onChange={(e) => setEditingTeammate({ ...editingTeammate, role: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editingTeammate.phone}
                  onChange={(e) => setEditingTeammate({ ...editingTeammate, phone: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Details</label>
                <textarea
                  rows={2}
                  value={editingTeammate.details}
                  onChange={(e) => setEditingTeammate({ ...editingTeammate, details: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setIsTeammateModalOpen(false);
                    setEditingTeammate(null);
                  }}
                  className="px-4 py-2 text-xs rounded-xl bg-white/10 hover:bg-white/15 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] cursor-pointer"
                >
                  Save Teammate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Partner Edit Modal */}
      {isPartnerModalOpen && editingPartner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#1C0206] border border-[#D4AF37]/30 rounded-3xl p-6 shadow-2xl text-white">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <h3 className="text-lg font-bold">Edit Partner</h3>
              <button
                type="button"
                onClick={() => {
                  setIsPartnerModalOpen(false);
                  setEditingPartner(null);
                }}
                className="p-1 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSavePartner(editingPartner);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Partner Name</label>
                <input
                  type="text"
                  required
                  value={editingPartner.name}
                  onChange={(e) => setEditingPartner({ ...editingPartner, name: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Brand / Specialty</label>
                <input
                  type="text"
                  required
                  value={editingPartner.brand}
                  onChange={(e) => setEditingPartner({ ...editingPartner, brand: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editingPartner.phone}
                  onChange={(e) => setEditingPartner({ ...editingPartner, phone: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Website URL (Optional)</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={editingPartner.website || ''}
                  onChange={(e) => setEditingPartner({ ...editingPartner, website: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Details</label>
                <textarea
                  rows={2}
                  value={editingPartner.details || ''}
                  onChange={(e) => setEditingPartner({ ...editingPartner, details: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setIsPartnerModalOpen(false);
                    setEditingPartner(null);
                  }}
                  className="px-4 py-2 text-xs rounded-xl bg-white/10 hover:bg-white/15 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] cursor-pointer"
                >
                  Save Partner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TOP APP BAR */}
      <header className="sticky top-0 z-40 bg-[#1A0206]/95 backdrop-blur-md border-b border-[#D4AF37]/25 px-4 sm:px-6 py-3 flex items-center justify-between">
        
        {/* Brand & Mobile Hamburger */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 rounded-lg bg-white/10 text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#7A1526] to-[#4A040F] border border-[#D4AF37] flex items-center justify-center text-[#F3DE8A] shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="font-serif text-base sm:text-lg font-bold text-white leading-tight block">
                Karimulla Tent House
              </span>
              <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-semibold block">
                Admin Console · Live Production
              </span>
            </div>
          </div>
        </div>

        {/* Status Indicators & Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* 30-Minute Inactivity Auto-Logout Badge */}
          <div
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-mono font-bold ${
              sessionExpiresIn <= 120
                ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse'
                : 'bg-black/40 border-[#D4AF37]/30 text-[#F3DE8A]'
            }`}
            title="Session automatically logs out after 30 minutes of inactivity"
          >
            <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Auto-Logout: {formatSessionTime(sessionExpiresIn)}</span>
            <button
              onClick={extendSession}
              className="p-0.5 rounded hover:bg-white/10 text-neutral-400 hover:text-white ml-1"
              title="Refresh / Extend Session"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>

          {/* View Live Website Button */}
          <button
            onClick={onBackToSite}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>Live Site</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          {/* Logout Button */}
          <button
            onClick={logout}
            className="px-3 py-1.5 rounded-xl bg-rose-900/80 hover:bg-rose-800 text-rose-100 border border-rose-500/40 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            title="Sign out of admin console"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>

        </div>
      </header>

      {/* MAIN LAYOUT */}
      <div className="flex-1 flex flex-col md:flex-row">
        
        {/* SIDEBAR NAVIGATION */}
        <aside
          className={`${
            mobileMenuOpen ? 'block' : 'hidden'
          } md:block w-full md:w-64 bg-[#160104] border-r border-[#D4AF37]/20 p-4 space-y-1.5 shrink-0`}
        >
          <div className="text-[11px] uppercase tracking-wider font-semibold text-neutral-400 px-3 py-2">
            Navigation Menu
          </div>

          {[
            { id: 'overview', label: 'Dashboard Overview', icon: LayoutDashboard },
            { id: 'items', label: 'Rental Inventory / Items', icon: Package, badge: siteData.items.length },
            { id: 'founder', label: 'Chairman & Founder', icon: Crown },
            { id: 'team', label: 'Teammates & Staff', icon: Users, badge: siteData.team.length },
            { id: 'partners', label: 'Partners & Collaboration', icon: HeartHandshake, badge: siteData.partners.length },
            { id: 'settings', label: 'Website Settings', icon: Settings },
            { id: 'backup', label: 'Backup & Security', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as AdminTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] shadow-md'
                    : 'text-neutral-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </div>
                {tab.badge !== undefined && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-[#240106] text-[#F3DE8A]' : 'bg-white/10 text-neutral-400'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Quick Info Box in Sidebar */}
          <div className="mt-8 p-4 rounded-2xl bg-black/40 border border-white/10 text-[11px] text-neutral-400 space-y-2">
            <span className="font-bold text-white block">Real-Time Sync Active</span>
            <p>Every change saved here updates live visitors immediately with zero server rebuild required.</p>
          </div>
        </aside>

        {/* CONTENT AREA */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-y-auto">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                  Dashboard Overview
                </h2>
                <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                  Welcome back, <strong>{adminUser}</strong>. Here is your inventory and site status at a glance.
                </p>
              </div>

              {/* Stat Cards Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                <div className="p-5 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 shadow-lg">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold">Total Items</span>
                    <Package className="w-5 h-5 text-[#F3DE8A]" />
                  </div>
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-white block">
                    {siteData.items.length}
                  </span>
                  <span className="text-[11px] text-emerald-400 mt-1 block">
                    {siteData.items.filter((i) => i.visible).length} Visible Online
                  </span>
                </div>

                <div className="p-5 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 shadow-lg">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold">Years of Trust</span>
                    <Crown className="w-5 h-5 text-[#F3DE8A]" />
                  </div>
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-white block">
                    {siteData.founder.experienceYears}+
                  </span>
                  <span className="text-[11px] text-neutral-400 mt-1 block">
                    Established 2002 · Guntur
                  </span>
                </div>

                <div className="p-5 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 shadow-lg">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold">Team Members</span>
                    <Users className="w-5 h-5 text-[#F3DE8A]" />
                  </div>
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-white block">
                    {siteData.team.length}
                  </span>
                  <span className="text-[11px] text-neutral-400 mt-1 block">
                    Setup & Electrical Crew
                  </span>
                </div>

                <div className="p-5 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 shadow-lg">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold">Partners</span>
                    <HeartHandshake className="w-5 h-5 text-[#F3DE8A]" />
                  </div>
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-white block">
                    {siteData.partners.length}
                  </span>
                  <span className="text-[11px] text-neutral-400 mt-1 block">
                    Catering, Flowers & Photo
                  </span>
                </div>
              </div>

              {/* Quick Actions Bar */}
              <div className="p-6 rounded-3xl bg-[#180205] border border-white/10 space-y-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Quick Actions
                </h3>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => {
                      setEditingItem(null);
                      setIsItemModalOpen(true);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Rental Item</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('items')}
                    className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs flex items-center gap-2 cursor-pointer"
                  >
                    <Package className="w-4 h-4" />
                    <span>Manage Inventory & Photos</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('founder')}
                    className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs flex items-center gap-2 cursor-pointer"
                  >
                    <Crown className="w-4 h-4" />
                    <span>Chairman Photo & Founder Details</span>
                  </button>

                  <button
                    onClick={handleExportBackup}
                    className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs flex items-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export JSON Backup</span>
                  </button>
                </div>
              </div>

              {/* Live Preview Information */}
              <div className="p-6 rounded-3xl bg-black/40 border border-white/10 space-y-3">
                <span className="text-xs uppercase tracking-wider text-[#D4AF37] font-bold block">
                  Current Website Configuration
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-neutral-500 block">Site Title:</span>
                    <strong className="text-white">{siteData.settings.siteName}</strong>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Direct Phones:</span>
                    <strong className="text-white">{siteData.settings.phone1} · {siteData.settings.phone2}</strong>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Founder Bio Mode:</span>
                    <strong className="text-white">
                      {siteData.founder.showPhoto ? 'Custom Photo Displayed' : 'Prestigious Gold Crest Emblem'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Last Saved To Disk:</span>
                    <span className="text-neutral-300 font-mono text-[11px]">{new Date(siteData.lastUpdated).toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Lockout Protection:</span>
                    <span className="text-emerald-400 font-semibold">Enabled (5 attempts = 15m lock)</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Session Security:</span>
                    <span className="text-emerald-400 font-semibold">30 Min Inactivity Expiry</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ITEMS / INVENTORY */}
          {activeTab === 'items' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Header + Add Item Button */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                    Rental Inventory & Items Menu
                  </h2>
                  <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                    Add, edit, reorder, and toggle visibility. Changes appear instantly on the live website.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setEditingItem(null);
                    setIsItemModalOpen(true);
                  }}
                  className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Item</span>
                </button>
              </div>

              {/* Filters & Search Bar */}
              <div className="p-4 rounded-2xl bg-[#1C0206] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-3">
                <div className="relative w-full md:w-80">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <input
                    type="text"
                    placeholder="Search by title or category..."
                    value={itemSearch}
                    onChange={(e) => setItemSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 text-xs rounded-xl bg-black/40 border border-white/10 text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
                  {/* Category Filter */}
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="px-3 py-2 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                  >
                    {allCategories.map((c) => (
                      <option key={c} value={c} className="bg-neutral-900">
                        {c === 'All' ? 'All Categories' : c}
                      </option>
                    ))}
                  </select>

                  {/* Visibility Filter */}
                  <select
                    value={visibilityFilter}
                    onChange={(e) => setVisibilityFilter(e.target.value)}
                    className="px-3 py-2 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="All">All Statuses</option>
                    <option value="Visible">Visible Only</option>
                    <option value="Hidden">Hidden Only</option>
                  </select>
                </div>
              </div>

              {/* Items Table / Cards */}
              <div className="space-y-3">
                {filteredItems.length === 0 ? (
                  <div className="p-12 rounded-3xl bg-[#1A0206] border border-white/10 text-center text-neutral-400 text-sm">
                    No items found matching your filters.
                  </div>
                ) : (
                  filteredItems.map((item, index) => (
                    <div
                      key={item.id}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                        item.visible
                          ? 'bg-[#1C0206] border-white/10 hover:border-[#D4AF37]/40 shadow-sm'
                          : 'bg-black/40 border-dashed border-white/10 opacity-70'
                      }`}
                    >
                      {/* Left: Thumbnail & Details */}
                      <div className="flex items-start gap-4 min-w-0">
                        
                        {/* Thumbnail Slot */}
                        <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden bg-neutral-900 border border-white/15 shrink-0 flex items-center justify-center">
                          {item.image || (item.images && item.images[0]) ? (
                            <img
                              src={item.image || item.images[0]}
                              alt={item.english}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="text-center p-1 text-neutral-500 text-[10px]">
                              <ImageIcon className="w-5 h-5 mx-auto mb-0.5 text-neutral-600" />
                              <span>No Photo</span>
                            </div>
                          )}

                          <span className="absolute top-1 left-1 w-5 h-5 rounded-full bg-[#7A1526] text-[#F3DE8A] text-[10px] font-bold font-mono flex items-center justify-center shadow-xs">
                            {index + 1}
                          </span>
                        </div>

                        {/* Title & Info */}
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 rounded-full bg-white/10 text-[#F3DE8A] text-[10px] font-bold uppercase tracking-wider">
                              {item.category}
                            </span>
                            {item.badge && (
                              <span className="px-2 py-0.5 rounded-full bg-[#7A1526]/80 text-white text-[10px] font-medium">
                                {item.badge}
                              </span>
                            )}
                            {!item.visible && (
                              <span className="px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 text-[10px] font-bold flex items-center gap-1">
                                <EyeOff className="w-3 h-3" />
                                <span>Hidden from Live Site</span>
                              </span>
                            )}
                          </div>

                          <h3 className="text-base sm:text-lg font-bold text-white truncate font-telugu">
                            {item.telugu} <span className="font-sans font-medium text-neutral-300 text-sm">({item.english})</span>
                          </h3>

                          <p className="text-xs text-neutral-400 line-clamp-1 mt-0.5">
                            {item.description || item.specs || 'No description provided.'}
                          </p>

                          {/* Sizes / Capacity Tags */}
                          {item.sizes && item.sizes.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {item.sizes.map((s, idx) => (
                                <span
                                  key={idx}
                                  className="px-2 py-0.5 rounded text-[10px] bg-black/40 border border-white/10 text-neutral-300"
                                >
                                  {s.label}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                      </div>

                      {/* Right: Actions Bar */}
                      <div className="flex items-center gap-1.5 shrink-0 self-end md:self-center">
                        
                        {/* Manage Multiple Photos */}
                        <button
                          onClick={() => {
                            setImageManagingItem(item);
                            setIsImagesModalOpen(true);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-neutral-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                          title="Manage photo gallery & auto-compress"
                        >
                          <ImageIcon className="w-3.5 h-3.5 text-[#F3DE8A]" />
                          <span>Photos ({item.images?.length || (item.image ? 1 : 0)})</span>
                        </button>

                        {/* Visibility Toggle */}
                        <button
                          onClick={() => handleToggleItemVisibility(item.id)}
                          className={`p-2 rounded-xl transition-colors cursor-pointer ${
                            item.visible ? 'text-emerald-400 hover:bg-emerald-950/40' : 'text-neutral-500 hover:bg-white/10'
                          }`}
                          title={item.visible ? 'Hide from public site' : 'Show on public site'}
                        >
                          {item.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                        </button>

                        {/* Reorder Up */}
                        <button
                          disabled={index === 0}
                          onClick={() => handleReorderItem(index, 'up')}
                          className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer"
                          title="Move Up"
                        >
                          <ArrowUp className="w-4 h-4" />
                        </button>

                        {/* Reorder Down */}
                        <button
                          disabled={index === siteData.items.length - 1}
                          onClick={() => handleReorderItem(index, 'down')}
                          className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer"
                          title="Move Down"
                        >
                          <ArrowDown className="w-4 h-4" />
                        </button>

                        {/* Edit Item */}
                        <button
                          onClick={() => {
                            setEditingItem(item);
                            setIsItemModalOpen(true);
                          }}
                          className="p-2 rounded-xl text-[#F3DE8A] hover:bg-[#D4AF37]/20 transition-colors cursor-pointer"
                          title="Edit Item Details"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        {/* Delete Item */}
                        <button
                          onClick={() => handleDeleteItem(item.id, `${item.telugu} ${item.english}`)}
                          className="p-2 rounded-xl text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                          title="Delete Item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                      </div>

                    </div>
                  ))
                )}
              </div>

            </div>
          )}

          {/* TAB 3: FOUNDER & LEADERSHIP */}
          {activeTab === 'founder' && (
            <div className="space-y-6 max-w-4xl animate-in fade-in duration-200">
              <div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                  Chairman & Founder Profile
                </h2>
                <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                  Upload a Chairman / Founder photo directly from your device&apos;s Files app, or manage titles, story, and contact numbers.
                </p>
              </div>

              {/* Photo Mode Card with Files App Picker & Drag-and-Drop */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDraggingChairmanPhoto(true);
                }}
                onDragLeave={() => setIsDraggingChairmanPhoto(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDraggingChairmanPhoto(false);
                  const droppedFile = e.dataTransfer.files?.[0];
                  if (droppedFile) {
                    processChairmanPhotoFile(droppedFile);
                  }
                }}
                className={`p-6 rounded-3xl bg-[#1C0206] border transition-colors flex flex-col sm:flex-row items-center gap-6 ${
                  isDraggingChairmanPhoto
                    ? 'border-[#D4AF37] ring-2 ring-[#D4AF37]/40 bg-[#28040B]'
                    : 'border-[#D4AF37]/30'
                }`}
              >
                
                {/* Photo or Crest Preview */}
                <div className="w-28 h-28 rounded-2xl overflow-hidden border-2 border-[#D4AF37] ring-4 ring-[#D4AF37]/30 bg-black/40 flex flex-col items-center justify-center shrink-0 relative">
                  {siteData.founder.showPhoto && siteData.founder.photo ? (
                    <img src={siteData.founder.photo} alt={siteData.founder.name} className="w-full h-full object-cover object-top" />
                  ) : (
                    <div className="flex flex-col items-center justify-center p-2 text-center text-[#F3DE8A]">
                      <Crown className="w-8 h-8 mb-1" />
                      <span className="text-[9px] font-bold tracking-wider uppercase">ROYAL CREST</span>
                    </div>
                  )}
                  {isUploadingChairmanPhoto && (
                    <div className="absolute inset-0 bg-black/75 flex items-center justify-center">
                      <RefreshCw className="w-6 h-6 text-[#F3DE8A] animate-spin" />
                    </div>
                  )}
                </div>

                <div className="space-y-2 text-center sm:text-left flex-1">
                  <span className="text-xs font-bold text-[#F3DE8A] uppercase tracking-wider block">
                    Chairman / Founder Photo (Files App)
                  </span>
                  <p className="text-xs text-neutral-300">
                    Currently set to:{' '}
                    <strong>
                      {siteData.founder.showPhoto && siteData.founder.photo
                        ? 'Chairman Photo Displayed Live'
                        : 'Royal Crest Insignia (No Photo Displayed)'}
                    </strong>.
                  </p>
                  <p className="text-[11px] text-neutral-400">
                    Select any image from your device&apos;s Files app (JPG, PNG, WebP) or drag &amp; drop a photo here. It auto-compresses and updates live.
                  </p>

                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 pt-2">
                    <button
                      type="button"
                      onClick={handleOpenFilesAppForChairman}
                      disabled={isUploadingChairmanPhoto}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md disabled:opacity-60"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      <span>{isUploadingChairmanPhoto ? 'Uploading...' : 'Choose Photo from Files App'}</span>
                    </button>

                    <input
                      ref={chairmanFileInputRef}
                      type="file"
                      accept="image/*,.jpg,.jpeg,.png,.webp,.gif"
                      onChange={handleFounderPhotoUpload}
                      className="hidden"
                    />

                    <button
                      type="button"
                      onClick={handleToggleFounderPhotoDisplay}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                        siteData.founder.showPhoto
                          ? 'bg-rose-900/60 border border-rose-500/40 text-rose-200 hover:bg-rose-900/80'
                          : 'bg-emerald-700 hover:bg-emerald-600 text-white'
                      }`}
                    >
                      {siteData.founder.showPhoto ? 'Switch to Royal Emblem Crest' : 'Enable Chairman Photo Display'}
                    </button>

                    {siteData.founder.photo && (
                      <button
                        type="button"
                        onClick={handleRemoveFounderPhoto}
                        className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-rose-900/60 text-xs font-semibold text-neutral-200 hover:text-rose-200 flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Remove Photo</span>
                      </button>
                    )}
                  </div>
                </div>

              </div>

              {/* Founder Information Form */}
              <form onSubmit={handleSaveFounder} className="p-6 sm:p-8 rounded-3xl bg-[#1C0206] border border-white/10 space-y-5">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      English Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      defaultValue={siteData.founder.name}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                      తెలుగు పేరు (Telugu Name)
                    </label>
                    <input
                      type="text"
                      name="nameTelugu"
                      defaultValue={siteData.founder.nameTelugu}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Title / Role (English)
                    </label>
                    <input
                      type="text"
                      name="title"
                      defaultValue={siteData.founder.title}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                      పదవి / శీర్షిక (Telugu Title)
                    </label>
                    <input
                      type="text"
                      name="titleTelugu"
                      defaultValue={siteData.founder.titleTelugu}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Phone Number 1
                    </label>
                    <input
                      type="text"
                      name="phone1"
                      defaultValue={siteData.founder.phone1}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Phone Number 2 (Alternate)
                    </label>
                    <input
                      type="text"
                      name="phone2"
                      defaultValue={siteData.founder.phone2}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Years of Experience
                    </label>
                    <input
                      type="number"
                      name="experienceYears"
                      defaultValue={siteData.founder.experienceYears}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                    Bio & History (English)
                  </label>
                  <textarea
                    name="bio"
                    rows={3}
                    defaultValue={siteData.founder.bio}
                    className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                    వివరాలు & చరిత్ర (Telugu Bio)
                  </label>
                  <textarea
                    name="bioTelugu"
                    rows={3}
                    defaultValue={siteData.founder.bioTelugu}
                    className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Office Address (English)
                    </label>
                    <input
                      type="text"
                      name="addressEnglish"
                      defaultValue={siteData.founder.addressEnglish}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                      ఆఫీస్ చిరునామా (Telugu Address)
                    </label>
                    <input
                      type="text"
                      name="addressTelugu"
                      defaultValue={siteData.founder.addressTelugu}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                    />
                  </div>
                </div>

                {/* Social Links */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Instagram URL
                    </label>
                    <input
                      type="text"
                      name="instagram"
                      defaultValue={siteData.founder.socialLinks?.instagram || ''}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Facebook URL
                    </label>
                    <input
                      type="text"
                      name="facebook"
                      defaultValue={siteData.founder.socialLinks?.facebook || ''}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      WhatsApp Raw Number
                    </label>
                    <input
                      type="text"
                      name="whatsapp"
                      defaultValue={siteData.founder.socialLinks?.whatsapp || ''}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 text-right">
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-sm shadow-md transition-transform active:scale-95 cursor-pointer"
                  >
                    Save Founder Profile
                  </button>
                </div>

              </form>

            </div>
          )}

          {/* TAB 4: TEAMMATES */}
          {activeTab === 'team' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                    Teammates & Staff Management
                  </h2>
                  <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                    Manage profiles of on-site supervisors, technicians, and crew members.
                  </p>
                </div>

                <button
                  onClick={() => {
                    const newTeamId = `team-${Date.now()}`;
                    const newMember: Teammate = {
                      id: newTeamId,
                      name: 'New Teammate',
                      role: 'Team Member',
                      phone: '98481 47203',
                      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
                      details: 'Pandal setup & catering equipment support.',
                    };
                    handleSaveTeammate(newMember);
                  }}
                  className="px-4 py-2.5 rounded-2xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Teammate</span>
                </button>
              </div>

              {/* Teammates Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {siteData.team.map((member) => (
                  <div key={member.id} className="p-5 rounded-3xl bg-[#1C0206] border border-white/10 space-y-4">
                    <div className="flex items-center gap-3.5">
                      <div className="w-14 h-14 rounded-2xl overflow-hidden bg-neutral-900 border border-white/20 shrink-0">
                        <img src={member.photo} alt={member.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-base leading-snug">{member.name}</h4>
                        <span className="text-xs text-[#F3DE8A] font-semibold">{member.role}</span>
                        <div className="text-[11px] text-neutral-400 font-mono mt-0.5">{member.phone}</div>
                      </div>
                    </div>

                    <p className="text-xs text-neutral-300 line-clamp-2">{member.details}</p>

                    <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                      <label className="text-[11px] text-[#F3DE8A] hover:underline cursor-pointer flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        <span>Change Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            const compressed = await compressImage(file);
                            handleSaveTeammate({ ...member, photo: compressed });
                          }}
                        />
                      </label>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingTeammate(member);
                            setIsTeammateModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-300 hover:text-white cursor-pointer"
                          title="Edit teammate"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteTeammate(member.id, member.name)}
                          className="p-1.5 rounded-lg hover:bg-rose-950/50 text-rose-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: PARTNERS & COLLABORATION */}
          {activeTab === 'partners' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                    Partners & Vendor Network
                  </h2>
                  <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                    Manage catering, photography, and decor partners displayed in the infinite marquee.
                  </p>
                </div>

                <button
                  onClick={() => {
                    const newPartner: Partner = {
                      id: `partner-${Date.now()}`,
                      name: 'Partner Business Name',
                      brand: 'Specialty Brand',
                      role: 'Partner',
                      phone: '98481 47203',
                      photo: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=400&q=80',
                      details: 'Verified event collaboration partner.',
                    };
                    handleSavePartner(newPartner);
                  }}
                  className="px-4 py-2.5 rounded-2xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Partner</span>
                </button>
              </div>

              {/* Partnership Text Editor Card */}
              <div className="p-6 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 space-y-3">
                <span className="text-xs font-bold text-[#F3DE8A] uppercase tracking-wider block">
                  Partnership Section Content
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-neutral-400 block mb-1">Section Title (English):</label>
                    <input
                      type="text"
                      defaultValue={siteData.partnership.heading}
                      onBlur={(e) => updatePartnership({ ...siteData.partnership, heading: e.target.value })}
                      className="w-full px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-neutral-400 block mb-1 font-telugu">శీర్షిక (Telugu Heading):</label>
                    <input
                      type="text"
                      defaultValue={siteData.partnership.headingTelugu}
                      onBlur={(e) => updatePartnership({ ...siteData.partnership, headingTelugu: e.target.value })}
                      className="w-full px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-white font-telugu"
                    />
                  </div>
                </div>
              </div>

              {/* Partners Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {siteData.partners.map((partner) => (
                  <div key={partner.id} className="p-5 rounded-3xl bg-[#1C0206] border border-white/10 space-y-4">
                    <div className="flex items-center gap-3.5">
                      <div className="w-14 h-14 rounded-2xl overflow-hidden bg-neutral-900 border border-white/20 shrink-0">
                        <img src={partner.photo} alt={partner.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-base leading-snug">{partner.name}</h4>
                        <span className="text-xs text-[#F3DE8A] font-semibold">{partner.brand}</span>
                        <div className="text-[11px] text-neutral-400 font-mono mt-0.5">{partner.phone}</div>
                      </div>
                    </div>

                    <p className="text-xs text-neutral-300 line-clamp-2">{partner.details || 'Vendor partner.'}</p>

                    <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                      <label className="text-[11px] text-[#F3DE8A] hover:underline cursor-pointer flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        <span>Logo / Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            const compressed = await compressImage(file);
                            handleSavePartner({ ...partner, photo: compressed });
                          }}
                        />
                      </label>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingPartner(partner);
                            setIsPartnerModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-300 hover:text-white cursor-pointer"
                          title="Edit partner"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeletePartner(partner.id, partner.name)}
                          className="p-1.5 rounded-lg hover:bg-rose-950/50 text-rose-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: WEBSITE SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-4xl animate-in fade-in duration-200">
              <div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                  Website Settings
                </h2>
                <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                  Configure primary site title, hero texts, banner image, and contact details.
                </p>
              </div>

              <form onSubmit={handleSaveSettings} className="p-6 sm:p-8 rounded-3xl bg-[#1C0206] border border-white/10 space-y-5">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Business Name (English)
                    </label>
                    <input
                      type="text"
                      name="siteName"
                      defaultValue={siteData.settings.siteName}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                      వ్యాపార పేరు (Telugu Business Name)
                    </label>
                    <input
                      type="text"
                      name="siteNameTelugu"
                      defaultValue={siteData.settings.siteNameTelugu}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                    Browser Title (&lt;title&gt; Tag)
                  </label>
                  <input
                    type="text"
                    name="siteTitle"
                    defaultValue={siteData.settings.siteTitle}
                    className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Primary Tagline (English)
                    </label>
                    <textarea
                      name="tagline"
                      rows={2}
                      defaultValue={siteData.settings.tagline}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                      ప్రధాన ట్యాగ్‌లైన్ (Telugu Tagline)
                    </label>
                    <textarea
                      name="taglineTelugu"
                      rows={2}
                      defaultValue={siteData.settings.taglineTelugu}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Primary Phone (Phone 1)
                    </label>
                    <input
                      type="text"
                      name="phone1"
                      defaultValue={siteData.settings.phone1}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Secondary Phone (Phone 2)
                    </label>
                    <input
                      type="text"
                      name="phone2"
                      defaultValue={siteData.settings.phone2}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Official Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      defaultValue={siteData.settings.email}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Footer Copyright Text
                    </label>
                    <input
                      type="text"
                      name="footerText"
                      defaultValue={siteData.settings.footerText}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                      Address (English)
                    </label>
                    <input
                      type="text"
                      name="addressEnglish"
                      defaultValue={siteData.settings.addressEnglish}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wide mb-1 font-telugu">
                      చిరునామా (Telugu Address)
                    </label>
                    <input
                      type="text"
                      name="addressTelugu"
                      defaultValue={siteData.settings.addressTelugu}
                      className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37] font-telugu"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 text-right">
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-sm shadow-md transition-transform active:scale-95 cursor-pointer"
                  >
                    Save Website Settings
                  </button>
                </div>

              </form>
            </div>
          )}

          {/* TAB 7: BACKUP & SECURITY */}
          {activeTab === 'backup' && (
            <div className="space-y-6 max-w-4xl animate-in fade-in duration-200">
              <div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                  Backup, Restore & Security
                </h2>
                <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                  Export backups, restore previous database snapshots, and review security settings.
                </p>
              </div>

              {/* Backup & Restore Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Export Card */}
                <div className="p-6 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 space-y-4">
                  <div className="flex items-center gap-3 text-[#F3DE8A]">
                    <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center">
                      <Download className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white">Export Database Backup</h3>
                      <span className="text-[11px] text-neutral-400">Download complete inventory & settings</span>
                    </div>
                  </div>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    Generates a complete, unencrypted JSON archive containing all your inventory items, images, founder story, teammates, partners, and site settings.
                  </p>
                  <button
                    onClick={handleExportBackup}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download JSON Archive</span>
                  </button>
                </div>

                {/* Import Card */}
                <div className="p-6 rounded-3xl bg-[#1C0206] border border-white/10 space-y-4">
                  <div className="flex items-center gap-3 text-emerald-400">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white">Restore Backup</h3>
                      <span className="text-[11px] text-neutral-400">Upload and apply a JSON backup</span>
                    </div>
                  </div>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    Restore previously downloaded backup JSON file to recover items, photos, and configurations.
                  </p>
                  <label className="w-full py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors">
                    <Upload className="w-4 h-4 text-[#F3DE8A]" />
                    <span>Choose JSON Backup File</span>
                    <input type="file" accept=".json,application/json" onChange={handleImportBackup} className="hidden" />
                  </label>
                </div>

              </div>

              {/* Change Owner Password Card */}
              <div className="p-6 rounded-3xl bg-[#1C0206] border border-[#D4AF37]/30 space-y-4">
                <div className="flex items-center gap-2.5 text-[#F3DE8A]">
                  <ShieldCheck className="w-5 h-5" />
                  <h3 className="font-bold text-base text-white">Change Owner Username &amp; Password</h3>
                </div>

                {configuredViaEnv ? (
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    Owner credentials are currently managed via server environment secrets (<code>ADMIN_USERNAME</code> and <code>ADMIN_PASSWORD</code> in Settings → Secrets). Update them in your environment secrets and restart the server to change your password.
                  </p>
                ) : (
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (newPassInput.length < 8) {
                        showToast('error', 'New password must be at least 8 characters long.');
                        return;
                      }
                      if (newPassInput !== confirmPassInput) {
                        showToast('error', 'New password and confirmation do not match.');
                        return;
                      }
                      setIsUpdatingPassword(true);
                      const res = await changePassword(currentPassInput, newUserInput.trim(), newPassInput);
                      setIsUpdatingPassword(false);
                      if (res.success) {
                        setCurrentPassInput('');
                        setNewPassInput('');
                        setConfirmPassInput('');
                        showToast('success', 'Owner username and password updated securely.');
                      } else {
                        showToast('error', res.error || 'Could not update credentials.');
                      }
                    }}
                    className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs"
                  >
                    <div>
                      <label className="block font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                        Current Password *
                      </label>
                      <input
                        type="password"
                        required
                        value={currentPassInput}
                        onChange={(e) => setCurrentPassInput(e.target.value)}
                        placeholder="Enter current password"
                        className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                        Owner Username
                      </label>
                      <input
                        type="text"
                        required
                        minLength={3}
                        value={newUserInput}
                        onChange={(e) => setNewUserInput(e.target.value)}
                        placeholder="Owner username"
                        className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                        New Password (Min 8 chars) *
                      </label>
                      <input
                        type="password"
                        required
                        minLength={8}
                        value={newPassInput}
                        onChange={(e) => setNewPassInput(e.target.value)}
                        placeholder="Enter new strong password"
                        className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-neutral-300 uppercase tracking-wide mb-1">
                        Confirm New Password *
                      </label>
                      <input
                        type="password"
                        required
                        minLength={8}
                        value={confirmPassInput}
                        onChange={(e) => setConfirmPassInput(e.target.value)}
                        placeholder="Confirm new password"
                        className="w-full px-3.5 py-2 text-sm rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>
                    <div className="sm:col-span-2 flex justify-end pt-2">
                      <button
                        type="submit"
                        disabled={isUpdatingPassword}
                        className="px-5 py-2 rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs cursor-pointer disabled:opacity-50"
                      >
                        {isUpdatingPassword ? 'Updating...' : 'Update Owner Password'}
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Security & Authentication Documentation */}
              <div className="p-6 rounded-3xl bg-black/40 border border-white/10 space-y-4">
                <div className="flex items-center gap-2.5 text-[#F3DE8A]">
                  <ShieldCheck className="w-5 h-5" />
                  <h3 className="font-bold text-base text-white">Owner Access Safeguards</h3>
                </div>

                <div className="space-y-3 text-xs text-neutral-300 leading-relaxed">
                  <div className="p-3.5 rounded-xl bg-white/5 border border-white/10">
                    <strong className="text-white block mb-1">1. Hidden Owner Route &amp; Code Isolation</strong>
                    <p>
                      The <code>/admin</code> route has zero links on the public website, sends <code>noindex, nofollow</code> meta tags and server headers, and loads in an isolated bundle only when navigated to directly.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/5 border border-white/10">
                    <strong className="text-white block mb-1">2. Salted Bcrypt Hashing &amp; Memory Sessions</strong>
                    <p>
                      Owner passwords are stored strictly as salted <strong>bcrypt</strong> hashes on the server (12 rounds) and verified server-side. Active session tokens stay strictly in memory and auto-expire after <strong>30 minutes</strong> of inactivity.
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/5 border border-white/10">
                    <strong className="text-white block mb-1">3. Brute-Force Lockout Protection</strong>
                    <p>
                      After <strong>5 consecutive wrong password attempts</strong>, access is locked for <strong>15 minutes</strong>.
                    </p>
                  </div>
                </div>

                {/* Reset to Factory Defaults */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-rose-300 block">Factory Reset</span>
                    <span className="text-[11px] text-neutral-500">Reverts all inventory and configurations back to initial template.</span>
                  </div>
                  <button
                    onClick={handleResetToDefaults}
                    className="px-3.5 py-2 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 hover:bg-rose-900/60 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                </div>
              </div>

            </div>
          )}

        </main>
      </div>

    </div>
  );
};
