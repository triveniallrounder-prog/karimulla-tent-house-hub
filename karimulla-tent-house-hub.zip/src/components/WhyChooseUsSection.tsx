import React, { useEffect, useState, useRef } from 'react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { 
  ShieldCheck, 
  Clock, 
  Sparkles, 
  UserCheck, 
  Award, 
  HeartHandshake 
} from 'lucide-react';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer } from './motion/MotionFade';

interface CounterProps {
  target: number;
  suffix?: string;
  duration?: number;
}

const AnimatedCounter: React.FC<CounterProps> = ({ target, suffix = '', duration = 2000 }) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      // ease-out expo
      const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      setCount(Math.floor(easeProgress * target));

      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        setCount(target);
      }
    };

    window.requestAnimationFrame(step);
  }, [isVisible, target, duration]);

  return (
    <div ref={elementRef} className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F3DE8A] tabular-nums animated-gradient-gold">
      {count.toLocaleString('en-IN')}{suffix}
    </div>
  );
};

export const WhyChooseUsSection: React.FC = () => {
  return (
    <section className="py-20 sm:py-24 bg-gradient-to-b from-[#38030B] via-[#4A040F] to-[#2D0208] text-white relative overflow-hidden">
      
      {/* Subtle Pattern Grid Background */}
      <div 
        aria-hidden="true" 
        className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:24px_24px]"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <MotionHeading className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-semibold tracking-wider text-[#E5C158] mb-2">
            The Karimulla Difference
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            Why Event Organizers Trust Karimulla Tent House
          </h2>
          <p className="mt-3 text-base text-neutral-300">
            For over two decades, families and corporations across Andhra Pradesh have relied on our proven punctuality, spotless aesthetics, and dedicated on-site support.
          </p>
        </MotionHeading>

        {/* Animated Number Counters Banner */}
        <MotionContainer delay={0.15} className="grid grid-cols-2 lg:grid-cols-4 gap-6 p-6 sm:p-8 rounded-2xl bg-white/5 backdrop-blur-md border border-[#D4AF37]/30 shadow-2xl mb-16">
          
          <div className="text-center space-y-1 p-3">
            <AnimatedCounter target={BUSINESS_DETAILS.experienceYears} suffix="+" />
            <span className="text-xs sm:text-sm text-neutral-300 font-medium block">
              Years in Business
            </span>
          </div>

          <div className="text-center space-y-1 p-3">
            <AnimatedCounter target={BUSINESS_DETAILS.eventsCompleted} suffix="+" />
            <span className="text-xs sm:text-sm text-neutral-300 font-medium block">
              Events Completed
            </span>
          </div>

          <div className="text-center space-y-1 p-3">
            <AnimatedCounter target={BUSINESS_DETAILS.happyClients} suffix="+" />
            <span className="text-xs sm:text-sm text-neutral-300 font-medium block">
              Happy Families
            </span>
          </div>

          <div className="text-center space-y-1 p-3">
            <AnimatedCounter target={BUSINESS_DETAILS.inventoryCount} suffix="+" />
            <span className="text-xs sm:text-sm text-neutral-300 font-medium block">
              Rental Inventory Items
            </span>
          </div>

        </MotionContainer>

        {/* 4 Pillars of Excellence */}
        <MotionContainer delay={0.25} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 card-premium-hover reveal-on-scroll stagger-delay-1">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#F3DE8A] mb-4 shadow-sm">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-white mb-2">
              All-Weather Durability
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              Certified German PVC hangars and heavy iron-pole shamianas withstand high winds and heavy monsoons with zero leaks.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 card-premium-hover reveal-on-scroll stagger-delay-2">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#F3DE8A] mb-4 shadow-sm">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-white mb-2">
              Spotless Presentation
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              No torn fabrics, stained covers, or scratched chairs. Every item is washed, steamed, and pre-screened before dispatch.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 card-premium-hover reveal-on-scroll stagger-delay-3">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#F3DE8A] mb-4 shadow-sm">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-white mb-2">
              Advance 12-Hr Setup
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              We never run into last-minute chaos. Your venue is fully erected, illuminated, and ready well ahead of your muhurtham or guests arrival.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 card-premium-hover reveal-on-scroll stagger-delay-4">
            <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#F3DE8A] mb-4 shadow-sm">
              <UserCheck className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-white mb-2">
              Direct Owner Supervised
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              Karimulla garu personally monitors the crew and stays reachable 24/7 on call for immediate adjustments or extra chair additions.
            </p>
          </div>

        </MotionContainer>

      </div>
    </section>
  );
};
