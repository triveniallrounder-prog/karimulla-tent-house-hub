import React, { useEffect, useState } from 'react';
import { Crown, Sparkles } from 'lucide-react';

export const PageLoader: React.FC = () => {
  const [mounted, setMounted] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    // Show splash for 750ms then smoothly dissolve out
    const timer = setTimeout(() => {
      setMounted(true);
      setTimeout(() => setHidden(true), 600);
    }, 700);

    return () => clearTimeout(timer);
  }, []);

  if (hidden) return null;

  return (
    <div
      aria-hidden="true"
      className={`page-loader-overlay ${mounted ? 'is-hidden' : ''}`}
    >
      <div className="flex flex-col items-center justify-center p-6 text-center max-w-sm">
        {/* Royal Crest Monogram with Breathing Glow */}
        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-br from-[#7A1526] via-[#4A040F] to-[#240106] border-2 border-[#D4AF37] flex flex-col items-center justify-center p-3 anim-logo-breathe shadow-2xl relative">
          <Crown className="w-8 h-8 text-[#F3DE8A]" />
          <span className="font-serif font-black text-white text-lg tracking-wider mt-0.5">
            K
          </span>
          <div className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-[#E5C158] flex items-center justify-center shadow-xs">
            <Sparkles className="w-2.5 h-2.5 text-[#240106]" />
          </div>
        </div>

        {/* Title */}
        <h2 className="font-telugu text-xl font-bold text-white mt-5 tracking-tight">
          కరిముల్లా టెంట్ హౌస్
        </h2>
        <p className="font-serif text-xs text-[#E5C158] uppercase tracking-widest mt-1">
          Karimulla Tent House · 22+ Years
        </p>

        {/* Luxury Gold Progress Line */}
        <div className="w-44 h-1 bg-white/10 rounded-full mt-6 overflow-hidden relative">
          <div className="h-full bg-gradient-to-r from-[#D4AF37] via-[#F3DE8A] to-[#B8860B] rounded-full animate-[progress-pulse_1.2s_ease-in-out_infinite]" />
        </div>
      </div>
    </div>
  );
};
