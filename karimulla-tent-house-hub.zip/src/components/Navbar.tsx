import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Menu, 
  X, 
  ShoppingBag, 
  Phone, 
  ArrowRight,
  Globe,
  Sun,
  Moon,
  User,
  Users,
  Star
} from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useSiteData } from '../context/SiteDataContext';

interface NavbarProps {
  quoteCount: number;
  onOpenQuoteBasket: () => void;
  onSwitchToRealEstate: () => void;
  onSwitchToFounder?: () => void;
  onSwitchToPartners?: () => void;
  onSwitchToReviews?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  quoteCount,
  onOpenQuoteBasket,
  onSwitchToRealEstate,
  onSwitchToFounder,
  onSwitchToPartners,
  onSwitchToReviews,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { language, setLanguage, isTelugu } = useLanguage();
  const { theme, toggleTheme, isDark } = useTheme();
  const { siteData } = useSiteData();
  const settings = siteData?.settings;

  const siteName = settings?.siteName || BUSINESS_DETAILS.name;
  const siteNameTelugu = settings?.siteNameTelugu || BUSINESS_DETAILS.nameTelugu;
  const addressShort = isTelugu 
    ? (settings?.addressTelugu || BUSINESS_DETAILS.addressTelugu)
    : (settings?.addressEnglish || BUSINESS_DETAILS.addressEnglish);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = isTelugu
    ? [
        { label: 'హోమ్', href: '#home' },
        { label: 'మా సామాగ్రి', href: '#our-items' },
        { label: 'మెనూ', href: '#items-menu' },
        { label: 'మా గురించి', href: '#about' },
        { label: 'రేటింగ్స్', href: '#reviews' },
        { label: 'టీమ్', href: '#team' },
        { label: 'ఎఫ్.ఎ.క్యు', href: '#faq' },
        { label: 'సంప్రదించండి', href: '#contact' },
      ]
    : [
        { label: 'Home', href: '#home' },
        { label: 'Our Items', href: '#our-items' },
        { label: 'Menu', href: '#items-menu' },
        { label: 'About', href: '#about' },
        { label: 'Reviews', href: '#reviews' },
        { label: 'Team', href: '#team' },
        { label: 'FAQ', href: '#faq' },
        { label: 'Contact', href: '#contact' },
      ];

  const handleLinkClick = (link: any, e: React.MouseEvent) => {
    if (link.action) {
      e.preventDefault();
      link.action();
    }
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-200 ${
        isScrolled
          ? 'bg-[#38030B]/95 backdrop-blur-md shadow-lg border-b border-[#D4AF37]/30 py-1.5 sm:py-2'
          : 'bg-gradient-to-b from-[#240106]/95 via-[#240106]/85 to-transparent py-2 sm:py-2.5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-1 sm:gap-3">
          
          {/* Brand Wordmark (Zone 1) - Compact, Never pushes elements off screen */}
          <a
            href="#home"
            className="flex items-center gap-1.5 sm:gap-2 text-white group focus:outline-none rounded shrink min-w-0"
          >
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gradient-to-br from-[#E5C158] to-[#B8860B] flex items-center justify-center shadow-sm text-[#38030B] font-bold text-sm sm:text-base font-serif shrink-0">
              K
            </div>
            <div className="flex flex-col leading-tight min-w-0">
              <span className={`text-xs sm:text-sm md:text-base font-bold tracking-tight text-white group-hover:text-[#F3DE8A] transition-colors truncate ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? siteNameTelugu : siteName}
              </span>
              <span className="hidden md:block text-[10px] tracking-wide text-[#E5C158] font-medium truncate max-w-[200px]">
                {addressShort}
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links (Zone 2) */}
          <nav className="hidden lg:flex items-center gap-3 xl:gap-4.5 text-xs xl:text-sm font-medium text-white/90 shrink">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(link, e)}
                className={`nav-link-animated py-1 text-white/90 hover:text-[#F3DE8A] whitespace-nowrap ${
                  isTelugu ? 'font-telugu' : 'font-sans'
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Actions + Dark/Light Toggle + Language Toggle + Real Estate Button + Quote */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            
            {/* Dark Mode / Light Mode Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              className="p-1 sm:p-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-[#F3DE8A] border border-[#D4AF37]/40 shadow-xs transition-colors cursor-pointer shrink-0"
              title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
              aria-label={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDark ? (
                <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300" />
              ) : (
                <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#F3DE8A]" />
              )}
            </button>

            {/* Language Mode Toggle Button (Telugu mode & English mode) */}
            <div 
              className="flex items-center bg-black/40 p-0.5 rounded-lg border border-[#D4AF37]/40 shadow-xs shrink-0"
              role="group"
              aria-label="Language selection"
            >
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-all cursor-pointer ${
                  !isTelugu
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] font-bold shadow-xs'
                    : 'text-white/80 hover:text-white font-medium'
                }`}
                title="Switch to English mode"
                aria-pressed={!isTelugu}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-all cursor-pointer font-telugu ${
                  isTelugu
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] font-bold shadow-xs'
                    : 'text-white/80 hover:text-white font-medium'
                }`}
                title="తెలుగు మోడ్‌కి మారండి"
                aria-pressed={isTelugu}
              >
                తెలుగు
              </button>
            </div>

            {/* Real Estate Button (Contrasting Emerald Accent - Sleek & Guaranteed to Never Cut Off) */}
            <button
              onClick={onSwitchToRealEstate}
              type="button"
              aria-label="Open Karimulla Real Estate website"
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white shadow-xs border border-emerald-400/50 hover:border-emerald-300 transition-all duration-150 active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
              title={isTelugu ? BUSINESS_DETAILS.realEstateLineTelugu : "Karimulla Real Estate - Open Plots, Farm Lands & Villas"}
            >
              <Building2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-200 shrink-0" />
              <span className="hidden sm:inline">
                {isTelugu ? BUSINESS_DETAILS.realEstateLabelTelugu : BUSINESS_DETAILS.realEstateLabelEnglish}
              </span>
              <span className="sm:hidden font-sans font-bold">Real Estate</span>
            </button>

            {/* Quote Basket Button */}
            <button
              onClick={onOpenQuoteBasket}
              type="button"
              className="relative p-1 sm:p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[#F3DE8A] border border-[#D4AF37]/40 transition-colors focus:outline-none cursor-pointer shrink-0"
              title="View your selected rental items"
              aria-label={`View quote basket with ${quoteCount} items`}
            >
              <ShoppingBag className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
              {quoteCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#9E1B32] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-[#E5C158] shadow-xs tabular-nums">
                  {quoteCount}
                </span>
              )}
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
              className="lg:hidden p-1 sm:p-1.5 rounded-lg text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#260106]/98 backdrop-blur-xl border-b border-[#D4AF37]/30 shadow-2xl px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-3 duration-200 max-h-[85vh] overflow-y-auto">
          
          <div className="flex flex-col space-y-1 pt-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(link, e)}
                className={`px-3.5 py-2.5 text-sm font-medium text-white/90 hover:text-[#F3DE8A] hover:bg-white/5 rounded-xl transition-colors flex items-center justify-between ${
                  isTelugu ? 'font-telugu' : 'font-sans'
                }`}
              >
                <span>{link.label}</span>
              </a>
            ))}
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onSwitchToRealEstate();
              }}
              className="w-full flex items-center justify-between px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white border border-emerald-400/50 cursor-pointer shadow-sm"
            >
              <span className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-200" />
                <span className={isTelugu ? 'font-telugu' : 'font-sans font-semibold'}>
                  {isTelugu ? BUSINESS_DETAILS.realEstateLabelTelugu : BUSINESS_DETAILS.realEstateLabelEnglish}
                </span>
              </span>
              <ArrowRight className="w-4 h-4 text-emerald-300" />
            </button>

            <div className="grid grid-cols-2 gap-2">
              <a
                href={`tel:+${BUSINESS_DETAILS.phone1Raw}`}
                className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-[#D4AF37] hover:bg-[#E5C158] text-[#2D0208] transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{BUSINESS_DETAILS.phone1}</span>
              </a>
              <a
                href={`tel:+${BUSINESS_DETAILS.phone2Raw}`}
                className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-[#D4AF37] hover:bg-[#E5C158] text-[#2D0208] transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{BUSINESS_DETAILS.phone2}</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
