import React from 'react';
import { Check, MessageCircle, PhoneCall, Sparkles } from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer } from './motion/MotionFade';

interface PricingPackage {
  name: string;
  tagline: string;
  priceEstimate: string;
  priceNote: string;
  isPopular?: boolean;
  features: string[];
}

const PACKAGES: PricingPackage[] = [
  {
    name: 'Home Ceremony / Pooja Package',
    tagline: 'Ideal for Haldi, Mehendi, Satyanarayana Vratam & Birthdays',
    priceEstimate: '₹8,500 – ₹15,000',
    priceNote: 'approx per day (50–150 guests)',
    features: [
      '18x24 ft Decorative Shamiana Canopy',
      '100 Banquet Chairs with Satin Covers',
      '5 Buffet & Dining Tables with Linens',
      'Compact Stage Backdrop & Carpet',
      'Warm LED Par Lighting & 2 Fans',
      'Delivery, Setup & Pickup Included'
    ]
  },
  {
    name: 'Grand Wedding & Reception Package',
    tagline: 'Full-service royal production for memorable marriages',
    priceEstimate: '₹45,000 – ₹95,000',
    priceNote: 'approx per day (500–1,500 guests)',
    isPopular: true,
    features: [
      'Grand Velvet Frill Shamiana or German Pagoda',
      '30x16 ft Royal Mandap / Reception Stage',
      'Handcrafted Maharaja Golden Throne Sofa',
      '500 VIP Chiavari Chairs & 25 Dining Tables',
      '4 Crystal Chandeliers + RGBW Ambient Lighting',
      'JBL Sound System + 2 Wireless Microphones',
      '4 Jumbo Air Coolers / Water Misting Fans',
      'Dedicated 24/7 Setup Crew on Location'
    ]
  },
  {
    name: 'Mega Convention / German Hangar',
    tagline: 'All-weather engineered hangar for 2,000+ guest galas & expos',
    priceEstimate: 'Custom Quotation',
    priceNote: 'tailored to venue sq. footage & days',
    features: [
      'Heavy Aluminum Alloy German Waterproof Hangar',
      '100% Wind & Rain-Proof White PVC Roof',
      'Red Carpet Paved Walkways & Stage',
      '1,000 to 5,000+ Chiavari or Banquet Chairs',
      'Full Banquet Food Counter Equipment & Degchas',
      'Line-Array High-Wattage Sound Coverage',
      'Industrial Power Distribution & High Mast Floodlights'
    ]
  }
];

export const PricingSection: React.FC = () => {
  return (
    <section id="pricing" className="py-20 sm:py-24 bg-[#FCF9F5] border-b border-amber-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <MotionHeading className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-semibold tracking-wider text-[#9E1B32] mb-2">
            Transparent Event Packages
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] tracking-tight">
            Popular Event Rental Packages
          </h2>
          <p className="mt-3 text-base text-neutral-600">
            Combine tents, seating, stage, audio, and dining gear into coordinated packages for substantial savings and hassle-free coordination.
          </p>
        </MotionHeading>

        {/* Packages Grid */}
        <MotionContainer delay={0.2} className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {PACKAGES.map((pkg) => (
            <div
              key={pkg.name}
              className={`rounded-3xl p-7 flex flex-col justify-between transition-all duration-300 relative ${
                pkg.isPopular
                  ? 'bg-gradient-to-b from-[#3E030B] to-[#2D0208] text-white shadow-2xl border-2 border-[#D4AF37] scale-100 lg:-translate-y-2'
                  : 'bg-white text-neutral-800 shadow-lg border border-amber-900/10 hover:shadow-xl'
              }`}
            >
              {pkg.isPopular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] text-xs font-extrabold uppercase tracking-wider px-4 py-1 rounded-full shadow-md flex items-center gap-1.5 whitespace-nowrap">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Most Selected for Weddings</span>
                </div>
              )}

              <div>
                <h3 className={`font-serif text-xl sm:text-2xl font-bold ${pkg.isPopular ? 'text-white' : 'text-[#38030B]'}`}>
                  {pkg.name}
                </h3>
                <p className={`text-xs mt-1 min-h-[32px] ${pkg.isPopular ? 'text-neutral-300' : 'text-neutral-500'}`}>
                  {pkg.tagline}
                </p>

                <div className="mt-6 pt-6 border-t border-white/15">
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#E5C158]">
                    Estimated Rate
                  </div>
                  <div className={`font-serif text-2xl sm:text-3xl font-extrabold mt-1 ${pkg.isPopular ? 'text-[#F3DE8A]' : 'text-[#7A1526]'}`}>
                    {pkg.priceEstimate}
                  </div>
                  <div className={`text-xs mt-0.5 ${pkg.isPopular ? 'text-neutral-400' : 'text-neutral-500'}`}>
                    {pkg.priceNote}
                  </div>
                </div>

                <div className="mt-6 space-y-2.5">
                  <span className={`text-xs font-bold uppercase tracking-wider block ${pkg.isPopular ? 'text-white/80' : 'text-neutral-700'}`}>
                    Package Highlights:
                  </span>
                  <ul className="space-y-2 text-xs">
                    {pkg.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2.5">
                        <Check className={`w-4 h-4 shrink-0 mt-0.5 ${pkg.isPopular ? 'text-[#E5C158]' : 'text-emerald-600'}`} />
                        <span className={pkg.isPopular ? 'text-neutral-200' : 'text-neutral-600'}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-white/15 space-y-2">
                <a
                  href={`https://wa.me/${BUSINESS_DETAILS.phoneRaw}?text=${encodeURIComponent(
                    `Hello Karimulla garu, I am interested in inquiring about the "${pkg.name}" for my upcoming event.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
                    pkg.isPopular
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106]'
                      : 'bg-[#7A1526] hover:bg-[#5C0614] text-white'
                  }`}
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Enquire for this Package</span>
                </a>

                <a
                  href={`tel:${BUSINESS_DETAILS.phoneRaw}`}
                  className={`w-full py-2 text-center text-xs block transition-colors ${
                    pkg.isPopular ? 'text-neutral-300 hover:text-white' : 'text-neutral-500 hover:text-neutral-800'
                  }`}
                >
                  <PhoneCall className="w-3 h-3 inline mr-1" />
                  Or call Karimulla: {BUSINESS_DETAILS.phone}
                </a>
              </div>
            </div>
          ))}
        </MotionContainer>

      </div>
    </section>
  );
};
