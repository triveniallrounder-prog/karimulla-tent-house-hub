import React, { useState, useEffect, useMemo } from 'react';
import { 
  Star, 
  Search, 
  SlidersHorizontal, 
  CheckCircle2, 
  MessageSquare, 
  ThumbsUp, 
  ShieldCheck, 
  ArrowRight, 
  Building2, 
  Tent, 
  Sparkles, 
  Plus, 
  X, 
  Send, 
  HeartHandshake, 
  Phone, 
  MessageCircle,
  Award,
  Clock,
  Filter
} from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { REVIEWS_SUMMARY, INITIAL_REVIEWS_DATA, ClientReview } from '../data/reviewsData';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { Sun, Moon } from 'lucide-react';

interface ClientReviewsPageProps {
  onSwitchToTentHouse: () => void;
  onSwitchToFounder: () => void;
  onSwitchToPartners: () => void;
  onSwitchToRealEstate: () => void;
}

export const ClientReviewsPage: React.FC<ClientReviewsPageProps> = ({
  onSwitchToTentHouse,
  onSwitchToFounder,
  onSwitchToPartners,
  onSwitchToRealEstate,
}) => {
  const { isTelugu, setLanguage } = useLanguage();
  const { toggleTheme, isDark } = useTheme();

  // Load reviews from localStorage + fallback to INITIAL_REVIEWS_DATA
  const [reviews, setReviews] = useState<ClientReview[]>(() => {
    try {
      const saved = localStorage.getItem('karimulla_client_reviews');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return INITIAL_REVIEWS_DATA;
  });

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'helpful' | 'newest' | 'highest'>('helpful');
  const [likedReviews, setLikedReviews] = useState<Record<string, boolean>>({});

  // Review Modal State
  const [isWriteModalOpen, setIsWriteModalOpen] = useState(false);
  const [newReviewForm, setNewReviewForm] = useState({
    name: '',
    location: '',
    eventType: 'Wedding & Reception',
    rating: 5,
    title: '',
    comment: ''
  });
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Sync reviews to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('karimulla_client_reviews', JSON.stringify(reviews));
    } catch {
      // ignore
    }
  }, [reviews]);

  const handleLike = (id: string) => {
    if (likedReviews[id]) return;
    setLikedReviews((prev) => ({ ...prev, [id]: true }));
    setReviews((prev) =>
      prev.map((r) => (r.id === id ? { ...r, helpfulCount: r.helpfulCount + 1 } : r))
    );
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewForm.name.trim() || !newReviewForm.comment.trim()) return;

    const newRev: ClientReview = {
      id: `user-rev-${Date.now()}`,
      name: newReviewForm.name.trim(),
      location: newReviewForm.location.trim() || 'Guntur, Andhra Pradesh',
      eventType: newReviewForm.eventType,
      category: 'weddings',
      rating: newReviewForm.rating,
      date: 'Just now',
      verified: true,
      avatarLetter: newReviewForm.name.trim().charAt(0).toUpperCase() || 'C',
      title: newReviewForm.title.trim() || 'Wonderful service and grand setup!',
      comment: newReviewForm.comment.trim(),
      helpfulCount: 1,
      highlightSpecs: 'Client Verified Review · On-Time Delivery',
      ownerReply: {
        date: 'Just now',
        message: 'Thank you so much for your kind rating and trust in Karimulla Tent House! We are delighted to serve your family event.'
      }
    };

    setReviews([newRev, ...reviews]);
    setSubmitSuccess(true);
    setTimeout(() => {
      setSubmitSuccess(false);
      setIsWriteModalOpen(false);
      setNewReviewForm({
        name: '',
        location: '',
        eventType: 'Wedding & Reception',
        rating: 5,
        title: '',
        comment: ''
      });
    }, 1500);
  };

  // Filtered & Sorted Reviews
  const filteredReviews = useMemo(() => {
    let result = reviews.filter((r) => {
      const matchesCategory =
        activeCategory === 'all' || r.category === activeCategory;
      const query = searchQuery.toLowerCase();
      const matchesSearch =
        !query ||
        r.name.toLowerCase().includes(query) ||
        r.location.toLowerCase().includes(query) ||
        r.comment.toLowerCase().includes(query) ||
        r.title.toLowerCase().includes(query) ||
        r.eventType.toLowerCase().includes(query);

      return matchesCategory && matchesSearch;
    });

    if (sortBy === 'helpful') {
      result.sort((a, b) => b.helpfulCount - a.helpfulCount);
    } else if (sortBy === 'newest') {
      result.sort((a, b) => b.id.localeCompare(a.id));
    } else if (sortBy === 'highest') {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [reviews, activeCategory, searchQuery, sortBy]);

  const categories = [
    { id: 'all', labelEn: 'All Reviews', labelTe: 'అన్ని రివ్యూలు' },
    { id: 'weddings', labelEn: 'Weddings & Mandap', labelTe: 'పెళ్లిళ్లు & మండపం' },
    { id: 'utensils', labelEn: 'Dabbalu & Utensils', labelTe: 'డబ్బాలు & వంట పాత్రలు' },
    { id: 'tents', labelEn: 'Waterproof Tents', labelTe: 'వాటర్ ప్రూఫ్ టెంట్లు' },
    { id: 'lighting', labelEn: 'Lighting & Sound', labelTe: 'లైటింగ్ & సౌండ్' },
    { id: 'birthday', labelEn: 'Birthday & Functions', labelTe: 'పుట్టినరోజు & వేడుకలు' },
    { id: 'realestate', labelEn: 'Real Estate Clients', labelTe: 'రియల్ ఎస్టేట్' },
  ];

  return (
    <div className="min-h-screen bg-[#FCF9F5] text-neutral-800 font-sans antialiased selection:bg-[#7A1526] selection:text-white pb-20 sm:pb-12">
      
      {/* 1. Header (Compact, Responsive, No Horizontal Overflow) */}
      <header className="sticky top-0 z-40 bg-[#38030B]/95 backdrop-blur-md shadow-lg border-b border-[#D4AF37]/30 py-2 text-white">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 flex items-center justify-between gap-2">
          
          {/* Brand Wordmark */}
          <div className="flex items-center gap-2 min-w-0 shrink">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#E5C158] to-[#B8860B] flex items-center justify-center text-[#38030B] font-bold text-base font-serif shrink-0 shadow-xs">
              K
            </div>
            <div className="min-w-0">
              <span className={`text-sm sm:text-base font-bold tracking-tight text-white block truncate leading-tight ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? 'క్లయింట్ రేటింగ్స్ & రివ్యూలు' : 'Client Ratings & Reviews'}
              </span>
              <span className="text-[10px] tracking-wide text-[#E5C158] font-sans font-medium hidden sm:block truncate">
                {BUSINESS_DETAILS.name} · Verified Experiences
              </span>
            </div>
          </div>

          {/* Header Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* Theme Toggle */}
            <button
              type="button"
              onClick={toggleTheme}
              className="p-1.5 sm:p-2 rounded-lg bg-black/40 hover:bg-black/60 text-[#F3DE8A] border border-[#D4AF37]/40 shadow-xs transition-colors shrink-0"
              title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
              aria-label="Toggle theme"
            >
              {isDark ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5 text-[#F3DE8A]" />}
            </button>

            {/* Language Toggle */}
            <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-[#D4AF37]/40 shrink-0">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-colors ${
                  !isTelugu ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] font-bold' : 'text-white/80'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-colors font-telugu ${
                  isTelugu ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#240106] font-bold' : 'text-white/80'
                }`}
              >
                తెలుగు
              </button>
            </div>

            {/* Real Estate Compact Button (Never Cut Off) */}
            <button
              onClick={onSwitchToRealEstate}
              className="flex items-center gap-1 px-2 py-1 text-xs font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white border border-emerald-400/50 transition-transform active:scale-95 shrink-0"
              title="Switch to Karimulla Real Estate"
            >
              <Building2 className="w-3 h-3 text-emerald-200" />
              <span className="hidden xs:inline">Real Estate</span>
              <span className="xs:hidden">RE</span>
            </button>

            {/* Back to Tent House Main Website */}
            <button
              onClick={onSwitchToTentHouse}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold transition-all shadow-xs shrink-0"
            >
              <Tent className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Home</span>
            </button>
          </div>
        </div>
      </header>

      {/* 2. Top Sub-Navigation Bar between pages */}
      <div className="bg-[#260106] text-white py-2 border-b border-[#D4AF37]/25 shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-3 overflow-x-auto no-scrollbar text-xs">
          <span className="text-[#E5C158] font-medium whitespace-nowrap flex items-center gap-1.5 shrink-0">
            <Sparkles className="w-3.5 h-3.5 text-[#E5C158]" />
            <span>4th Page: Client Ratings & Verified Testimonials</span>
          </span>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onSwitchToTentHouse}
              className="text-neutral-300 hover:text-white px-2 py-1 rounded transition-colors whitespace-nowrap"
            >
              1st Page: Main Tent House →
            </button>
            <button
              onClick={onSwitchToFounder}
              className="text-neutral-300 hover:text-white px-2 py-1 rounded transition-colors whitespace-nowrap"
            >
              2nd Page: Founder & Director →
            </button>
            <button
              onClick={onSwitchToPartners}
              className="text-neutral-300 hover:text-white px-2 py-1 rounded transition-colors whitespace-nowrap"
            >
              3rd Page: Trusted Partners & Teams →
            </button>
          </div>
        </div>
      </div>

      {/* 3. Hero Rating Overview Section */}
      <section className="bg-gradient-to-b from-[#38030B] via-[#4A040F] to-[#260106] text-white py-10 sm:py-14 border-b border-[#D4AF37]/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F3DE8A] text-xs font-semibold uppercase tracking-wider mb-3">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% Genuine Client Experiences</span>
            </div>
            <h1 className="font-serif text-2xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white mb-3">
              {isTelugu ? 'కరిముల్లా టెంట్ హౌస్ క్లయింట్ రేటింగ్స్' : 'What Our Hosts & Families Say'}
            </h1>
            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed max-w-2xl mx-auto">
              {isTelugu 
                ? 'గుంటూరు మరియు చుట్టుపక్కల ప్రాంతాలలో జరిగిన శుభకార్యాలు, వివాహాలు, మరియు అన్నదాన కార్యక్రమాలకు అందించిన సేవలపై మా క్లయింట్ల అభిప్రాయాలు.' 
                : 'Read firsthand verified feedback from families, temple trustees, and wedding planners who entrusted their most memorable celebrations to Karimulla Tent House.'}
            </p>
          </div>

          {/* Aggregate Rating Cards Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-black/30 backdrop-blur-md rounded-2xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-2xl">
            
            {/* Big Rating Score Card (Cols 1-4) */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center text-center p-4 border-b lg:border-b-0 lg:border-r border-[#D4AF37]/20">
              <div className="font-serif text-5xl sm:text-6xl font-bold text-[#E5C158] tracking-tight mb-2">
                {REVIEWS_SUMMARY.averageRating}
              </div>
              <div className="flex items-center gap-1 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 text-amber-400 fill-amber-400" />
                ))}
              </div>
              <div className="text-sm font-semibold text-white">
                Outstanding {REVIEWS_SUMMARY.averageRating} out of 5.0
              </div>
              <div className="text-xs text-neutral-300 mt-1">
                Based on <span className="font-bold text-[#E5C158]">{REVIEWS_SUMMARY.totalReviews} verified ratings</span> across Guntur District
              </div>
              <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{REVIEWS_SUMMARY.recommendedPercentage}% Clients Recommend Us</span>
              </div>

              {/* Write Review CTA Button */}
              <button
                onClick={() => setIsWriteModalOpen(true)}
                className="mt-6 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-sm shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isTelugu ? 'మీ రివ్యూ రాయండి' : 'Write a Review / Leave Rating'}</span>
              </button>
            </div>

            {/* Rating Breakdown Bars (Cols 5-8) */}
            <div className="lg:col-span-4 flex flex-col justify-center px-0 lg:px-4 py-2 border-b lg:border-b-0 lg:border-r border-[#D4AF37]/20 space-y-2.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#E5C158] mb-1">
                Rating Breakdown
              </div>
              {REVIEWS_SUMMARY.ratingDistribution.map((dist) => (
                <div key={dist.stars} className="flex items-center gap-3 text-xs">
                  <span className="w-12 font-medium text-neutral-300 flex items-center gap-1">
                    <span>{dist.stars}</span>
                    <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                  </span>
                  <div className="flex-1 h-2 rounded-full bg-white/10 overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-amber-400 to-[#D4AF37] rounded-full transition-all duration-500"
                      style={{ width: `${dist.percentage}%` }}
                    />
                  </div>
                  <span className="w-10 text-right text-neutral-300 font-semibold tabular-nums">
                    {dist.percentage}%
                  </span>
                </div>
              ))}
            </div>

            {/* Quality Metrics Criteria (Cols 9-12) */}
            <div className="lg:col-span-4 flex flex-col justify-center px-0 lg:px-2 space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#E5C158] mb-1">
                Verified Quality Metrics
              </div>
              {REVIEWS_SUMMARY.serviceRatings.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-white/5">
                  <span className="text-neutral-300 truncate pr-2">{item.metric}</span>
                  <span className="font-bold text-[#E5C158] shrink-0">{item.score}</span>
                </div>
              ))}
            </div>

          </div>

        </div>
      </section>

      {/* 4. Filter & Search Controls */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4 relative z-20">
        <div className="bg-white rounded-2xl shadow-xl border border-amber-900/10 p-4 sm:p-5">
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                placeholder={isTelugu ? 'రివ్యూలలో వెతకండి (ఉదా: డబ్బాలు, వర్షం, పెళ్లి)...' : 'Search reviews (e.g., dabbalu, rain, wedding)...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-neutral-200 focus:border-[#D4AF37] focus:outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Sort Selector & Count */}
            <div className="flex items-center justify-between w-full md:w-auto gap-3 text-xs">
              <span className="text-neutral-500 font-medium">
                Showing <strong className="text-neutral-800 font-bold">{filteredReviews.length}</strong> of {reviews.length} reviews
              </span>

              <div className="flex items-center gap-1.5">
                <span className="text-neutral-500">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="px-2.5 py-1.5 rounded-lg border border-neutral-200 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] bg-white cursor-pointer"
                >
                  <option value="helpful">Most Helpful</option>
                  <option value="newest">Newest First</option>
                  <option value="highest">Highest Rating</option>
                </select>
              </div>
            </div>

          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 sm:gap-2 mt-4 overflow-x-auto no-scrollbar pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#7A1526] text-white shadow-xs'
                    : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700'
                } ${isTelugu ? 'font-telugu' : 'font-sans'}`}
              >
                {isTelugu ? cat.labelTe : cat.labelEn}
              </button>
            ))}
          </div>

        </div>
      </section>

      {/* 5. Reviews List Display */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        
        {filteredReviews.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-amber-900/10 shadow-sm max-w-lg mx-auto">
            <MessageSquare className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
            <h3 className="font-serif text-lg font-bold text-neutral-800">No reviews found matching your search</h3>
            <p className="text-xs text-neutral-500 mt-1 mb-4">Try clearing the search query or switching category filter.</p>
            <button
              onClick={() => { setSearchQuery(''); setActiveCategory('all'); }}
              className="px-4 py-2 rounded-xl bg-[#7A1526] text-white text-xs font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredReviews.map((rev) => (
              <article
                key={rev.id}
                className="bg-white rounded-2xl p-6 sm:p-7 border border-amber-900/10 shadow-md hover:shadow-lg transition-shadow flex flex-col justify-between"
              >
                <div>
                  
                  {/* Top Header: Avatar + Author + Rating */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#7A1526] to-[#4A040F] text-[#F3DE8A] font-bold font-serif flex items-center justify-center shadow-xs shrink-0 text-base">
                        {rev.avatarLetter}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h3 className="font-serif text-sm sm:text-base font-bold text-[#38030B]">
                            {isTelugu && rev.nameTelugu ? rev.nameTelugu : rev.name}
                          </h3>
                          {rev.verified && (
                            <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-200">
                              <CheckCircle2 className="w-2.5 h-2.5" />
                              <span>Verified Host</span>
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-500">
                          {rev.location} · <span className="text-neutral-400">{rev.date}</span>
                        </div>
                      </div>
                    </div>

                    {/* Star Rating */}
                    <div className="flex items-center gap-0.5 shrink-0 bg-amber-50 px-2 py-1 rounded-lg border border-amber-200/60">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                      ))}
                    </div>
                  </div>

                  {/* Event Type Badge */}
                  <div className="mb-3">
                    <span className="inline-block text-[11px] font-semibold text-[#7A1526] bg-[#7A1526]/8 px-2.5 py-0.5 rounded-full border border-[#7A1526]/15">
                      Event: {isTelugu && rev.eventTypeTelugu ? rev.eventTypeTelugu : rev.eventType}
                    </span>
                  </div>

                  {/* Review Headline & Body */}
                  <h4 className="font-sans text-sm sm:text-base font-bold text-neutral-900 mb-2 leading-snug">
                    {rev.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed mb-4">
                    &ldquo;{isTelugu && rev.commentTelugu ? rev.commentTelugu : rev.comment}&rdquo;
                  </p>

                  {/* Highlight Specs Tag */}
                  {rev.highlightSpecs && (
                    <div className="mb-4 text-[11px] text-neutral-500 bg-neutral-50 px-3 py-1.5 rounded-lg border border-neutral-200/60 flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 text-[#B8860B] shrink-0" />
                      <span className="truncate">{rev.highlightSpecs}</span>
                    </div>
                  )}

                  {/* Official Owner Reply Box */}
                  {rev.ownerReply && (
                    <div className="bg-[#FAF7F2] rounded-xl p-3.5 border-l-4 border-[#7A1526] mb-4 text-xs text-neutral-700">
                      <div className="flex items-center justify-between text-[11px] font-bold text-[#38030B] mb-1">
                        <span className="flex items-center gap-1">
                          <HeartHandshake className="w-3.5 h-3.5 text-[#7A1526]" />
                          <span>Response from Prop. Shaik Karimulla (Babu) Garu</span>
                        </span>
                        <span className="text-neutral-400 font-normal">{rev.ownerReply.date}</span>
                      </div>
                      <p className="italic text-neutral-600 leading-relaxed">
                        {isTelugu && rev.ownerReply.messageTelugu ? rev.ownerReply.messageTelugu : rev.ownerReply.message}
                      </p>
                    </div>
                  )}

                </div>

                {/* Bottom Card Footer: Helpful button */}
                <div className="flex items-center justify-between pt-3 border-t border-neutral-100 text-xs">
                  <span className="text-neutral-400 text-[11px]">
                    Did this review help you?
                  </span>
                  <button
                    onClick={() => handleLike(rev.id)}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                      likedReviews[rev.id]
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                        : 'hover:bg-neutral-50 text-neutral-600 border-neutral-200'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>Helpful ({rev.helpfulCount})</span>
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}

      </section>

      {/* 6. Bottom Host Assurance Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="bg-gradient-to-r from-[#38030B] to-[#5C0614] rounded-3xl p-8 sm:p-10 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-[#D4AF37]/30">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-[#E5C158] text-xs font-bold uppercase tracking-wider mb-2">
              <Award className="w-4 h-4" />
              <span>Karimulla Tent House Guarantee</span>
            </div>
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-white mb-2">
              Planning an upcoming wedding, ceremony, or feast?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              Experience the same 5-star reliability trusted by over 480+ Guntur families. Call or WhatsApp Shaik Karimulla (Babu) Garu directly for customized pandal layouts and transparent quotation.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 w-full md:w-auto">
            <a
              href={`tel:+${BUSINESS_DETAILS.phone1Raw}`}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-white text-[#38030B] font-bold text-xs sm:text-sm hover:bg-neutral-100 transition-colors shadow-md flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 text-[#7A1526]" />
              <span>Call: {BUSINESS_DETAILS.phone1}</span>
            </a>
            <a
              href={`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent('Hello Karimulla garu, I saw your 5-star client ratings on your website and want to discuss booking for our upcoming event.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm transition-colors shadow-md flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-200" />
              <span>WhatsApp Consultation</span>
            </a>
          </div>
        </div>
      </section>

      {/* 7. Interactive "Write a Review" Modal */}
      {isWriteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-amber-900/10 relative max-h-[90vh] overflow-y-auto">
            
            <button
              onClick={() => setIsWriteModalOpen(false)}
              className="absolute top-5 right-5 p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {submitSuccess ? (
              <div className="py-8 text-center">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-xl font-bold text-neutral-900 mb-1">
                  Thank You for Your Review!
                </h3>
                <p className="text-xs text-neutral-600">
                  Your feedback has been published and added to our ratings. Prop. Shaik Karimulla and our crew deeply appreciate your support.
                </p>
              </div>
            ) : (
              <div>
                <div className="mb-6">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#7A1526]">
                    Share Your Feedback
                  </span>
                  <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#38030B]">
                    Write a Review for Karimulla Tent House
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1">
                    Help fellow families choose the best wedding pandals, cooking vessels, and event infrastructure.
                  </p>
                </div>

                <form onSubmit={handleReviewSubmit} className="space-y-4 text-xs">
                  
                  {/* Star Rating Picker */}
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1.5">
                      Your Rating (Tap to select) *
                    </label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewReviewForm({ ...newReviewForm, rating: star })}
                          className="p-1 text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star
                            className={`w-7 h-7 ${
                              star <= newReviewForm.rating
                                ? 'fill-amber-400 text-amber-400'
                                : 'text-neutral-200'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="ml-2 font-bold text-sm text-neutral-800">
                        {newReviewForm.rating}.0 / 5.0
                      </span>
                    </div>
                  </div>

                  {/* Name & Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-neutral-700 mb-1">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Ramesh Varma"
                        value={newReviewForm.name}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, name: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-neutral-300 focus:border-[#D4AF37] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-neutral-700 mb-1">
                        City / Location
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Brodipet, Guntur"
                        value={newReviewForm.location}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, location: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl border border-neutral-300 focus:border-[#D4AF37] focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Event Type */}
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Event / Service Type
                    </label>
                    <select
                      value={newReviewForm.eventType}
                      onChange={(e) => setNewReviewForm({ ...newReviewForm, eventType: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-300 focus:border-[#D4AF37] focus:outline-none bg-white"
                    >
                      <option value="Wedding & Reception">Wedding & Reception (పెళ్లి & రిసెప్షన్)</option>
                      <option value="Cooking Utensils & Dabbalu Hire">Cooking Utensils & Dabbalu Hire (వంట పాత్రలు)</option>
                      <option value="Waterproof German Tent">Waterproof German Tent (వాటర్ ప్రూఫ్ టెంట్)</option>
                      <option value="Birthday / Half-Saree Ceremony">Birthday / Half-Saree Ceremony</option>
                      <option value="Temple Festival / Annadanam">Temple Festival / Annadanam</option>
                      <option value="Karimulla Real Estate Property">Karimulla Real Estate Property</option>
                    </select>
                  </div>

                  {/* Headline */}
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Review Headline
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Prompt setup and pristine clean equipment!"
                      value={newReviewForm.title}
                      onChange={(e) => setNewReviewForm({ ...newReviewForm, title: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-300 focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>

                  {/* Detailed Comments */}
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Your Detailed Experience *
                    </label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Tell us about the tent quality, setup punctuality, and staff behavior..."
                      value={newReviewForm.comment}
                      onChange={(e) => setNewReviewForm({ ...newReviewForm, comment: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-300 focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#7A1526] to-[#4A040F] hover:from-[#5C0614] hover:to-[#38030B] text-white font-bold shadow-md transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>Submit Review & Rating</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
