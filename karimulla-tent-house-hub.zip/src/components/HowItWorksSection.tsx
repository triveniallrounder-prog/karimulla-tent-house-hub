import React from 'react';
import { HOW_IT_WORKS_STEPS } from '../data/rentalData';
import { CheckCircle, CalendarCheck, Truck, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer } from './motion/MotionFade';

const STEP_ICONS = [
  Sparkles,
  CalendarCheck,
  Truck,
  CheckCircle,
];

export const HowItWorksSection: React.FC = () => {
  return (
    <section className="py-20 sm:py-24 bg-[#FCF9F5] border-b border-amber-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <MotionHeading className="text-center max-w-3xl mx-auto mb-16">
          <div className="text-xs uppercase font-semibold tracking-wider text-[#9E1B32] mb-2">
            Seamless 4-Step Process
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] tracking-tight">
            How It Works
          </h2>
          <p className="mt-3 text-base text-neutral-600">
            From initial item selection to post-event teardown, our workflow ensures your celebration runs smoothly without stress.
          </p>
        </MotionHeading>

        {/* Timeline Grid with Connecting Line */}
        <div className="relative">
          
          {/* Desktop Connecting Horizontal Line */}
          <div
            aria-hidden="true"
            className="hidden lg:block absolute top-1/2 left-12 right-12 h-0.5 bg-gradient-to-r from-[#D4AF37] via-[#9E1B32] to-[#D4AF37] -translate-y-8 z-0 opacity-30"
          />

          <MotionContainer delay={0.2} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {HOW_IT_WORKS_STEPS.map((step, idx) => {
              const Icon = STEP_ICONS[idx % STEP_ICONS.length];
              return (
                <div
                  key={step.step}
                  className="bg-white rounded-2xl p-6 border border-amber-900/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group hover:-translate-y-1"
                >
                  <div>
                    {/* Top Index & Icon Lockup */}
                    <div className="flex items-center justify-between mb-5">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#7A1526] to-[#4A040F] text-[#F3DE8A] flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="font-serif text-3xl font-extrabold text-[#D4AF37]/50 group-hover:text-[#D4AF37] transition-colors tabular-nums">
                        {step.step}
                      </span>
                    </div>

                    <span className="text-xs uppercase tracking-wider text-[#9E1B32] font-semibold block mb-1">
                      {step.subtitle}
                    </span>

                    <h3 className="font-serif text-lg font-bold text-[#38030B] leading-snug">
                      {step.title}
                    </h3>

                    <p className="text-xs text-neutral-600 mt-2.5 leading-relaxed">
                      {step.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center gap-1.5 text-[11px] text-neutral-400 font-medium">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Quality Assured</span>
                  </div>
                </div>
              );
            })}
          </MotionContainer>

        </div>

      </div>
    </section>
  );
};
