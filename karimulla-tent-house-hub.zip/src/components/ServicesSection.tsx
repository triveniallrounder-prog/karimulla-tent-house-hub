import React from 'react';
import { EVENT_SERVICES, EventService, BUSINESS_DETAILS } from '../data/rentalData';
import { Users, CheckCircle2, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer } from './motion/MotionFade';

interface ServicesSectionProps {
  onSelectEventType: (eventType: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectEventType }) => {
  return (
    <section id="services" className="py-20 sm:py-24 bg-[#FCF9F5] border-b border-amber-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <MotionHeading className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs uppercase font-semibold tracking-wider text-[#9E1B32] mb-2">
            Tailored Event Production
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] tracking-tight">
            Comprehensive Event Services
          </h2>
          <p className="mt-3 text-base text-neutral-600">
            From intimate home ceremonies to mammoth 5,000-guest outdoor wedding receptions, we provide complete turnkey tent, furniture, lighting, and audio infrastructure.
          </p>
        </MotionHeading>

        {/* 4 Core Event Types Grid */}
        <MotionContainer delay={0.2} className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {EVENT_SERVICES.map((service: EventService, index: number) => {
            return (
              <div
                key={service.id}
                className="bg-white rounded-2xl overflow-hidden border border-amber-900/10 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col"
              >
                {/* Visual Header */}
                <div className="relative h-60 sm:h-64 w-full overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover brightness-110 group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#240106]/72 via-[#240106]/20 to-transparent" />
                  
                  {/* Top floating index */}
                  <div className="absolute top-4 left-4 bg-white/20 backdrop-blur-md text-white text-xs font-mono px-3 py-1 rounded-full border border-white/30">
                    0{index + 1}. Event Tier
                  </div>

                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <span className="text-xs text-[#F3DE8A] font-medium block">
                      {service.teluguTitle}
                    </span>
                    <h3 className="font-serif text-2xl font-bold text-white mt-0.5">
                      {service.title}
                    </h3>
                  </div>
                </div>

                {/* Body Details */}
                <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-6">
                  
                  <div className="space-y-4">
                    <p className="text-xs uppercase tracking-wider text-[#9E1B32] font-semibold">
                      {service.subtitle}
                    </p>
                    <p className="text-sm text-neutral-600 leading-relaxed">
                      {service.description}
                    </p>

                    {/* Capacity badge */}
                    <div className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-700 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
                      <Users className="w-4 h-4 text-[#7A1526]" />
                      <span>Capacity: {service.capacity}</span>
                    </div>

                    {/* Recommended Setup Checklist */}
                    <div className="pt-2 space-y-2">
                      <span className="text-xs font-bold text-neutral-800 uppercase tracking-wide block">
                        Included Setup Components:
                      </span>
                      <ul className="space-y-1.5 text-xs text-neutral-600">
                        {service.recommendedSetup.map((item, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Action CTA */}
                  <div className="pt-4 border-t border-amber-900/10 flex items-center justify-between">
                    <button
                      onClick={() => {
                        onSelectEventType(service.title);
                        const contactEl = document.getElementById('contact');
                        if (contactEl) {
                          contactEl.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-[#7A1526] hover:text-[#4A040F] transition-colors group cursor-pointer"
                    >
                      <span>Book Infrastructure for this Event</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>

                    <a
                      href={`https://wa.me/${BUSINESS_DETAILS.phoneRaw}?text=${encodeURIComponent(
                        `Hello Karimulla garu, I am interested in booking tent and event setup for a ${service.title}.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-neutral-500 hover:text-emerald-700 underline"
                    >
                      Quick WhatsApp
                    </a>
                  </div>

                </div>
              </div>
            );
          })}
        </MotionContainer>

      </div>
    </section>
  );
};
