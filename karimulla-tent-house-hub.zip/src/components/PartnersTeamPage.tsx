import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  Phone, 
  MessageCircle, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Tent, 
  Users, 
  Award, 
  Sparkles, 
  Clock, 
  User, 
  Image as ImageIcon,
  HeartHandshake,
  Layers,
  Zap,
  Flower2,
  Truck,
  UtensilsCrossed,
  SlidersHorizontal,
  ChevronRight,
  Star
} from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { SPECIFIC_TEAMS_DATA, TRUSTED_PARTNERS_DATA, SpecificTeam, TeamMember, TrustedPartner } from '../data/partnersTeamData';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { Sun, Moon } from 'lucide-react';
import { TeamMembersAnimatedScroll } from './TeamMembersAnimatedScroll';

interface PartnersTeamPageProps {
  onSwitchToTentHouse: () => void;
  onSwitchToFounder: () => void;
  onSwitchToRealEstate: () => void;
  onSwitchToReviews?: () => void;
}

export const PartnersTeamPage: React.FC<PartnersTeamPageProps> = ({
  onSwitchToTentHouse,
  onSwitchToFounder,
  onSwitchToRealEstate,
  onSwitchToReviews,
}) => {
  const { isTelugu, setLanguage } = useLanguage();
  const { toggleTheme, isDark } = useTheme();
  const [selectedTeamTab, setSelectedTeamTab] = useState<string>('all');
  const [activePartnerCategory, setActivePartnerCategory] = useState<string>('all');

  const filteredTeams = selectedTeamTab === 'all'
    ? SPECIFIC_TEAMS_DATA
    : SPECIFIC_TEAMS_DATA.filter((t) => t.id === selectedTeamTab);

  const getTeamIcon = (teamId: string) => {
    switch (teamId) {
      case 'team-decoration':
        return <Flower2 className="w-5 h-5 text-pink-500" />;
      case 'team-lighting':
        return <Zap className="w-5 h-5 text-amber-500" />;
      case 'team-tents':
        return <Tent className="w-5 h-5 text-blue-500" />;
      case 'team-utensils':
        return <UtensilsCrossed className="w-5 h-5 text-red-500" />;
      case 'team-logistics':
        return <Truck className="w-5 h-5 text-emerald-500" />;
      default:
        return <Users className="w-5 h-5 text-[#E5C158]" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FCF9F5] text-neutral-800 font-sans antialiased selection:bg-[#7A1526] selection:text-white pb-20 sm:pb-0">
      
      {/* Top Header (Compact & Mobile Responsive) */}
      <header className="sticky top-0 z-40 bg-[#38030B]/95 backdrop-blur-md shadow-lg border-b border-[#D4AF37]/30 py-2 text-white">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8 flex items-center justify-between gap-2">
          
          {/* Brand */}
          <div className="flex items-center gap-2 min-w-0 shrink">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#E5C158] to-[#B8860B] flex items-center justify-center text-[#38030B] font-bold text-base font-serif shrink-0 shadow-xs">
              K
            </div>
            <div className="min-w-0">
              <span className={`text-xs sm:text-base font-bold tracking-tight text-white block leading-tight truncate ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? 'భాగస్వాములు & బృందం' : 'Partners & Teams'}
              </span>
              <span className="text-[10px] tracking-wide text-[#E5C158] font-sans font-medium hidden md:block truncate">
                Karimulla Tent House · Specialist Crews
              </span>
            </div>
          </div>

          {/* Quick Page Nav Buttons */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            
            {/* Dark Mode / Light Mode Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              className="p-1 sm:p-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-[#F3DE8A] border border-[#D4AF37]/40 shadow-xs transition-colors cursor-pointer shrink-0"
              title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
              aria-label={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDark ? (
                <Sun className="w-3.5 h-3.5 text-amber-300" />
              ) : (
                <Moon className="w-3.5 h-3.5 text-[#F3DE8A]" />
              )}
            </button>

            {/* Language Toggle */}
            <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-[#D4AF37]/40 text-xs shrink-0">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
                  !isTelugu ? 'bg-[#D4AF37] text-[#240106] font-bold' : 'text-white/80 hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                className={`px-1.5 py-0.5 text-[11px] rounded font-telugu transition-colors cursor-pointer ${
                  isTelugu ? 'bg-[#D4AF37] text-[#240106] font-bold' : 'text-white/80 hover:text-white'
                }`}
              >
                తెలుగు
              </button>
            </div>

            {/* Switch to Tent House Home */}
            <button
              onClick={onSwitchToTentHouse}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-[#F3DE8A] border border-[#D4AF37]/40 transition-colors cursor-pointer shrink-0"
              title="Return to Karimulla Tent House Home"
            >
              <Tent className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isTelugu ? 'హోమ్' : 'Home'}</span>
            </button>

            {/* Switch to Founder & Director (Page 2) */}
            <button
              onClick={onSwitchToFounder}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-white border border-[#D4AF37]/40 transition-colors cursor-pointer shrink-0"
              title="View Founder & Director Page"
            >
              <User className="w-3.5 h-3.5 text-[#E5C158]" />
              <span className="hidden sm:inline">{isTelugu ? 'డైరెక్టర్ (2nd)' : 'Founder (2nd)'}</span>
            </button>

            {/* Switch to Reviews (4th Page) */}
            {onSwitchToReviews && (
              <button
                onClick={onSwitchToReviews}
                className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-[#F3DE8A] border border-[#D4AF37]/40 transition-colors cursor-pointer shrink-0"
                title="View Client Reviews & Ratings"
              >
                <Star className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                <span className="hidden md:inline">{isTelugu ? 'రేటింగ్స్ (4th)' : 'Reviews (4th)'}</span>
              </button>
            )}

            {/* Switch to Real Estate (Guaranteed to Never Cut Off) */}
            <button
              onClick={onSwitchToRealEstate}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white shadow-xs border border-emerald-400/50 transition-transform active:scale-95 cursor-pointer shrink-0"
              title="Open Karimulla Real Estate"
            >
              <Building2 className="w-3.5 h-3.5 text-emerald-200 shrink-0" />
              <span className="hidden sm:inline font-sans">{isTelugu ? 'రియల్ ఎస్టేట్' : 'Real Estate'}</span>
              <span className="sm:hidden font-sans font-bold">RE</span>
            </button>
          </div>

        </div>
      </header>

      {/* Hero Section */}
      <section className="py-14 sm:py-20 bg-gradient-to-b from-[#2D0208] via-[#38030B] to-[#4A040F] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F3DE8A] text-xs sm:text-sm font-semibold uppercase tracking-wider mb-4">
            <Users className="w-4 h-4 text-[#E5C158]" />
            <span>Trusted Partners & Specialized Teams</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight">
            {isTelugu ? 'మా విశ్వసనీయ బృందాలు & భాగస్వాములు' : 'Our Specialized Teams & Trusted Partners'}
          </h1>

          <p className="mt-4 text-base sm:text-lg text-neutral-200 max-w-3xl mx-auto font-sans leading-relaxed text-balance">
            Every grand event is executed by dedicated in-house craftsmen — from our floral decoration team and lighting engineers to waterproof tent riggers and transport dispatchers.
          </p>

          {/* Quick Team Highlights */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mt-10 pt-6 border-t border-white/10 text-center">
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#F3DE8A] block">5 Dedicated</span>
              <span className="text-xs text-neutral-300">Specialized In-House Teams</span>
            </div>
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#F3DE8A] block">45+ Experts</span>
              <span className="text-xs text-neutral-300">Full-Time Trained Crew</span>
            </div>
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#F3DE8A] block">12 Vehicles</span>
              <span className="text-xs text-neutral-300">Dedicated Transport Fleet</span>
            </div>
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#F3DE8A] block">24/7 On-Site</span>
              <span className="text-xs text-neutral-300">Direct Event Supervision</span>
            </div>
          </div>

        </div>
      </section>

      {/* SIDE-BY-SIDE ANIMATED TEAM MEMBERS SHOWCASE */}
      <TeamMembersAnimatedScroll 
        title={isTelugu ? 'కళాకారుల బృందం (సైడ్-బై-సైడ్ స్క్రోలింగ్)' : 'All Team Members (Animated Side-by-Side Scrolling)'}
        subtitle={isTelugu 
          ? 'మా టెంట్, డెకరేషన్, లైటింగ్ మరియు వంటపాత్రల బృంద సభ్యులు సైడ్-బై-సైడ్ ఆటో-స్క్రోలింగ్ రూపంలో.'
          : 'Browse all verified craftsmen animated side-by-side. Tap or hover over any card to pause and contact directly.'}
      />

      {/* SECTION 1: SPECIFIC TEAMS (Decoration Team, Lighting Team, Tent Crew, etc.) */}
      <section id="specific-teams" className="py-16 sm:py-20 bg-white border-b border-amber-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-10">
            <span className="text-xs uppercase font-bold tracking-widest text-[#9E1B32]">
              In-House Crew Divisions
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#38030B] mt-1">
              Meet Our Specific Dedicated Teams
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 mt-2">
              Each specialized unit operates under direct supervision with certified leads, dedicated phone lines, and specialized equipment.
            </p>
          </div>

          {/* Team Tabs Filter */}
          <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
            <button
              onClick={() => setSelectedTeamTab('all')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                selectedTeamTab === 'all'
                  ? 'bg-[#7A1526] text-white shadow-md'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              All Teams (అన్ని టీమ్స్)
            </button>
            {SPECIFIC_TEAMS_DATA.map((t) => (
              <button
                key={t.id}
                onClick={() => setSelectedTeamTab(t.id)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  selectedTeamTab === t.id
                    ? 'bg-[#7A1526] text-white shadow-md'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                {getTeamIcon(t.id)}
                <span>{isTelugu ? t.teluguName : t.name}</span>
              </button>
            ))}
          </div>

          {/* Specific Teams Detailed Blocks */}
          <div className="space-y-16">
            {filteredTeams.map((team) => (
              <div 
                key={team.id}
                className="p-6 sm:p-8 rounded-3xl bg-[#FAF7F2] border border-amber-900/15 shadow-sm space-y-6"
              >
                {/* Team Header Info */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-amber-900/10">
                  <div className="flex items-start gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-amber-900/10 flex items-center justify-center shrink-0">
                      {getTeamIcon(team.id)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#38030B]">
                          {team.name}
                        </h3>
                        <span className="text-[10px] font-bold bg-[#D4AF37]/30 text-[#4A040F] px-2.5 py-0.5 rounded-full">
                          {team.badge}
                        </span>
                      </div>
                      <p className="font-telugu text-sm font-semibold text-[#7A1526] mt-0.5">
                        {team.teluguName}
                      </p>
                      <p className="text-xs text-neutral-600 mt-1 max-w-xl">
                        {team.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                    <div className="text-left md:text-right">
                      <span className="text-[11px] text-neutral-500 block">Team Lead:</span>
                      <strong className="text-xs sm:text-sm text-neutral-800">{team.leadName}</strong>
                    </div>

                    <a
                      href={`tel:+${team.leadPhoneRaw}`}
                      className="px-4 py-2 rounded-xl bg-white hover:bg-neutral-50 text-[#7A1526] border border-amber-900/20 font-bold text-xs flex items-center gap-1.5 shadow-xs whitespace-nowrap"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#9E1B32]" />
                      <span>{team.leadPhone}</span>
                    </a>
                  </div>
                </div>

                {/* Team Members Animated Side-by-Side Scroll / Grid */}
                <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-4 gap-5 overflow-x-auto sm:overflow-visible pb-3 sm:pb-0 scroll-smooth no-scrollbar">
                  {team.members.map((member) => (
                    <div
                      key={member.id}
                      className="min-w-[260px] sm:min-w-0 shrink-0 sm:shrink bg-white rounded-2xl p-4 border border-amber-900/10 shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col justify-between group"
                    >
                      <div>
                        {/* Member Photo Slot */}
                        <div className="relative h-36 w-full rounded-xl bg-gradient-to-br from-amber-100/60 to-stone-100 border border-dashed border-amber-300 flex flex-col items-center justify-center p-3 text-center mb-3 overflow-hidden">
                          {member.photo ? (
                            <img
                              src={member.photo}
                              alt={member.name}
                              className="w-full h-full object-cover rounded-lg group-hover:scale-105 transition-transform"
                            />
                          ) : (
                            <div className="flex flex-col items-center justify-center text-neutral-400 group-hover:text-[#7A1526] transition-colors">
                              <User className="w-10 h-10 mb-1" />
                              <span className="text-[10px] font-sans font-medium">
                                Member Photo Slot
                              </span>
                              <span className="text-[8px] text-neutral-400">
                                (Upload Picture)
                              </span>
                            </div>
                          )}

                          <div className="absolute top-2 right-2 bg-white/90 text-neutral-600 text-[9px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                            {member.experience}
                          </div>
                        </div>

                        {/* Name & Roles */}
                        <h4 className="font-telugu text-base font-bold text-[#38030B] group-hover:text-[#7A1526] transition-colors">
                          {member.teluguName || member.name}
                        </h4>
                        <p className="text-xs font-sans font-semibold text-neutral-600">
                          {member.name}
                        </p>
                        <span className="inline-block mt-1 text-[11px] font-medium text-[#9E1B32] bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/60">
                          {member.role}
                        </span>

                        <p className="text-[11px] text-neutral-500 mt-2 leading-relaxed">
                          Speciality: <strong>{member.speciality}</strong>
                        </p>
                      </div>

                      {/* Member Contact Action */}
                      <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between gap-2">
                        <a
                          href={`tel:+${member.phoneRaw}`}
                          className="flex-1 py-1.5 px-2 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                        >
                          <Phone className="w-3 h-3 text-[#7A1526]" />
                          <span>{member.phone}</span>
                        </a>

                        <a
                          href={`https://wa.me/${member.phoneRaw}?text=${encodeURIComponent(
                            `Hello ${member.name}, I am contacting you regarding your ${team.name} service for an upcoming event in Guntur.`
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 rounded-lg bg-[#25D366]/15 hover:bg-[#25D366]/25 text-emerald-800 transition-colors"
                          title="WhatsApp this team member"
                        >
                          <MessageCircle className="w-4 h-4 text-emerald-600 fill-current" />
                        </a>
                      </div>

                    </div>
                  ))}
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* SECTION 2: TRUSTED PARTNERS NETWORK */}
      <section id="trusted-partners" className="py-16 sm:py-24 bg-[#FAF7F2] border-b border-amber-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold uppercase tracking-wider mb-2">
              <HeartHandshake className="w-3.5 h-3.5 text-emerald-700" />
              <span>Certified Vendor Ecosystem</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-neutral-900 tracking-tight">
              Our Trusted Partners
            </h2>
            <p className="text-sm sm:text-base text-neutral-600 mt-2">
              We collaborate with Guntur&apos;s finest catering masters, fresh flower decorators, cinematic wedding videographers, and pro audio engineers for cohesive event execution.
            </p>
          </div>

          {/* Partners Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {TRUSTED_PARTNERS_DATA.map((partner) => (
              <div
                key={partner.id}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-900/15 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#9E1B32] bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                        {partner.category}
                      </span>
                      <h3 className="font-serif text-xl sm:text-2xl font-bold text-neutral-900 mt-1.5">
                        {partner.businessName}
                      </h3>
                      <p className="font-telugu text-sm text-[#7A1526] font-semibold mt-0.5">
                        {partner.teluguName}
                      </p>
                    </div>

                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-1 rounded-full shrink-0">
                      {partner.badge}
                    </span>
                  </div>

                  {/* Partner Photo Slot */}
                  <div className="h-40 w-full rounded-2xl bg-gradient-to-br from-amber-50 via-slate-50 to-amber-100/60 border border-dashed border-amber-300 flex flex-col items-center justify-center p-3 mb-5 text-center">
                    <ImageIcon className="w-8 h-8 text-neutral-400 mb-1" />
                    <span className="text-[11px] font-medium text-neutral-500">
                      Partner Showcase Photo Slot
                    </span>
                    <span className="text-[9px] text-neutral-400">
                      (Upload Partner Work / Studio Picture)
                    </span>
                  </div>

                  {/* Partner Services */}
                  <div className="space-y-1.5 mb-6">
                    <span className="text-xs font-bold text-neutral-700 uppercase tracking-wide block">
                      Specialized Offerings:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-neutral-600">
                      {partner.services.map((srv, idx) => (
                        <div key={idx} className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{srv}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Partner Contact Card */}
                <div className="pt-4 border-t border-neutral-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="text-neutral-400 block text-[11px]">Primary Contact:</span>
                    <strong className="text-neutral-800">{partner.contactPerson}</strong>
                    <span className="text-neutral-500 block text-[11px] mt-0.5">{partner.location}</span>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <a
                      href={`tel:+${partner.phoneRaw}`}
                      className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold flex items-center justify-center gap-1.5"
                    >
                      <Phone className="w-3.5 h-3.5 text-[#7A1526]" />
                      <span>{partner.phone}</span>
                    </a>

                    <a
                      href={`https://wa.me/${partner.phoneRaw}?text=${encodeURIComponent(
                        `Hello ${partner.contactPerson}, I got your contact through Karimulla Tent House Trusted Partner network.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* SECTION 3: PARTNER WITH US CALLOUT */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="rounded-3xl p-8 sm:p-12 bg-gradient-to-r from-[#38030B] via-[#4A040F] to-[#5C0614] text-white text-center space-y-4 border border-[#D4AF37]/30 shadow-2xl">
            <span className="text-xs uppercase tracking-widest text-[#E5C158] font-bold">
              Vendor & Freelancer Network
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold">
              Are You a Decorator, Caterer, or Audio Technician in Guntur?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-xl mx-auto">
              Join Karimulla Tent House’s trusted vendor roster. We collaborate on 300+ events every season with prompt payments and long-term partnerships.
            </p>

            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href={`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(
                  'Hello Karimulla garu, I am a vendor/contractor in Guntur and would like to join your trusted partner network.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-7 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-xs sm:text-sm shadow-md transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>Join As a Trusted Partner</span>
              </a>

              <button
                onClick={onSwitchToTentHouse}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm border border-white/20 transition-colors"
              >
                Return to Home Catalog
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1C0105] text-neutral-400 py-12 border-t border-white/10 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <p className="text-white font-medium">
              &copy; {new Date().getFullYear()} Karimulla Tent House. Specialized Teams & Trusted Partners Division.
            </p>
            <p className="text-[11px] text-neutral-500 mt-0.5">
              Director: {BUSINESS_DETAILS.ownerEnglish} · {BUSINESS_DETAILS.addressEnglish}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onSwitchToTentHouse} className="hover:text-white underline cursor-pointer">
              Home
            </button>
            <span>·</span>
            <button onClick={onSwitchToFounder} className="hover:text-white underline cursor-pointer">
              Founder & Director
            </button>
            <span>·</span>
            <button onClick={onSwitchToRealEstate} className="hover:text-white underline cursor-pointer">
              Real Estate
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Floating Bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#38030B]/95 backdrop-blur-md border-t border-[#D4AF37]/30 p-2.5 px-4 flex items-center justify-between gap-3 shadow-2xl">
        <button
          onClick={onSwitchToTentHouse}
          className="flex-1 py-2 px-3 rounded-xl bg-white/10 text-white font-semibold text-xs flex items-center justify-center gap-1.5"
        >
          <Tent className="w-3.5 h-3.5 text-[#F3DE8A]" />
          <span>Home</span>
        </button>

        <button
          onClick={onSwitchToFounder}
          className="flex-1 py-2 px-3 rounded-xl bg-[#D4AF37] text-[#240106] font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm"
        >
          <User className="w-3.5 h-3.5" />
          <span>Director</span>
        </button>

        <a
          href={`tel:+${BUSINESS_DETAILS.phone1Raw}`}
          className="py-2 px-3 rounded-xl bg-emerald-700 text-white font-bold text-xs flex items-center justify-center"
          title="Call Karimulla"
        >
          <Phone className="w-4 h-4" />
        </a>
      </div>

    </div>
  );
};
