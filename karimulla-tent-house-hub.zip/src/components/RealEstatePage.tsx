import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  Phone, 
  MessageCircle, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Tent, 
  ChevronDown, 
  FileCheck, 
  TrendingUp, 
  Landmark, 
  Send, 
  AlertCircle, 
  Sparkles, 
  Car, 
  User, 
  Image as ImageIcon,
  Sun,
  Moon,
  Crown,
  Award
} from 'lucide-react';
import { 
  REAL_ESTATE_BUSINESS, 
  REAL_ESTATE_FAQS 
} from '../data/realEstateData';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useSiteData } from '../context/SiteDataContext';
import { motion } from 'framer-motion';
import { MotionFadeUp, MotionHeading, MotionContainer } from './motion/MotionFade';

interface RealEstatePageProps {
  onSwitchToTentHouse: () => void;
}

// Bilingual real estate menu offerings
const REAL_ESTATE_MENU_ITEMS = [
  {
    id: 'open-plots',
    number: 1,
    telugu: 'ఓపెన్ ప్లాట్లు',
    english: 'Open Residential Plots',
    description: 'CRDA & DTCP Approved residential layout plots in Amaravathi Capital, Mangalagiri, and Guntur.',
    descriptionTelugu: 'అమరావతి రాజధాని ప్రాంతం, మంగళగిరి మరియు గుంటూరులలో CRDA & DTCP ఆమోదిత నివాస లేఅవుట్ ప్లాట్లు.',
    badge: 'CRDA / DTCP Approved',
    badgeTelugu: 'CRDA / DTCP ఆమోదితం'
  },
  {
    id: 'farm-lands',
    number: 2,
    telugu: 'పొలాలు & ఫామ్‌ల్యాండ్స్',
    english: 'Farm Lands & Fields',
    description: 'Fertile agricultural lands, riverfront farm bits, and highway farm houses with sweet ground water.',
    descriptionTelugu: 'సారవంతమైన వ్యవసాయ భూములు, కృష్ణా నదీతీర ఫామ్‌ల్యాండ్లు మరియు హైవే ఫామ్‌హౌస్ స్థలాలు.',
    badge: 'Fertile Clear Title',
    badgeTelugu: 'సారవంతమైన క్లియర్ టైటిల్'
  },
  {
    id: 'houses-villas',
    number: 3,
    telugu: 'ఇల్లులు & విల్లాలు',
    english: 'Independent Houses & Villas',
    description: 'Modern luxury duplex villas, independent houses, and gated community residences.',
    descriptionTelugu: 'ఆధునిక లగ్జరీ డ్యూప్లెక్స్ విల్లాలు, స్వతంత్ర ఇళ్ళు మరియు గేటెడ్ కమ్యూనిటీ నివాసాలు.',
    badge: '100% Vastu Compliant',
    badgeTelugu: '100% వాస్తు ప్రకారం'
  },
  {
    id: 'apartments',
    number: 4,
    telugu: 'అపార్ట్‌మెంట్స్ & ఫ్లాట్లు',
    english: 'Apartments & Flats',
    description: 'Ready-to-occupy 2BHK & 3BHK flats with municipal drinking water, lift, and covered parking.',
    descriptionTelugu: 'మున్సిపల్ తాగునీరు, లిఫ్ట్ మరియు కవర్డ్ కార్ పార్కింగ్‌తో కూడిన రెడీ-టు-ఆక్యుపై 2BHK & 3BHK ఫ్లాట్లు.',
    badge: 'Ready for Possession',
    badgeTelugu: 'తక్షణ గృహప్రవేశం'
  },
  {
    id: 'commercial',
    number: 5,
    telugu: 'కమర్షియల్ స్థలాలు',
    english: 'Commercial Land & Highway Bits',
    description: 'Direct NH-16 highway-facing commercial bits suitable for showrooms, hotels, hospitals & godowns.',
    descriptionTelugu: 'షోరూమ్‌లు, హోటళ్ళు, ఆసుపత్రులు మరియు గోడౌన్లకు అనువైన డైరెక్ట్ NH-16 హైవే ఫేసింగ్ కమర్షియల్ బిట్స్.',
    badge: 'High Appreciation Bit',
    badgeTelugu: 'హైవే ప్రైమ్ లొకేషన్'
  },
  {
    id: 'selling',
    number: 6,
    telugu: 'అమ్మదలచిన స్థలాలు',
    english: 'Sell Your Property / Land',
    description: 'If you want to sell your plot, house, or land, connect directly with genuine verified cash buyers.',
    descriptionTelugu: 'మీ ప్లాట్, ఇల్లు లేదా పొలం అమ్మాలనుకుంటే, నేరుగా నమ్మకమైన నగదు కొనుగోలుదారులతో సంప్రదించండి.',
    badge: 'Instant Spot Buyer Connect',
    badgeTelugu: 'తక్షణ కొనుగోలుదారుల కనెక్ట్'
  }
];

export const RealEstatePage: React.FC<RealEstatePageProps> = ({ onSwitchToTentHouse }) => {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);
  const { setLanguage, isTelugu } = useLanguage();
  const { toggleTheme, isDark } = useTheme();
  const { siteData } = useSiteData();
  const founder = siteData?.founder;

  // Dedicated phone number for real estate: 9030 610 877
  const rePhoneDisplay = "9030 610 877";
  const rePhoneRaw = "919030610877";

  // Working Inquiry Form state
  const [inquiryForm, setInquiryForm] = useState({
    name: '',
    phone: '',
    purpose: isTelugu ? 'ఓపెన్ ప్లాట్లు (Open Plots)' : 'Open Plots',
    location: 'Amaravathi Capital Region / Mangalagiri',
    budget: '₹25 Lakhs – ₹50 Lakhs',
    message: ''
  });

  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formError, setFormError] = useState('');

  const handleInquiryChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setInquiryForm({ ...inquiryForm, [e.target.name]: e.target.value });
    if (formError) setFormError('');
  };

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!inquiryForm.name.trim() || !inquiryForm.phone.trim()) {
      setFormError(
        isTelugu 
          ? 'దయచేసి మీ పేరు మరియు ఫోన్ నంబర్‌ను నమోదు చేయండి.' 
          : 'Please enter both your name and phone number to proceed.'
      );
      return;
    }

    let whatsappText = `*KARIMULLA REAL ESTATE - PROPERTY INQUIRY*\n\n`;
    whatsappText += `*Client Name:* ${inquiryForm.name.trim()}\n`;
    whatsappText += `*Phone / WhatsApp:* ${inquiryForm.phone.trim()}\n`;
    whatsappText += `*Requirement:* ${inquiryForm.purpose}\n`;
    whatsappText += `*Preferred Location:* ${inquiryForm.location}\n`;
    whatsappText += `*Budget Range:* ${inquiryForm.budget}\n`;
    if (inquiryForm.message.trim()) {
      whatsappText += `*Details / Notes:* ${inquiryForm.message.trim()}\n`;
    }
    whatsappText += `\nHello Karimulla garu, I am contacting you on 9030 610 877 regarding property in Guntur/Amaravathi. Please share details and guide me. Thank you!`;

    const encoded = encodeURIComponent(whatsappText);
    window.open(`https://wa.me/${rePhoneRaw}?text=${encoded}`, '_blank');
    setFormSubmitted(true);
  };

  const handleMenuWhatsApp = (itemTelugu: string, itemEnglish: string) => {
    const text = isTelugu
      ? `నమస్తే కరిముల్లా గారు, నేను "${itemTelugu}" (${itemEnglish}) గురించి సంప్రదించాలనుకుంటున్నాను. గుంటూరు/అమరావతి వివరాలు పంపగలరు.`
      : `Hello Karimulla garu, I am interested in "${itemEnglish}" (${itemTelugu}) in Guntur/Amaravathi. Please share available verified properties and guide me on ${rePhoneDisplay}.`;
    window.open(`https://wa.me/${rePhoneRaw}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#F8FAF9] dark:bg-[#061A14] text-slate-800 dark:text-slate-100 font-sans antialiased selection:bg-emerald-800 selection:text-white pb-20 sm:pb-0 transition-colors duration-300">
      
      {/* Real Estate Top Header (Compact & Mobile Responsive) */}
      <header className="sticky top-0 z-40 bg-emerald-950/95 dark:bg-[#03140F]/95 backdrop-blur-md shadow-lg border-b border-emerald-500/20 py-2.5 text-white">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8 flex items-center justify-between gap-2">
          
          {/* Brand Wordmark */}
          <div className="flex items-center gap-2 min-w-0 shrink">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white shadow-xs shrink-0">
              <Building2 className="w-4 h-4 text-emerald-950" />
            </div>
            <div className="min-w-0">
              <span className={`text-xs sm:text-base font-bold tracking-tight text-white block leading-tight truncate ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? REAL_ESTATE_BUSINESS.nameTelugu : REAL_ESTATE_BUSINESS.name}
              </span>
              <span className={`text-[10px] tracking-wide text-emerald-300 font-medium hidden md:block truncate ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? REAL_ESTATE_BUSINESS.addressTelugu : REAL_ESTATE_BUSINESS.addressEnglish}
              </span>
            </div>
          </div>

          {/* Desktop Nav Links (Fully Bilingual) */}
          <nav className="hidden xl:flex items-center gap-5 text-xs xl:text-sm font-medium text-emerald-100 shrink">
            <a href="#re-founder" className={`hover:text-emerald-300 transition-colors whitespace-nowrap ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? 'వ్యవస్థాపకులు' : 'Founder & Leadership'}
            </a>
            <a href="#re-menu" className={`hover:text-emerald-300 transition-colors whitespace-nowrap ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? 'సేవల మెనూ' : 'Real Estate Menu'}
            </a>
            <a href="#re-contact-intro" className={`hover:text-emerald-300 transition-colors whitespace-nowrap ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? 'సంప్రదించండి' : 'Property Advisory'}
            </a>
            <a href="#re-inquiry-form" className={`hover:text-emerald-300 transition-colors whitespace-nowrap ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? 'ఎంక్వైరీ ఫారమ్' : 'Inquiry Form'}
            </a>
            <a href="#re-faqs" className={`hover:text-emerald-300 transition-colors whitespace-nowrap ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? 'సందేహాలు & సమాధానాలు' : 'Legal & FAQs'}
            </a>
          </nav>

          {/* Actions & Working Language Mode Toggle & Switch to Tent House Button */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            
            {/* Dark Mode / Light Mode Toggle */}
            <button
              type="button"
              onClick={toggleTheme}
              className="p-1 sm:p-1.5 rounded-lg bg-black/35 hover:bg-black/55 text-emerald-200 border border-emerald-400/40 shadow-xs transition-colors cursor-pointer shrink-0"
              title={isDark ? (isTelugu ? "లైట్ మోడ్" : "Switch to Light Mode") : (isTelugu ? "డార్క్ మోడ్" : "Switch to Dark Mode")}
              aria-label={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDark ? (
                <Sun className="w-3.5 h-3.5 text-amber-300" />
              ) : (
                <Moon className="w-3.5 h-3.5 text-emerald-200" />
              )}
            </button>

            {/* Header Language Mode Toggle (EN / తెలుగు) - Real Estate Translate Switch */}
            <div 
              className="flex items-center bg-emerald-900/90 dark:bg-black/40 p-0.5 rounded-lg border border-emerald-400/50 shadow-xs shrink-0"
              role="group"
              aria-label="Language selection"
            >
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 text-[11px] rounded font-semibold transition-all cursor-pointer ${
                  !isTelugu
                    ? 'bg-emerald-300 text-emerald-950 font-bold shadow-xs'
                    : 'text-emerald-100/80 hover:text-white font-medium'
                }`}
                title="Switch to English mode"
                aria-pressed={!isTelugu}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                className={`px-2 py-0.5 text-[11px] rounded transition-all cursor-pointer font-telugu ${
                  isTelugu
                    ? 'bg-emerald-300 text-emerald-950 font-bold shadow-xs'
                    : 'text-emerald-100/80 hover:text-white font-medium'
                }`}
                title="తెలుగు మోడ్‌కి మారండి"
                aria-pressed={isTelugu}
              >
                తెలుగు
              </button>
            </div>

            {/* Switch to Karimulla Tent House Button */}
            <button
              onClick={onSwitchToTentHouse}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-[#7A1526] hover:bg-[#5C0614] text-white shadow-xs border border-[#D4AF37]/50 transition-transform active:scale-95 whitespace-nowrap cursor-pointer shrink-0"
              title="Switch to Karimulla Tent House"
            >
              <Tent className="w-3.5 h-3.5 text-[#F3DE8A] shrink-0" />
              <span className="hidden sm:inline">
                {isTelugu ? 'కరిముల్లా టెంట్‌హౌస్' : 'Karimulla Tent House'}
              </span>
              <span className="sm:hidden font-sans font-bold">Tent House</span>
              <ArrowRight className="w-3 h-3 text-[#F3DE8A] hidden sm:inline" />
            </button>

            {/* Direct Call Button */}
            <a
              href={`tel:+${rePhoneRaw}`}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition-all whitespace-nowrap shrink-0"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{rePhoneDisplay}</span>
            </a>
          </div>

        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-16 sm:py-24 bg-gradient-to-b from-emerald-950 via-emerald-900 to-emerald-950 text-white overflow-hidden">
        
        {/* Subtle decorative background pattern */}
        <div 
          aria-hidden="true" 
          className="absolute inset-0 opacity-10 bg-[radial-gradient(#34D399_1px,transparent_1px)] [background-size:28px_28px] pointer-events-none"
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          
          <MotionHeading className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-800/80 border border-emerald-400/40 text-emerald-200 text-xs sm:text-sm font-medium tracking-wide mb-6">
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              <span>
                {isTelugu 
                  ? '100% లీగల్ క్లియర్ టైటిల్ గ్యారెంటీ · CRDA & DTCP ఆమోదం' 
                  : '100% Legal Clear Title Guaranteed · CRDA & DTCP Approved'}
              </span>
            </div>

            <h1 className={`text-2xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white text-balance mx-auto leading-tight ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
              {isTelugu ? REAL_ESTATE_BUSINESS.taglineTelugu : REAL_ESTATE_BUSINESS.taglineEnglish}
            </h1>

            <p className={`max-w-2xl mx-auto text-base sm:text-lg text-emerald-100/90 mt-5 leading-relaxed text-balance ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? (
                <>
                  <strong>{REAL_ESTATE_BUSINESS.ownerTelugu}</strong> గారి ప్రత్యక్ష పర్యవేక్షణలో గుంటూరు మరియు అమరావతి రాజధాని ప్రాంతంలో పారదర్శక డాక్యుమెంటేషన్, స్పాట్ రిజిస్ట్రేషన్ మరియు నమ్మకమైన స్థలాల కొనుగోలు, అమ్మకాలు.
                </>
              ) : (
                <>
                  Direct property guidance from <strong>{REAL_ESTATE_BUSINESS.ownerEnglish}</strong>. We offer end-to-end assistance with transparent legal documentation and spot registration.
                </>
              )}
            </p>
          </MotionHeading>

          {/* Quick Stats Grid (Bilingual & Animated) */}
          <MotionContainer delay={0.2} className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto mt-10 pt-8 border-t border-emerald-800/60 text-center">
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-extrabold text-emerald-300 tabular-nums block">
                22+ {isTelugu ? 'ఏళ్లు' : 'Years'}
              </span>
              <span className="text-xs text-emerald-200/80">
                {isTelugu ? 'విశ్వసనీయ అనుభవం' : 'Trusted Experience'}
              </span>
            </div>
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-extrabold text-emerald-300 tabular-nums block">
                480+ {isTelugu ? 'ప్లాట్లు' : 'Plots'}
              </span>
              <span className="text-xs text-emerald-200/80">
                {isTelugu ? 'విజయవంతంగా రిజిస్టర్' : 'Successfully Registered'}
              </span>
            </div>
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-extrabold text-emerald-300 tabular-nums block">
                2,400+
              </span>
              <span className="text-xs text-emerald-200/80">
                {isTelugu ? 'సంతృప్తి చెందిన కస్టమర్లు' : 'Satisfied Buyers'}
              </span>
            </div>
            <div className="p-2">
              <span className="font-serif text-2xl sm:text-3xl font-extrabold text-emerald-300 tabular-nums block">
                100% {isTelugu ? 'క్లియర్' : 'Clear'}
              </span>
              <span className="text-xs text-emerald-200/80">
                {isTelugu ? 'టైటిల్ వెరిఫికేషన్' : 'Title Verification'}
              </span>
            </div>
          </MotionContainer>

          {/* Hero CTAs (Bilingual & Animated) */}
          <MotionFadeUp delay={0.3} className="flex flex-col sm:flex-row items-center justify-center gap-3.5 mt-8 max-w-md mx-auto">
            <a
              href="#re-inquiry-form"
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-sm shadow-xl transition-all duration-200 hover:scale-[1.02] cursor-pointer"
            >
              {isTelugu ? 'ప్రాపర్టీ ఎంక్వైరీ పంపండి' : 'Send Property Inquiry'}
            </a>
            <a
              href={`https://wa.me/${rePhoneRaw}?text=${encodeURIComponent(
                isTelugu 
                  ? 'నమస్తే కరిముల్లా గారు, గుంటూరు/అమరావతిలో స్థలం లేదా ప్రాపర్టీ కొనుగోలు/అమ్మకం కోసం సంప్రదించాలనుకుంటున్నాను.'
                  : 'Hello Karimulla garu, I would like to consult with you regarding property investment in Guntur / Amaravathi.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-sm shadow-xl transition-all duration-200 hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>WhatsApp: {rePhoneDisplay}</span>
            </a>
          </MotionFadeUp>

        </div>
      </section>

      {/* 1. FOUNDER AND DIRECTED BY SECTION (No founder photo, prestigious heraldic emblem) */}
      <section id="re-founder" className="py-16 sm:py-20 bg-white dark:bg-[#07241B] border-b border-slate-200 dark:border-emerald-900/40 scroll-mt-16 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            
            {/* Left: Leadership Crest Card (No Photo) */}
            <MotionContainer delay={0.1} className="lg:col-span-5">
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-emerald-950 to-emerald-900 text-white shadow-2xl border-4 border-emerald-400/30 flex flex-col items-center text-center relative overflow-hidden">
                
                {/* Chairman / Founder Photo (if uploaded in admin) or Prestigious Real Estate Insignia Crest */}
                {founder?.photo && founder?.showPhoto ? (
                  <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden border-2 border-emerald-400 ring-4 ring-[#D4AF37] shadow-xl mb-5 shrink-0 bg-emerald-950">
                    <img
                      src={founder.photo}
                      alt={founder.name || REAL_ESTATE_BUSINESS.ownerEnglish}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                ) : (
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-gradient-to-br from-emerald-800 via-emerald-900 to-emerald-950 border-2 border-emerald-400 ring-4 ring-[#D4AF37] shadow-xl flex flex-col items-center justify-center p-3 text-center mb-5">
                    <Building2 className="w-9 h-9 text-[#F3DE8A]" />
                    <span className="text-[10px] font-bold text-[#F3DE8A] tracking-wider uppercase mt-1">22+ YRS</span>
                  </div>
                )}

                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-800/80 border border-emerald-400/40 text-emerald-200 text-xs font-bold uppercase tracking-wider mb-2">
                  <Sparkles className="w-3 h-3 text-emerald-300" />
                  <span>{isTelugu ? 'వ్యవస్థాపకులు & డైరెక్టర్' : 'Founder & Directed By'}</span>
                </div>
                
                {/* Owner Name */}
                <h3 className="font-telugu text-2xl sm:text-3xl font-bold text-white leading-tight">
                  {REAL_ESTATE_BUSINESS.ownerTelugu}
                </h3>
                
                <p className="font-sans text-sm text-emerald-200 mt-1 font-medium">
                  {REAL_ESTATE_BUSINESS.ownerEnglish}
                </p>

                <div className="mt-4 pt-4 border-t border-emerald-800 w-full space-y-2 text-xs">
                  <div className="flex items-center justify-center gap-2 text-emerald-100">
                    <Phone className="w-4 h-4 text-emerald-300" />
                    <span className="text-emerald-300 font-medium">
                      {isTelugu ? 'కాల్ & వాట్సాప్:' : 'Call & WhatsApp:'}
                    </span>
                    <a href={`tel:+${rePhoneRaw}`} className="font-mono font-bold text-base hover:underline text-white">
                      {rePhoneDisplay}
                    </a>
                  </div>

                  <div className="flex items-center justify-center gap-1.5 text-emerald-200/90 text-center">
                    <MapPin className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                    <span className={isTelugu ? 'font-telugu' : 'font-sans'}>
                      {isTelugu ? REAL_ESTATE_BUSINESS.addressTelugu : REAL_ESTATE_BUSINESS.addressEnglish}
                    </span>
                  </div>
                </div>

              </div>
            </MotionContainer>

            {/* Right: Leadership & Heritage Overview (Fully Bilingual) */}
            <MotionContainer delay={0.2} className="lg:col-span-7 space-y-5">
              
              <div className="space-y-1">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
                  {isTelugu ? 'వ్యవస్థాపకులు & పర్యవేక్షణ · 22 ఏళ్ల నమ్మకం' : 'Leadership & Heritage · 22+ Years of Trust'}
                </span>
                <h2 className={`text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 dark:text-white leading-snug ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                  {isTelugu 
                    ? `${REAL_ESTATE_BUSINESS.ownerTelugu} గారి ఆధ్వర్యంలో 22 ఏళ్ల నమ్మకం`
                    : `22+ Years of Trusted Property Guidance Under ${REAL_ESTATE_BUSINESS.ownerEnglish}`}
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-sans">
                  {isTelugu ? 'నిజాయితీతో కూడిన రియల్ ఎస్టేట్ లావాదేవీలు' : `Founder & Directed By ${REAL_ESTATE_BUSINESS.ownerEnglish}`}
                </p>
              </div>

              <p className={`text-base text-slate-700 dark:text-slate-200 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                &ldquo;{isTelugu ? REAL_ESTATE_BUSINESS.taglineTelugu : REAL_ESTATE_BUSINESS.taglineEnglish}&rdquo;
              </p>

              <p className={`text-sm text-slate-600 dark:text-slate-300 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? (
                  <>
                    <strong>{REAL_ESTATE_BUSINESS.ownerTelugu}</strong> గారి ప్రత్యక్ష ఆధ్వర్యంలో, గుంటూరు మరియు అమరావతి రాజధాని బెల్ట్‌లో 2,400 కంటే ఎక్కువ మంది కుటుంబాలు మరియు ఇన్వెస్టర్లకు నమ్మకమైన సేవలు అందించబడ్డాయి. మేము చూపించే ప్రతి స్థలానికి ఒరిజినల్ లింక్ డాక్యుమెంట్లు, 30 ఏళ్ల EC (Encumbrance Certificate) మరియు మున్సిపల్/CRDA లేఅవుట్ అనుమతులను వ్యక్తిగతంగా తనిఖీ చేస్తాము.
                  </>
                ) : (
                  <>
                    Under the direct leadership and guidance of <strong>{REAL_ESTATE_BUSINESS.ownerEnglish}</strong>, Karimulla Real Estate has served over 2,400 satisfied land and property buyers across Guntur and the Amaravathi capital belt. We take personal responsibility for checking every legal document, original link deeds, 30-year Encumbrance Certificates (EC), and municipal town planning approvals before showing any site.
                  </>
                )}
              </p>

              {/* 4 Guarantees Grid (Bilingual) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs text-slate-700 dark:text-slate-200">
                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 dark:text-white">
                      {isTelugu ? '100% క్లియర్ టైటిల్ వెరిఫికేషన్' : '100% Clear Title Verification'}
                    </strong>
                    <span className="text-slate-600 dark:text-slate-300">
                      {isTelugu ? 'ఎటువంటి వివాదాలు లేని ఒరిజినల్ లింక్ డాక్యుమెంట్లు.' : 'No disputes, zero litigation, clean link documents.'}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                  <Car className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 dark:text-white">
                      {isTelugu ? 'ఉచిత సైట్ విజిట్ సదుపాయం' : 'Free Chauffeur Site Visit'}
                    </strong>
                    <span className="text-slate-600 dark:text-slate-300">
                      {isTelugu ? 'గుంటూరు నుండి ఉచిత ఫోర్-వీలర్‌లో స్థల పరిశీలన.' : 'Personal inspection in four-wheeler from Guntur.'}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                  <FileCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 dark:text-white">
                      {isTelugu ? 'స్పాట్ రిజిస్ట్రేషన్ సహకారం' : 'Spot Registration Support'}
                    </strong>
                    <span className="text-slate-600 dark:text-slate-300">
                      {isTelugu ? 'సబ్-రిజిస్ట్రార్ అపాయింట్‌మెంట్, డాక్యుమెంట్ డ్రాఫ్టింగ్ & మ్యుటేషన్.' : 'Sub-Registrar appointment, document drafting & mutation.'}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                  <Landmark className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 dark:text-white">
                      {isTelugu ? 'CRDA & DTCP లేఅవుట్లు' : 'CRDA & DTCP Layouts'}
                    </strong>
                    <span className="text-slate-600 dark:text-slate-300">
                      {isTelugu ? '75% వరకు బ్యాంక్ లోన్ సౌకర్యం గల అనుమతి లేఅవుట్లు.' : 'Sanctioned layouts with bank loan feasibility up to 75%.'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Direct Call / WhatsApp CTA */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <a
                  href={`tel:+${rePhoneRaw}`}
                  className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{isTelugu ? `కాల్ చేయండి (${rePhoneDisplay})` : `Call ${rePhoneDisplay}`}</span>
                </a>

                <a
                  href={`https://wa.me/${rePhoneRaw}?text=${encodeURIComponent(
                    isTelugu 
                      ? 'నమస్తే కరిముల్లా గారు, గుంటూరు/అమరావతి ప్రాపర్టీల వివరాలు తెలుసుకోవాలనుకుంటున్నాను.'
                      : 'Hello Karimulla garu, I want to consult you regarding property/land in Guntur on 9030 610 877.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-current" />
                  <span>{isTelugu ? `వాట్సాప్ చాట్ (${rePhoneDisplay})` : `Chat on WhatsApp (${rePhoneDisplay})`}</span>
                </a>
              </div>

            </MotionContainer>

          </div>

        </div>
      </section>

      {/* 2. REAL ESTATE OFFERINGS MENU SECTION */}
      <section id="re-menu" className="py-16 sm:py-20 bg-[#FAF7F2] dark:bg-[#041510] border-b border-amber-900/10 dark:border-emerald-900/40 scroll-mt-16 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <MotionHeading className="text-center max-w-3xl mx-auto mb-12 sm:mb-14">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200 text-xs font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
              <span>{isTelugu ? 'రియల్ ఎస్టేట్ సేవల మెనూ' : 'Real Estate Offerings Menu'}</span>
            </div>

            <h2 className={`text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
              {isTelugu ? 'మా రియల్ ఎస్టేట్ సేవలు & ఆఫరింగ్స్' : 'Real Estate Services & Offerings Menu'}
            </h2>
            <p className={`mt-3 text-base text-slate-600 dark:text-slate-300 ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              &ldquo;{isTelugu ? REAL_ESTATE_BUSINESS.taglineTelugu : REAL_ESTATE_BUSINESS.taglineEnglish}&rdquo;
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-sans mt-1">
              {isTelugu 
                ? `క్రింది కేటగిరీలలో దేనినైనా ఎంచుకుని కరిముల్లా గారితో నేరుగా వాట్సాప్‌లో (${rePhoneDisplay}) మాట్లాడవచ్చు.`
                : `Select any category below to enquire with Karimulla garu directly on WhatsApp (${rePhoneDisplay}).`}
            </p>
          </MotionHeading>

          {/* Grid of 6 Offerings Cards (Animated) */}
          <MotionContainer delay={0.15} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {REAL_ESTATE_MENU_ITEMS.map((item) => (
              <div
                key={item.id}
                className="bg-white dark:bg-[#07241B] rounded-2xl overflow-hidden border border-slate-200 dark:border-emerald-900/50 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
              >
                <div>
                  {/* Category Header Slot Container */}
                  <div className="relative h-36 w-full bg-gradient-to-br from-emerald-100/60 via-slate-100 to-emerald-200/50 dark:from-emerald-950 dark:via-[#051B13] dark:to-emerald-900/50 flex flex-col items-center justify-center p-4 text-center border-b border-slate-200 dark:border-emerald-900/40">
                    <div className="w-12 h-12 rounded-full bg-white dark:bg-emerald-900/80 border border-emerald-300 dark:border-emerald-700 flex items-center justify-center mb-1 shadow-xs group-hover:scale-110 transition-transform">
                      <Building2 className="w-6 h-6 text-emerald-800 dark:text-emerald-300" />
                    </div>
                    <span className="text-[11px] font-sans font-medium text-slate-500 dark:text-slate-400">
                      {isTelugu ? 'ప్రాపర్టీ కేటగిరీ' : 'Property Category'}
                    </span>

                    {/* Sequential Number Tag */}
                    <div className="absolute top-3 left-3 w-7 h-7 rounded-full bg-emerald-950 text-emerald-300 text-xs font-bold font-mono flex items-center justify-center shadow-md">
                      0{item.number}
                    </div>

                    {/* Badge */}
                    <div className="absolute top-3 right-3 bg-emerald-800 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
                      {isTelugu ? item.badgeTelugu : item.badge}
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5">
                    <h3 className={`text-xl font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-emerald-300 transition-colors ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                      {isTelugu ? item.telugu : item.english}
                    </h3>
                    <p className="font-sans text-xs text-emerald-900 dark:text-emerald-400 font-medium mt-0.5">
                      {isTelugu ? item.english : item.telugu}
                    </p>
                    <p className={`text-xs text-slate-600 dark:text-slate-300 mt-2.5 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                      {isTelugu ? item.descriptionTelugu : item.description}
                    </p>
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="p-5 pt-0">
                  <button
                    onClick={() => handleMenuWhatsApp(item.telugu, item.english)}
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-current" />
                    <span>
                      {isTelugu 
                        ? `వాట్సాప్‌లో ఎంక్వైరీ (${rePhoneDisplay})` 
                        : `Enquire on WhatsApp (${rePhoneDisplay})`}
                    </span>
                  </button>
                </div>
              </div>
            ))}
          </MotionContainer>

        </div>
      </section>

      {/* 3. DIRECT PROPERTY ADVISORY SECTION */}
      <section id="re-contact-intro" className="py-16 sm:py-20 bg-white dark:bg-[#07241B] border-b border-slate-200 dark:border-emerald-900/40 scroll-mt-16 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <MotionHeading className="text-center max-w-3xl mx-auto mb-14">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 text-xs font-bold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{isTelugu ? 'ప్రత్యక్ష ప్రాపర్టీ సలహాదారు' : 'Direct Property Advisory'}</span>
            </div>
            <h2 className={`text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight leading-tight ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
              {isTelugu 
                ? 'స్థలాలు, ప్లాట్లు, ఇల్లు కొనదలచినా, అమ్మదలచినా — సంప్రదించండి!' 
                : 'If Anyone Wants Land, Plots, or Property — Contact Us!'}
            </h2>
            <p className={`mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu ? (
                <>
                  గుంటూరు, మంగళగిరి లేదా అమరావతి రాజధాని పరిధిలో స్థలం కొనాలనుకుంటున్నారా లేదా మీ స్థలాన్ని సరసమైన ధరకు అమ్మాలనుకుంటున్నారా? నేరుగా <strong>{REAL_ESTATE_BUSINESS.ownerTelugu}</strong> గారిని <strong>{rePhoneDisplay}</strong> నంబర్‌లో సంప్రదించండి.
                </>
              ) : (
                <>
                  Looking to buy, sell, or invest in real estate in Guntur, Mangalagiri, or the Amaravathi Capital region? Reach out to <strong>{REAL_ESTATE_BUSINESS.ownerEnglish}</strong> directly at <strong>{rePhoneDisplay}</strong>.
                </>
              )}
            </p>
          </MotionHeading>

          {/* 4 Need-Based Cards (Bilingual & Animated) */}
          <MotionContainer delay={0.2} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div className="p-6 rounded-2xl bg-[#F8FAF9] dark:bg-emerald-950/40 border border-slate-200 dark:border-emerald-800 shadow-xs hover:shadow-lg transition-all duration-200">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/80 flex items-center justify-center text-emerald-800 dark:text-emerald-200 mb-4">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className={`text-lg font-bold text-slate-900 dark:text-white mb-2 ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                {isTelugu ? 'ఓపెన్ ప్లాట్లు కొనాలా?' : 'Want to Buy Open Plots?'}
              </h3>
              <p className={`text-xs text-slate-600 dark:text-slate-300 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu 
                  ? 'CRDA, DTCP & GMC ఆమోదం పొందిన నివాస లేఅవుట్ ప్లాట్లు, బీటీ రోడ్లు మరియు డ్రైనేజీ సదుపాయాలతో.' 
                  : 'CRDA, DTCP & GMC sanctioned residential layout plots in high-growth corridors with blacktop roads and underground drainage.'}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F8FAF9] dark:bg-emerald-950/40 border border-slate-200 dark:border-emerald-800 shadow-xs hover:shadow-lg transition-all duration-200">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/80 flex items-center justify-center text-emerald-800 dark:text-emerald-200 mb-4">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className={`text-lg font-bold text-slate-900 dark:text-white mb-2 ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                {isTelugu ? 'కమర్షియల్ & హైవే బిట్స్' : 'Commercial & Highway Bits'}
              </h3>
              <p className={`text-xs text-slate-600 dark:text-slate-300 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu 
                  ? 'NH-16 జాతీయ రహదారి ఫేసింగ్ కమర్షియల్ స్థలాలు, షోరూమ్ ప్లాట్లు మరియు గోడౌన్ బిట్స్.' 
                  : 'NH-16 national highway facing commercial land, showroom plots, and godown spaces suitable for business or rental yields.'}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F8FAF9] dark:bg-emerald-950/40 border border-slate-200 dark:border-emerald-800 shadow-xs hover:shadow-lg transition-all duration-200">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/80 flex items-center justify-center text-emerald-800 dark:text-emerald-200 mb-4">
                <Car className="w-6 h-6" />
              </div>
              <h3 className={`text-lg font-bold text-slate-900 dark:text-white mb-2 ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                {isTelugu ? 'ఉచిత సైట్ విజిట్ సదుపాయం' : 'Free Chauffeur Site Visit'}
              </h3>
              <p className={`text-xs text-slate-600 dark:text-slate-300 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu 
                  ? 'గుంటూరు నుండి ఉచిత ఫోర్-వీలర్‌లో సైట్ విజిట్ చేసి సరిహద్దులను ప్రత్యక్షంగా పరిశీలించే వెసులుబాటు.' 
                  : 'We provide free four-wheeler pickup from anywhere in Guntur to visit and inspect the land boundaries in person.'}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F8FAF9] dark:bg-emerald-950/40 border border-slate-200 dark:border-emerald-800 shadow-xs hover:shadow-lg transition-all duration-200">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/80 flex items-center justify-center text-emerald-800 dark:text-emerald-200 mb-4">
                <FileCheck className="w-6 h-6" />
              </div>
              <h3 className={`text-lg font-bold text-slate-900 dark:text-white mb-2 ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                {isTelugu ? 'మీ ప్రాపర్టీ అమ్మాలనుకుంటున్నారా?' : 'Want to Sell Your Property?'}
              </h3>
              <p className={`text-xs text-slate-600 dark:text-slate-300 leading-relaxed ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu 
                  ? 'నమ్మకమైన నగదు కొనుగోలుదారులను కనెక్ట్ చేసి సరసమైన మార్కెట్ ధర మరియు తక్షణ రిజిస్ట్రేషన్ సాధించండి.' 
                  : 'Connect directly with verified genuine cash buyers, get fair market valuations, and conclude prompt spot registration.'}
              </p>
            </div>

          </MotionContainer>

        </div>
      </section>

      {/* 4. WORKING INQUIRY FORM SECTION */}
      <section id="re-inquiry-form" className="py-16 sm:py-24 bg-[#FAF7F2] dark:bg-[#041510] border-b border-amber-900/10 dark:border-emerald-900/40 scroll-mt-16 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <MotionHeading className="text-center max-w-3xl mx-auto mb-14">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-800 dark:text-emerald-400">
              {isTelugu ? 'ప్రత్యేక సంప్రదింపులు' : 'Personalized Assistance'}
            </span>
            <h2 className={`text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 dark:text-white tracking-tight mt-1 ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
              {isTelugu ? 'ప్రాపర్టీ ఎంక్వైరీ & రిక్వైర్‌మెంట్ ఫారమ్' : 'Property Inquiry & Requirement Form'}
            </h2>
            <p className={`text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2 ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu 
                ? `మీ వివరాలను నమోదు చేసి సబ్మిట్ చేయగానే కరిముల్లా గారికి వాట్సాప్‌లో (${rePhoneDisplay}) నేరుగా ఎంక్వైరీ చేరుతుంది.`
                : `Fill out your requirements below to connect directly with Karimulla garu on ${rePhoneDisplay} via WhatsApp.`}
            </p>
          </MotionHeading>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            
            {/* Left Column: Direct Contact & Office Details */}
            <MotionContainer delay={0.15} className="lg:col-span-5 space-y-6">
              
              <div className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 text-white p-7 sm:p-8 rounded-3xl shadow-xl border border-emerald-500/30 space-y-6">
                <div>
                  <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold">
                    {isTelugu ? 'నేరుగా సంప్రదించండి' : 'Direct Contact'}
                  </span>
                  <h3 className="font-telugu text-xl sm:text-2xl font-bold text-white mt-1">
                    {REAL_ESTATE_BUSINESS.ownerTelugu}
                  </h3>
                  <p className="text-xs text-emerald-200 mt-0.5">
                    {REAL_ESTATE_BUSINESS.ownerEnglish} · {isTelugu ? '22+ ఏళ్ల ల్యాండ్ అడ్వైజరీ' : '22+ Years in Land Advisory'}
                  </p>
                </div>

                <div className="space-y-4 text-sm pt-2 border-t border-emerald-800">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-emerald-300 shrink-0 mt-0.5">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs text-emerald-300/80 block">
                        {isTelugu ? 'ఫోన్ & వాట్సాప్:' : 'Phone & WhatsApp:'}
                      </span>
                      <a
                        href={`tel:+${rePhoneRaw}`}
                        className="font-bold text-lg text-white hover:text-emerald-300 transition-colors font-mono"
                      >
                        {rePhoneDisplay}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-emerald-300 shrink-0 mt-0.5">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs text-emerald-300/80 block">
                        {isTelugu ? 'ఆఫీస్ చిరునామా:' : 'Office Location:'}
                      </span>
                      <p className="text-white font-telugu text-sm leading-relaxed mt-0.5">
                        {REAL_ESTATE_BUSINESS.addressTelugu}
                      </p>
                      <p className="text-emerald-200/80 text-xs">
                        {REAL_ESTATE_BUSINESS.addressEnglish}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-emerald-300 shrink-0 mt-0.5">
                      <Car className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs text-emerald-300/80 block">
                        {isTelugu ? 'సైట్ ఇన్‌స్పెక్షన్ సమయాలు:' : 'Site Inspection Visits:'}
                      </span>
                      <p className="text-white text-xs sm:text-sm">
                        {isTelugu ? 'సోమవారం నుండి ఆదివారం (ఉదయం 8:00 – రాత్రి 8:30)' : 'Available Monday to Sunday (8:00 AM – 8:30 PM)'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Direct WhatsApp Callout */}
                <div className="pt-2">
                  <a
                    href={`https://wa.me/${rePhoneRaw}?text=${encodeURIComponent(
                      isTelugu 
                        ? 'నమస్తే కరిముల్లా గారు, గుంటూరు/అమరావతి ప్రాపర్టీల విషయంలో మాట్లాడాలనుకుంటున్నాను.'
                        : 'Hello Karimulla garu, I have a property requirement in Guntur/Amaravathi and would like to speak with you.'
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform hover:scale-[1.01] cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-current" />
                    <span>
                      {isTelugu 
                        ? `వాట్సాప్‌లో చాట్ చేయండి (${rePhoneDisplay})` 
                        : `Quick Chat on WhatsApp (${rePhoneDisplay})`}
                    </span>
                  </a>
                </div>
              </div>

              {/* Trust Callout */}
              <div className="p-5 rounded-2xl bg-white dark:bg-[#07241B] border border-slate-200 dark:border-emerald-800 shadow-sm space-y-3">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-100 uppercase tracking-wide flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                  {isTelugu ? 'మా డాక్యుమెంట్ వెరిఫికేషన్ ప్రమాణాలు:' : 'Our Vetting Standards:'}
                </span>
                <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isTelugu ? '30 ఏళ్ల EC (Encumbrance Certificate) తనిఖీ' : '30-Year Encumbrance Certificates (EC) checked'}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isTelugu ? 'రెవెన్యూ 1B / అడంగల్ రికార్డుల ధృవీకరణ' : 'Revenue 1B / Adangal records pre-authenticated'}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isTelugu ? 'ఉచిత సరిహద్దుల లొకేషన్ మార్కింగ్ చెక్' : 'Free on-site demarcation and boundary check'}</span>
                  </li>
                </ul>
              </div>

            </MotionContainer>

            {/* Right Column: Working Interactive Inquiry Form */}
            <MotionContainer delay={0.25} className="lg:col-span-7">
              <div className="bg-white dark:bg-[#07241B] p-7 sm:p-9 rounded-3xl shadow-xl border border-slate-200 dark:border-emerald-800">
                
                <div className="mb-6">
                  <h3 className={`text-2xl font-bold text-slate-900 dark:text-white ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
                    {isTelugu ? 'మీ ప్రాపర్టీ అవసరాన్ని మాకు తెలపండి' : 'Tell Us What You Are Looking For'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                    {isTelugu 
                      ? `మీ వివరాలు పూరించి సబ్మిట్ చేయగానే నేరుగా వాట్సాప్ ద్వారా కరిముల్లా గారికి (${rePhoneDisplay}) ఎంక్వైరీ వెళుతుంది.`
                      : `Fill in your details below and hit submit to connect directly with Karimulla garu via WhatsApp on ${rePhoneDisplay}.`}
                  </p>
                </div>

                {formSubmitted && (
                  <div className="mb-6 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-100 flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div className="text-xs sm:text-sm">
                      <strong>{isTelugu ? 'ఎంక్వైరీ సిద్ధమైంది!' : 'Inquiry Prepared & Sent!'}</strong> {isTelugu ? `వాట్సాప్ ఆటోమేటిక్‌గా ఓపెన్ కాకపోతే మీరు నేరుగా ${rePhoneDisplay} కు కాల్ చేయవచ్చు.` : `If WhatsApp didn't automatically launch, call Karimulla garu directly at ${rePhoneDisplay}.`}
                    </div>
                  </div>
                )}

                {formError && (
                  <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-300 text-red-900 dark:text-red-200 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                    <div className="text-xs sm:text-sm font-medium">{formError}</div>
                  </div>
                )}

                <form onSubmit={handleInquirySubmit} className="space-y-4">
                  
                  {/* Name and Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wide mb-1.5">
                        {isTelugu ? 'మీ పూర్తి పేరు *' : 'Your Full Name *'}
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder={isTelugu ? 'ఉదా. రమేష్ నాయుడు / సయ్యద్ అహ్మద్' : 'e.g. Ramesh Naidu / Syed Ahmed'}
                        value={inquiryForm.name}
                        onChange={handleInquiryChange}
                        className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-emerald-950/50 border border-slate-300 dark:border-emerald-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-700"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wide mb-1.5">
                        {isTelugu ? 'ఫోన్ / వాట్సాప్ నంబర్ *' : 'Phone / WhatsApp Number *'}
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        placeholder={isTelugu ? 'ఉదా. 98480 12345' : 'e.g. 98480 12345'}
                        value={inquiryForm.phone}
                        onChange={handleInquiryChange}
                        className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-emerald-950/50 border border-slate-300 dark:border-emerald-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-700"
                      />
                    </div>
                  </div>

                  {/* Purpose & Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wide mb-1.5">
                        {isTelugu ? 'నాకు కావాల్సింది:' : 'I Want To:'}
                      </label>
                      <select
                        name="purpose"
                        value={inquiryForm.purpose}
                        onChange={handleInquiryChange}
                        className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-emerald-950/50 border border-slate-300 dark:border-emerald-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-700"
                      >
                        <option value="ఓపెన్ ప్లాట్లు (Open Plots)">{isTelugu ? 'ఓపెన్ ప్లాట్లు (Open Plots)' : 'Open Plots'}</option>
                        <option value="పొలాలు (Farm Lands / Fields)">{isTelugu ? 'పొలాలు & ఫామ్‌ల్యాండ్స్' : 'Farm Lands / Fields'}</option>
                        <option value="ఇల్లులు (Independent Houses / Villas)">{isTelugu ? 'ఇల్లులు / విల్లాలు' : 'Independent Houses / Villas'}</option>
                        <option value="అపార్ట్‌మెంట్స్ (Apartments / Flats)">{isTelugu ? 'అపార్ట్‌మెంట్స్ / ఫ్లాట్లు' : 'Apartments / Flats'}</option>
                        <option value="కమర్షియల్ స్థలాలు (Commercial Lands / Bits)">{isTelugu ? 'కమర్షియల్ స్థలాలు' : 'Commercial Lands / Bits'}</option>
                        <option value="అమ్మదలచిన స్థలాలు (Sell My Property)">{isTelugu ? 'నా స్థలం అమ్మదలిచాను' : 'Sell My Property'}</option>
                        <option value="General Property Consultation">{isTelugu ? 'సాధారణ సంప్రదింపులు' : 'General Property Consultation'}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wide mb-1.5">
                        {isTelugu ? 'ఆసక్తి గల ప్రాంతం:' : 'Preferred Location:'}
                      </label>
                      <select
                        name="location"
                        value={inquiryForm.location}
                        onChange={handleInquiryChange}
                        className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-emerald-950/50 border border-slate-300 dark:border-emerald-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-700"
                      >
                        <option value="Amaravathi Capital Region / Mangalagiri">{isTelugu ? 'అమరావతి రాజధాని / మంగళగిరి' : 'Amaravathi Capital Region / Mangalagiri'}</option>
                        <option value="Guntur City (Brodipet / Pattabhipuram / Gujjanagundla)">{isTelugu ? 'గుంటూరు సిటీ (బ్రోడీపేట / పట్టాభిపురం)' : 'Guntur City (Brodipet / Pattabhipuram)'}</option>
                        <option value="NH-16 Highway / Bypass Stretch">{isTelugu ? 'NH-16 హైవే / బైపాస్ రోడ్' : 'NH-16 Highway / Bypass Stretch'}</option>
                        <option value="Tenali / Outer Ring Road Area">{isTelugu ? 'తెనాలి / ఔటర్ రింగ్ రోడ్ పరిధి' : 'Tenali / Outer Ring Road Area'}</option>
                        <option value="Any Good High-Growth Area">{isTelugu ? 'మంచి డెవలప్‌మెంట్ గల ఏదైనా ప్రాంతం' : 'Any Good High-Growth Area'}</option>
                      </select>
                    </div>
                  </div>

                  {/* Budget */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wide mb-1.5">
                      {isTelugu ? 'సుమారు బడ్జెట్ పరిధి:' : 'Approximate Budget Range:'}
                    </label>
                    <select
                      name="budget"
                      value={inquiryForm.budget}
                      onChange={handleInquiryChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-emerald-950/50 border border-slate-300 dark:border-emerald-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-700"
                    >
                      <option value="Under ₹25 Lakhs">{isTelugu ? '₹25 లక్షల లోపు' : 'Under ₹25 Lakhs'}</option>
                      <option value="₹25 Lakhs – ₹50 Lakhs">{isTelugu ? '₹25 లక్షలు – ₹50 లక్షలు' : '₹25 Lakhs – ₹50 Lakhs'}</option>
                      <option value="₹50 Lakhs – ₹1 Crore">{isTelugu ? '₹50 లక్షలు – ₹1 కోటి' : '₹50 Lakhs – ₹1 Crore'}</option>
                      <option value="₹1 Crore – ₹3 Crores">{isTelugu ? '₹1 కోటి – ₹3 కోట్లు' : '₹1 Crore – ₹3 Crores'}</option>
                      <option value="Above ₹3 Crores">{isTelugu ? '₹3 కోట్ల పైన' : 'Above ₹3 Crores'}</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 uppercase tracking-wide mb-1.5">
                      {isTelugu ? 'ప్రత్యేక అవసరాలు / వివరాలు (ఐచ్ఛికం)' : 'Specific Requirements / Notes (Optional)'}
                    </label>
                    <textarea
                      name="message"
                      rows={3}
                      placeholder={isTelugu ? 'ఉదా. మంగళగిరి సమీపంలో ఈస్ట్ ఫేసింగ్ 200 గజాల ప్లాట్ కావాలి...' : 'e.g. Looking for East facing 200 sq.yds plot near Mangalagiri, ready for immediate registration...'}
                      value={inquiryForm.message}
                      onChange={handleInquiryChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-emerald-950/50 border border-slate-300 dark:border-emerald-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-700"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-4 px-6 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-950/20 transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
                  >
                    <MessageCircle className="w-5 h-5 fill-current" />
                    <span>
                      {isTelugu 
                        ? `కరిముల్లా గారికి వాట్సాప్‌లో పంపండి (${rePhoneDisplay})` 
                        : `Submit & Send to Karimulla on WhatsApp (${rePhoneDisplay})`}
                    </span>
                    <Send className="w-4 h-4 ml-1" />
                  </button>

                  <p className="text-center text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                    {isTelugu 
                      ? `ప్రత్యక్ష ల్యాండ్ సంప్రదింపులు. మీరు నేరుగా కరిముల్లా గారితోనే మాట్లాడుతారు (${rePhoneDisplay}).`
                      : `Direct land advisory. You talk directly with Karimulla garu on ${rePhoneDisplay}.`}
                  </p>

                </form>

              </div>
            </MotionContainer>

          </div>

        </div>
      </section>

      {/* 5. Legal & FAQs (Fully Bilingual & Animated) */}
      <section id="re-faqs" className="py-16 sm:py-20 bg-slate-50 dark:bg-[#07241B] border-t border-slate-200 dark:border-emerald-900/40 scroll-mt-16 transition-colors duration-300">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <MotionHeading className="text-center mb-10">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-800 dark:text-emerald-400">
              {isTelugu ? 'కొనుగోలుదారుల రక్షణ & సమాధానాలు' : 'Buyer Protection & Questions'}
            </span>
            <h2 className={`text-3xl font-bold text-slate-900 dark:text-white mt-1 ${isTelugu ? 'font-telugu' : 'font-serif'}`}>
              {isTelugu ? 'తరచుగా అడిగే ప్రశ్నలు (FAQ)' : 'Frequently Asked Questions'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
              {isTelugu 
                ? 'గుంటూరు మరియు అమరావతిలో ప్రాపర్టీ కొనుగోలుకు సంబంధించి పూర్తి సమాచారం.'
                : 'Everything you need to know about purchasing property in Guntur and Amaravathi.'}
            </p>
          </MotionHeading>

          <MotionContainer delay={0.2} className="space-y-3">
            {REAL_ESTATE_FAQS.map((faq, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800 overflow-hidden shadow-xs"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                  className={`w-full p-5 text-left flex items-center justify-between gap-4 text-base font-bold text-slate-900 dark:text-white hover:text-emerald-800 dark:hover:text-emerald-300 transition-colors cursor-pointer ${isTelugu ? 'font-telugu' : 'font-serif'}`}
                >
                  <span>{isTelugu ? faq.questionTelugu : faq.question}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${expandedFaq === idx ? 'rotate-180' : ''}`} />
                </button>
                {expandedFaq === idx && (
                  <div className={`px-5 pb-5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-emerald-900/60 pt-3 ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                    {isTelugu ? faq.answerTelugu : faq.answer}
                  </div>
                )}
              </div>
            ))}
          </MotionContainer>

        </div>
      </section>

      {/* 6. Direct Contact Section */}
      <section id="re-contact" className="py-16 sm:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <MotionFadeUp delay={0.1} className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 text-white rounded-3xl p-8 sm:p-12 shadow-2xl border border-emerald-500/30 flex flex-col md:flex-row items-center justify-between gap-8">
          
          <div className="space-y-3 text-center md:text-left">
            <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold">
              {isTelugu ? 'కరిముల్లా గారితో ప్రత్యక్ష సంప్రదింపులు' : 'Direct Contact With Karimulla Garu'}
            </span>
            <h2 className="font-telugu text-2xl sm:text-3xl md:text-4xl font-bold text-white">
              {REAL_ESTATE_BUSINESS.ownerTelugu}
            </h2>
            <p className={`text-xs sm:text-sm text-emerald-100/90 max-w-xl ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
              {isTelugu 
                ? 'మా ఆఫీస్: నల్లచెరువు, 12వ లైన్, మెయిన్ రోడ్, గుంటూరును సందర్శించండి లేదా నేరుగా ఫోన్ చేయండి. గుంటూరు, మంగళగిరి మరియు అమరావతి పరిధిలో ఉచిత వెహికల్ పికప్ మరియు డ్రాప్‌తో సైట్ పరిశీలన సౌకర్యం కలదు.'
                : 'Visit our office at Nallacheruvu, 12th Line, Main Road, Guntur or call directly. We provide free vehicle pickup and drop for property site inspections across Guntur, Mangalagiri, and Amaravathi.'}
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-4 pt-2 text-xs text-emerald-200">
              <span className="flex items-center gap-1.5 font-telugu">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                {isTelugu ? REAL_ESTATE_BUSINESS.addressTelugu : REAL_ESTATE_BUSINESS.addressEnglish}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5 font-mono font-bold text-sm">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                {rePhoneDisplay}
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-3 w-full sm:w-auto shrink-0">
            <a
              href={`https://wa.me/${rePhoneRaw}?text=${encodeURIComponent(
                isTelugu 
                  ? 'నమస్తే కరిముల్లా గారు, గుంటూరు/అమరావతి ప్రాపర్టీల విషయంలో మాట్లాడాలనుకుంటున్నాను.'
                  : 'Hello Karimulla garu, I want to consult regarding property in Guntur/Amaravathi.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="py-3.5 px-6 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>{isTelugu ? `వాట్సాప్‌లో సంప్రదించండి (${rePhoneDisplay})` : `Contact on WhatsApp (${rePhoneDisplay})`}</span>
            </a>

            <a
              href={`tel:+${rePhoneRaw}`}
              className="py-3.5 px-6 rounded-xl bg-white hover:bg-emerald-50 text-emerald-950 font-bold text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <Phone className="w-4 h-4" />
              <span>{isTelugu ? `కాల్ చేయండి: ${rePhoneDisplay}` : `Call: ${rePhoneDisplay}`}</span>
            </a>
          </div>

        </MotionFadeUp>

      </section>

      {/* Real Estate Footer with Sister Company Link */}
      <footer className="bg-emerald-950 text-emerald-200/80 pt-12 pb-24 sm:pb-16 border-t border-emerald-800/60 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          {/* Sister Company Callout */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-[#4A040F] to-[#7A1526] text-white border border-[#D4AF37]/40 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 flex items-center justify-center text-[#F3DE8A] shrink-0">
                <Tent className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-telugu text-base font-bold text-white">
                  కరిముల్లా టెంట్హౌస్ (Karimulla Tent House)
                </h4>
                <p className="text-xs text-neutral-300 font-telugu">
                  {isTelugu 
                    ? 'టెంట్లు, కుర్చీలు, టేబుళ్ళు, స్టేజ్ డెకరేషన్, వంటసామానులు అద్దెకు ఇవ్వబడును.'
                    : 'Waterproof tents, chairs, tables, stage decoration, and cooking vessels for rent.'}
                </p>
              </div>
            </div>

            <button
              onClick={onSwitchToTentHouse}
              className="py-2.5 px-4 rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs shadow-md transition-all whitespace-nowrap cursor-pointer font-telugu"
            >
              {isTelugu ? 'కరిముల్లా టెంట్హౌస్ చూడండి →' : 'Switch to Karimulla Tent House →'}
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-emerald-900 text-center sm:text-left">
            <p>
              &copy; {new Date().getFullYear()} {isTelugu ? REAL_ESTATE_BUSINESS.nameTelugu : REAL_ESTATE_BUSINESS.name}. {REAL_ESTATE_BUSINESS.ownerTelugu}. Phone: {rePhoneDisplay}.
            </p>
            <div className="flex items-center gap-4">
              <button
                onClick={onSwitchToTentHouse}
                className="hover:text-white transition-colors underline cursor-pointer"
              >
                Karimulla Tent House
              </button>
              <span>·</span>
              <span className={isTelugu ? 'font-telugu' : 'font-sans'}>
                {isTelugu ? REAL_ESTATE_BUSINESS.addressTelugu : REAL_ESTATE_BUSINESS.addressEnglish}
              </span>
            </div>
          </div>

        </div>
      </footer>

      {/* Floating Action Bar on Mobile for Real Estate */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-emerald-950/95 dark:bg-[#03140F]/95 backdrop-blur-md border-t border-emerald-500/30 p-2.5 px-4 flex items-center justify-between gap-3 shadow-2xl">
        <a
          href={`tel:+${rePhoneRaw}`}
          className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>{isTelugu ? 'కాల్' : 'Call'}: {rePhoneDisplay}</span>
        </a>

        <a
          href={`https://wa.me/${rePhoneRaw}?text=${encodeURIComponent(
            isTelugu 
              ? 'నమస్తే కరిముల్లా గారు, గుంటూరు/అమరావతి ప్రాపర్టీల విషయంలో మాట్లాడాలనుకుంటున్నాను.'
              : 'Hello Karimulla garu, I am contacting you regarding real estate property in Guntur/Amaravathi.'
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-3 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm"
        >
          <MessageCircle className="w-3.5 h-3.5 fill-current" />
          <span>WhatsApp</span>
        </a>

        <button
          onClick={onSwitchToTentHouse}
          className="p-2.5 rounded-xl bg-[#7A1526] text-white shadow-sm border border-[#D4AF37]/50"
          title="Switch to Tent House"
        >
          <Tent className="w-4 h-4 text-[#F3DE8A]" />
        </button>
      </div>

    </div>
  );
};
