import React from 'react';
import { X, Trash2, Plus, Minus, MessageCircle, ShoppingBag, ArrowRight } from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';

export interface BasketItem {
  item: {
    id: string;
    name: string;
    teluguName?: string;
    category?: string;
    pricePerDay?: number | string;
    unit?: string;
    description?: string;
    specs?: string;
    image?: string;
    selectedSize?: string;
  };
  quantity: number;
  days: number;
  selectedSize?: string;
}

interface QuoteBasketDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: BasketItem[];
  onUpdateQuantity: (itemId: string, newQty: number) => void;
  onUpdateDays: (itemId: string, newDays: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearAll: () => void;
}

export const QuoteBasketDrawer: React.FC<QuoteBasketDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onUpdateDays,
  onRemoveItem,
  onClearAll,
}) => {
  if (!isOpen) return null;

  const hasPricedItems = items.some(
    (entry) => typeof entry.item.pricePerDay === 'number' && entry.item.pricePerDay > 0
  );

  const totalEstimatedCost = items.reduce((acc, curr) => {
    const price = typeof curr.item.pricePerDay === 'number' ? curr.item.pricePerDay : 0;
    return acc + price * curr.quantity * curr.days;
  }, 0);

  const handleSendWhatsAppQuote = () => {
    if (items.length === 0) return;

    let message = `*KARIMULLA TENT HOUSE - EVENT REQUIREMENT LIST*\n`;
    message += `Hello Karimulla garu, I am requesting a quotation and availability for the following event requirements:\n\n`;

    items.forEach((entry, idx) => {
      message += `${idx + 1}. *${entry.item.name}*\n`;
      if (entry.selectedSize || entry.item.selectedSize) {
        message += `   - Size/Option: ${entry.selectedSize || entry.item.selectedSize}\n`;
      }
      message += `   - Quantity Required: ${entry.quantity}\n`;
      message += `   - Duration: ${entry.days} Day(s)\n`;
      if (typeof entry.item.pricePerDay === 'number' && entry.item.pricePerDay > 0) {
        const subtotal = entry.item.pricePerDay * entry.quantity * entry.days;
        message += `   - Rate: ₹${entry.item.pricePerDay.toLocaleString('en-IN')} ${entry.item.unit || ''}\n`;
        message += `   - Subtotal: ₹${subtotal.toLocaleString('en-IN')}\n`;
      } else {
        message += `   - Rate: Quote on Request\n`;
      }
      message += `\n`;
    });

    if (hasPricedItems && totalEstimatedCost > 0) {
      message += `*Estimated Total: ₹${totalEstimatedCost.toLocaleString('en-IN')}*\n`;
    }
    message += `Please confirm availability, transport & setup charges for Guntur / surrounding area. Thank you!\n`;
    message += `Prop. Shaik Karimulla (Babu) - 98481 47203`;

    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${BUSINESS_DETAILS.phoneRaw}?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-md bg-[#FCF9F5] shadow-2xl flex flex-col border-l border-amber-900/20">
          
          {/* Header */}
          <div className="p-4 sm:p-5 bg-gradient-to-r from-[#4A040F] to-[#7A1526] text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-[#E5C158]" />
              <div>
                <h2 className="font-serif text-lg font-bold">Event Requirement List</h2>
                <p className="text-xs text-neutral-300">
                  {items.length} {items.length === 1 ? 'item' : 'items'} selected
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close basket"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500">
                <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center text-[#7A1526] mb-4">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-base font-bold text-neutral-800">Your requirement list is empty</h3>
                <p className="text-xs text-neutral-500 mt-1 max-w-xs">
                  Browse our catalog and click &ldquo;Add to Requirement List&rdquo; on Dabbalu, Tents, Stoves, Benches, Chairs, Lighting, or Fans.
                </p>
              </div>
            ) : (
              items.map(({ item, quantity, days, selectedSize }) => (
                <div
                  key={item.id}
                  className="p-3.5 bg-white rounded-xl border border-amber-900/10 shadow-xs flex flex-col gap-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      {item.teluguName && (
                        <span className="text-[11px] font-telugu font-bold text-[#7A1526] block leading-tight">
                          {item.teluguName}
                        </span>
                      )}
                      <h4 className="font-serif text-sm font-bold text-neutral-900 leading-snug">
                        {item.name}
                      </h4>
                      {(selectedSize || item.selectedSize) && (
                        <span className="inline-block mt-1 text-[10px] font-semibold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full border border-amber-200">
                          Size: {selectedSize || item.selectedSize}
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-neutral-400 hover:text-red-600 transition-colors p-1 cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-xs text-neutral-600 pt-2 border-t border-neutral-100">
                    {/* Quantity controls */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-neutral-500">Qty:</span>
                      <div className="flex items-center border border-neutral-200 rounded-lg bg-neutral-50">
                        <button
                          onClick={() => onUpdateQuantity(item.id, quantity - 1)}
                          className="p-1 hover:bg-neutral-200 rounded-l transition-colors cursor-pointer"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2.5 py-0.5 text-xs font-mono font-bold">
                          {quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, quantity + 1)}
                          className="p-1 hover:bg-neutral-200 rounded-r transition-colors cursor-pointer"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Days selector */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-neutral-500">Days:</span>
                      <select
                        value={days}
                        onChange={(e) => onUpdateDays(item.id, Number(e.target.value))}
                        className="text-xs bg-neutral-50 border border-neutral-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-[#7A1526]"
                      >
                        {[1, 2, 3, 4, 5, 7, 10].map((d) => (
                          <option key={d} value={d}>
                            {d} {d === 1 ? 'day' : 'days'}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Rate */}
                    <div className="text-right">
                      {typeof item.pricePerDay === 'number' && item.pricePerDay > 0 ? (
                        <span className="font-mono font-bold text-xs text-[#7A1526]">
                          ₹{(item.pricePerDay * quantity * days).toLocaleString('en-IN')}
                        </span>
                      ) : (
                        <span className="text-[10px] text-neutral-500 font-medium italic">
                          Quote on request
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Actions */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 bg-white border-t border-amber-900/10 space-y-3 shadow-lg">
              {hasPricedItems && totalEstimatedCost > 0 ? (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600 font-medium">Estimated Rental:</span>
                  <span className="font-serif text-xl font-extrabold text-[#7A1526] font-mono">
                    ₹{totalEstimatedCost.toLocaleString('en-IN')}
                  </span>
                </div>
              ) : (
                <div className="text-xs text-neutral-600 text-center bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                  <span className="font-medium text-amber-950 font-telugu block">
                    వస్తువుల పరిమాణం మరియు ఈవెంట్ తేదీల ప్రకారం కోటేషన్ ఇవ్వబడును
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Transparent rental rates directly from Karimulla garu
                  </span>
                </div>
              )}

              <button
                onClick={handleSendWhatsAppQuote}
                className="btn-premium btn-shine w-full py-3.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>Send Requirement List on WhatsApp</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={onClearAll}
                  className="text-xs text-neutral-400 hover:text-red-600 transition-colors cursor-pointer"
                >
                  Clear All
                </button>
                <span className="text-[11px] text-neutral-400">
                  Direct reply from 98481 47203
                </span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
