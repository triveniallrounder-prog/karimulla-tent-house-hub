import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Star, 
  ChevronLeft, 
  ChevronRight, 
  Quote, 
  ShieldCheck, 
  MessageSquarePlus, 
  ThumbsUp, 
  X, 
  Send, 
  CheckCircle2, 
  Filter
} from 'lucide-react';
import { INITIAL_REVIEWS_DATA, ClientReview } from '../data/reviewsData';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer } from './motion/MotionFade';

export const TestimonialsSection: React.FC = () => {
  const { isTelugu } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [showAllGrid, setShowAllGrid] = useState(false);

  // Reviews from localStorage or INITIAL_REVIEWS_DATA
  const [reviews, setReviews] = useState<ClientReview[]>(() => {
    try {
      const saved = localStorage.getItem('karimulla_client_reviews');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return INITIAL_REVIEWS_DATA;
  });

  const [likedReviews, setLikedReviews] = useState<Record<string, boolean>>({});

  // Write Review Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newReviewForm, setNewReviewForm] = useState({
    name: '',
    location: '',
    eventType: 'Wedding & Reception',
    rating: 5,
    title: '',
    comment: '',
  });
  const [submitted, setSubmitted] = useState(false);

  // Filtered reviews
  const filteredReviews = useMemo(() => {
    if (activeCategory === 'all') return reviews;
    return reviews.filter((r) => r.category === activeCategory);
  }, [reviews, activeCategory]);

  const carouselList = useMemo(() => {
    return filteredReviews.slice(0, 6);
  }, [filteredReviews]);

  const nextSlide = useCallback(() => {
    if (carouselList.length === 0) return;
    setCurrentIndex((prev) => (prev + 1) % carouselList.length);
  }, [carouselList.length]);

  const prevSlide = useCallback(() => {
    if (carouselList.length === 0) return;
    setCurrentIndex((prev) => (prev - 1 + carouselList.length) % carouselList.length);
  }, [carouselList.length]);

  useEffect(() => {
    if (isPaused || carouselList.length <= 1) return;
    const interval = setInterval(nextSlide, 5500);
    return () => clearInterval(interval);
  }, [isPaused, nextSlide, carouselList.length]);

  // Handle Like
  const handleLike = (id: string) => {
    if (likedReviews[id]) return;
    setLikedReviews((prev) => ({ ...prev, [id]: true }));
    setReviews((prev) =>
      prev.map((r) => (r.id === id ? { ...r, helpfulCount: r.helpfulCount + 1 } : r))
    );
  };

  // Submit Review
  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewForm.name.trim() || !newReviewForm.comment.trim()) return;

    const newRev: ClientReview = {
      id: `rev-${Date.now()}`,
      name: newReviewForm.name.trim(),
      avatarLetter: newReviewForm.name.trim().charAt(0).toUpperCase(),
      location: newReviewForm.location.trim() || 'Andhra Pradesh',
      eventType: newReviewForm.eventType,
      rating: newReviewForm.rating,
      title: newReviewForm.title.trim() || 'Excellent Service & Coordination',
      comment: newReviewForm.comment.trim(),
      date: 'Just now',
      verified: true,
      helpfulCount: 1,
      category: 'weddings',
    };

    const updated = [newRev, ...reviews];
    setReviews(updated);
    try {
      localStorage.setItem('karimulla_client_reviews', JSON.stringify(updated));
    } catch {
      // storage unavailable
    }

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setIsModalOpen(false);
      setNewReviewForm({
        name: '',
        location: '',
        eventType: 'Wedding & Reception',
        rating: 5,
        title: '',
        comment: '',
      });
    }, 1500);
  };

  const current = carouselList[currentIndex] || reviews[0];

  return (
    <section 
      id="reviews" 
      className="py-16 sm:py-24 bg-[#FAF7F2] dark:bg-[#120104] border-b border-amber-900/10 dark:border-[#D4AF37]/20 scroll-mt-16 transition-colors duration-300"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header & Rating Trust Badge */}
        <MotionHeading className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#7A1526]/10 dark:bg-[#38030B] text-[#7A1526] dark:text-[#F3DE8A] text-xs font-semibold uppercase tracking-wider mb-3 border border-amber-900/15 dark:border-[#D4AF37]/30">
            <ShieldCheck className="w-3.5 h-3.5 text-[#B8860B] dark:text-[#E5C158]" />
            <span>4.9 / 5.0 Star Rated · 486+ Verified Client Reviews</span>
          </div>

          <h2 className="font-serif text-2xl sm:text-4xl md:text-5xl font-bold text-[#38030B] dark:text-white tracking-tight leading-tight">
            {isTelugu ? 'మా క్లయింట్ల అనుభవాలు & రేటింగ్స్' : 'Client Reviews & Ratings'}
          </h2>
          <p className="mt-2.5 text-xs sm:text-sm md:text-base text-neutral-600 dark:text-neutral-300 max-w-2xl mx-auto">
            {isTelugu 
              ? 'గుంటూరు మరియు ఆంధ్రప్రదేశ్‌లో మా సేవలను ఎంచుకున్న కుటుంబాలు, క్యాటరర్లు మరియు ఈవెంట్ నిర్వాహకుల నిజమైన అభిప్రాయాలు.'
              : 'Authentic reviews from families, caterers, and event planners who trusted Karimulla Tent House for their auspicious celebrations.'}
          </p>

          {/* Quick Rating Summary Card & Write Review Action */}
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 bg-white dark:bg-[#1E0308] px-3.5 py-1.5 rounded-full border border-neutral-200 dark:border-[#D4AF37]/30 shadow-2xs font-semibold text-neutral-800 dark:text-white">
              <span className="text-amber-500 font-bold text-sm">4.9</span>
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                ))}
              </div>
              <span className="text-neutral-500 dark:text-neutral-400 font-normal ml-1">({reviews.length}+ Reviews)</span>
            </div>

            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#7A1526] hover:bg-[#5C0614] text-white font-semibold text-xs shadow-sm transition-all hover:scale-105 cursor-pointer"
            >
              <MessageSquarePlus className="w-3.5 h-3.5 text-[#F3DE8A]" />
              <span>{isTelugu ? 'రివ్యూ రాయండి' : 'Write a Review / Leave Rating'}</span>
            </button>
          </div>

          {/* Category Tabs */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-1.5 text-xs">
            {[
              { id: 'all', label: isTelugu ? 'అన్నీ' : 'All Reviews' },
              { id: 'weddings', label: isTelugu ? 'వివాహాలు' : 'Weddings & Mandaps' },
              { id: 'utensils', label: isTelugu ? 'డబ్బాలు & వంటపాత్రలు' : 'Dabbalu & Vessels' },
              { id: 'tents', label: isTelugu ? 'వాటర్‌ప్రూఫ్ టెంట్లు' : 'Waterproof Tents' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveCategory(cat.id);
                  setCurrentIndex(0);
                }}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#7A1526] dark:bg-[#D4AF37] text-white dark:text-[#240106] font-bold shadow-xs'
                    : 'bg-white dark:bg-white/5 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-white/10 border border-neutral-200 dark:border-white/10'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </MotionHeading>

        {/* Featured Testimonial Carousel Card */}
        {current && (
          <MotionContainer delay={0.15}>
            <div
              className="relative bg-white dark:bg-[#1E0308] rounded-3xl p-6 sm:p-10 shadow-xl border border-amber-900/10 dark:border-[#D4AF37]/30 transition-colors"
              onMouseEnter={() => setIsPaused(true)}
              onMouseLeave={() => setIsPaused(false)}
            >
            {/* Decorative Quote Mark */}
            <div className="absolute top-6 right-8 text-[#F3DE8A] opacity-25 dark:opacity-15 pointer-events-none">
              <Quote className="w-16 h-16 sm:w-20 sm:h-20" />
            </div>

            <div className="relative z-10 flex flex-col justify-between min-h-[200px]">
              
              {/* Rating Stars & Event Tag */}
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(current.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-500 fill-amber-400" />
                  ))}
                  <span className="text-xs font-bold text-neutral-700 dark:text-neutral-200 ml-1.5">
                    {current.rating}.0 Verified Client
                  </span>
                </div>
                <span className="text-[11px] font-semibold text-[#7A1526] dark:text-[#F3DE8A] bg-[#7A1526]/8 dark:bg-[#D4AF37]/15 px-2.5 py-0.5 rounded-full border border-amber-900/10 dark:border-[#D4AF37]/30">
                  {isTelugu && current.eventTypeTelugu ? current.eventTypeTelugu : current.eventType}
                </span>
              </div>

              {/* Testimonial Headline & Quote */}
              <h3 className="font-sans text-base sm:text-lg font-bold text-neutral-900 dark:text-white mb-2 leading-snug">
                {current.title}
              </h3>
              <blockquote className="text-xs sm:text-sm md:text-base text-neutral-700 dark:text-neutral-200 font-serif leading-relaxed italic mb-6">
                &ldquo;{isTelugu && current.commentTelugu ? current.commentTelugu : current.comment}&rdquo;
              </blockquote>

              {/* Author Meta */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-5 border-t border-neutral-100 dark:border-white/10">
                <div>
                  <h4 className="font-serif text-base sm:text-lg font-bold text-[#38030B] dark:text-white">
                    {isTelugu && current.nameTelugu ? current.nameTelugu : current.name}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    <span className="text-[#9E1B32] dark:text-[#F3DE8A] font-medium">{current.location}</span>
                    <span>·</span>
                    <span>{current.date}</span>
                  </div>
                </div>

                {/* Helpful & Controls */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleLike(current.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      likedReviews[current.id]
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-300'
                        : 'bg-neutral-50 dark:bg-white/5 text-neutral-600 dark:text-neutral-300 border-neutral-200 dark:border-white/10 hover:bg-neutral-100'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>Helpful ({current.helpfulCount})</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={prevSlide}
                      className="p-2 rounded-full border border-neutral-200 dark:border-white/10 hover:bg-neutral-100 dark:hover:bg-white/10 text-neutral-700 dark:text-neutral-300 transition-colors cursor-pointer"
                      aria-label="Previous testimonial"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={nextSlide}
                      className="p-2 rounded-full border border-neutral-200 dark:border-white/10 hover:bg-neutral-100 dark:hover:bg-white/10 text-neutral-700 dark:text-neutral-300 transition-colors cursor-pointer"
                      aria-label="Next testimonial"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

              </div>

            </div>

            {/* Dots Indicator */}
            <div className="flex items-center justify-center gap-2 mt-6">
              {carouselList.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                    currentIndex === idx
                      ? 'w-7 bg-[#7A1526] dark:bg-[#D4AF37]'
                      : 'w-2 bg-neutral-300 dark:bg-neutral-700 hover:bg-neutral-400'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>

          </div>
        </MotionContainer>
        )}

        {/* View All Reviews Accordion Grid */}
        <div className="mt-8 text-center">
          <button
            onClick={() => setShowAllGrid(!showAllGrid)}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white dark:bg-[#1E0308] hover:bg-neutral-50 dark:hover:bg-[#2A050D] text-[#38030B] dark:text-white border border-amber-900/15 dark:border-[#D4AF37]/30 font-bold text-xs sm:text-sm shadow-sm transition-all duration-150 hover:shadow-md cursor-pointer"
          >
            <span>{showAllGrid ? 'Collapse Reviews List' : `View All ${reviews.length}+ Verified Customer Reviews`}</span>
          </button>
        </div>

        {/* All Reviews Grid (When expanded) */}
        {showAllGrid && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-in fade-in duration-300">
            {reviews.map((rev) => (
              <div
                key={rev.id}
                className="p-5 rounded-2xl bg-white dark:bg-[#1E0308] border border-amber-900/10 dark:border-[#D4AF37]/20 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      ))}
                    </div>
                    <span className="text-[10px] text-neutral-400 font-mono">{rev.date}</span>
                  </div>
                  <h4 className="text-sm font-bold text-neutral-900 dark:text-white leading-snug mb-1">
                    {rev.title}
                  </h4>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed italic">
                    &ldquo;{isTelugu && rev.commentTelugu ? rev.commentTelugu : rev.comment}&rdquo;
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-white/10 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-[#38030B] dark:text-[#F3DE8A] block">
                      {isTelugu && rev.nameTelugu ? rev.nameTelugu : rev.name}
                    </span>
                    <span className="text-[11px] text-neutral-400">{rev.location}</span>
                  </div>
                  <button
                    onClick={() => handleLike(rev.id)}
                    className="flex items-center gap-1 text-[11px] text-neutral-500 hover:text-emerald-600 transition-colors"
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>{rev.helpfulCount}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* Write a Review Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-white dark:bg-[#1A0206] rounded-3xl p-6 sm:p-8 shadow-2xl border border-amber-900/20 dark:border-[#D4AF37]/30 relative text-neutral-800 dark:text-white">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5 text-neutral-500" />
            </button>

            {submitted ? (
              <div className="text-center py-8 space-y-3">
                <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
                <h3 className="font-serif text-2xl font-bold">Review Submitted!</h3>
                <p className="text-xs text-neutral-500">Thank you for rating Karimulla Tent House.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div className="text-center mb-4">
                  <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#38030B] dark:text-white">
                    {isTelugu ? 'మీ అనుభవాన్ని రేట్ చేయండి' : 'Rate Your Experience'}
                  </h3>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                    Your feedback helps other families plan their special celebrations.
                  </p>
                </div>

                {/* Rating Stars Selection */}
                <div className="flex flex-col items-center gap-1 pb-2">
                  <span className="text-xs font-semibold text-neutral-600 dark:text-neutral-300">Overall Rating:</span>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setNewReviewForm((prev) => ({ ...prev, rating: star }))}
                        className="p-1 hover:scale-110 transition-transform cursor-pointer"
                      >
                        <Star
                          className={`w-7 h-7 ${
                            star <= newReviewForm.rating
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-neutral-300 dark:text-neutral-600'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      value={newReviewForm.name}
                      onChange={(e) => setNewReviewForm((prev) => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g. Ramesh Varma"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-white/5 border border-neutral-200 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold mb-1">Location / Town</label>
                    <input
                      type="text"
                      value={newReviewForm.location}
                      onChange={(e) => setNewReviewForm((prev) => ({ ...prev, location: e.target.value }))}
                      placeholder="e.g. Guntur / Tenali"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-white/5 border border-neutral-200 dark:border-white/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Review Headline</label>
                  <input
                    type="text"
                    value={newReviewForm.title}
                    onChange={(e) => setNewReviewForm((prev) => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g. Perfect waterproof tent setup & timely delivery"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-white/5 border border-neutral-200 dark:border-white/10"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">Detailed Review *</label>
                  <textarea
                    required
                    rows={3}
                    value={newReviewForm.comment}
                    onChange={(e) => setNewReviewForm((prev) => ({ ...prev, comment: e.target.value }))}
                    placeholder="Tell us about the tent quality, dabbalu vessels, or setup timing..."
                    className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-white/5 border border-neutral-200 dark:border-white/10"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#7A1526] to-[#5C0614] hover:from-[#9E1B32] hover:to-[#7A1526] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-transform hover:scale-[1.01]"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Verified Review</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}

    </section>
  );
};

export default TestimonialsSection;
