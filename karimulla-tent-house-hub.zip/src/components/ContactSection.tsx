import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  Calendar,
  Users,
  AlertCircle
} from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer } from './motion/MotionFade';
import { useSiteData } from '../context/SiteDataContext';

interface ContactSectionProps {
  initialEventType?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ initialEventType = '' }) => {
  const { siteData } = useSiteData();
  const settings = siteData?.settings;

  const phone1 = settings?.phone1 || BUSINESS_DETAILS.phone1;
  const phone1Raw = settings?.phone1Raw || BUSINESS_DETAILS.phone1Raw;
  const phone2 = settings?.phone2 || BUSINESS_DETAILS.phone2;
  const phone2Raw = settings?.phone2Raw || BUSINESS_DETAILS.phone2Raw;
  const email = settings?.email || BUSINESS_DETAILS.email;
  const addressEnglish = settings?.addressEnglish || BUSINESS_DETAILS.addressEnglish;
  const addressTelugu = settings?.addressTelugu || BUSINESS_DETAILS.addressTelugu;

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    eventDate: '',
    eventType: initialEventType || 'Wedding / Reception',
    guestCount: '250 - 500',
    venueLocation: 'Guntur City',
    itemsNeeded: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errorMessage) setErrorMessage('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMessage('Please provide your name and phone number to proceed.');
      return;
    }

    let whatsappText = `*NEW EVENT ENQUIRY - KARIMULLA TENT HOUSE*\n\n`;
    whatsappText += `*Name:* ${formData.name.trim()}\n`;
    whatsappText += `*Phone:* ${formData.phone.trim()}\n`;
    whatsappText += `*Event Type:* ${formData.eventType}\n`;
    if (formData.eventDate) whatsappText += `*Event Date:* ${formData.eventDate}\n`;
    whatsappText += `*Estimated Guests:* ${formData.guestCount}\n`;
    whatsappText += `*Venue / City:* ${formData.venueLocation}\n`;
    if (formData.itemsNeeded.trim()) {
      whatsappText += `*Items Needed:* ${formData.itemsNeeded.trim()}\n`;
    }
    if (formData.message.trim()) {
      whatsappText += `*Message/Notes:* ${formData.message.trim()}\n`;
    }
    whatsappText += `\nPlease check date availability and send quotation. Thank you!`;

    const encoded = encodeURIComponent(whatsappText);
    window.open(`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encoded}`, '_blank');
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 sm:py-24 bg-[#FAF7F2] border-b border-amber-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <MotionHeading className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs uppercase font-semibold tracking-wider text-[#9E1B32] mb-2">
            Get in Touch
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] tracking-tight">
            Reserve Your Event Equipment
          </h2>
          <p className="mt-3 text-base text-neutral-600">
            Tell us about your upcoming celebration. Karimulla garu and our coordination team will review your requirements and provide an immediate quotation.
          </p>
        </MotionHeading>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12">
          
          {/* Left Column: Direct Contact & Location Details */}
          <MotionContainer delay={0.15} className="lg:col-span-5 space-y-6">
            
            <div className="bg-gradient-to-br from-[#38030B] to-[#5C0614] text-white p-7 sm:p-8 rounded-3xl shadow-xl border border-[#D4AF37]/30 space-y-6">
              
              <div>
                <span className="text-xs uppercase tracking-widest text-[#E5C158] font-semibold">
                  Personal Assistance
                </span>
                <h3 className="font-telugu text-xl sm:text-2xl font-bold text-white mt-1">
                  {BUSINESS_DETAILS.ownerTelugu}
                </h3>
                <p className="text-xs sm:text-sm text-neutral-300 mt-0.5">
                  {BUSINESS_DETAILS.ownerEnglish}
                </p>
                <p className="text-xs text-[#E5C158] font-telugu mt-1">
                  {BUSINESS_DETAILS.taglineTelugu}
                </p>
              </div>

              <div className="space-y-4 text-sm pt-2 border-t border-white/10">
                
                {/* Phones (Both tap-to-call links) */}
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#F3DE8A] shrink-0 mt-0.5">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-neutral-400 block">Phone & WhatsApp (Tap to Call):</span>
                    <div className="flex flex-col gap-1 mt-1">
                      <a
                        href={`tel:+${phone1Raw}`}
                        className="font-bold text-base text-white hover:text-[#F3DE8A] transition-colors inline-flex items-center gap-1.5"
                      >
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span>{phone1}</span>
                      </a>
                      {phone2 && (
                        <a
                          href={`tel:+${phone2Raw}`}
                          className="font-bold text-base text-white hover:text-[#F3DE8A] transition-colors inline-flex items-center gap-1.5"
                        >
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          <span>{phone2}</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#F3DE8A] shrink-0 mt-0.5">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-neutral-400 block">Email Inquiries:</span>
                    <a
                      href={`mailto:${email}`}
                      className="text-white hover:text-[#F3DE8A] transition-colors break-all"
                    >
                      {email}
                    </a>
                  </div>
                </div>

                {/* Address */}
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#F3DE8A] shrink-0 mt-0.5">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-neutral-400 block">Office & Warehouse Address:</span>
                    <p className="text-white font-telugu text-sm leading-relaxed mt-0.5">
                      {addressTelugu}
                    </p>
                    <p className="text-neutral-300 font-sans text-xs mt-0.5">
                      {addressEnglish}
                    </p>
                  </div>
                </div>

                {/* Working Hours */}
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#F3DE8A] shrink-0 mt-0.5">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-neutral-400 block">Operating Hours:</span>
                    <p className="text-white">
                      {BUSINESS_DETAILS.workingHours}
                    </p>
                  </div>
                </div>

              </div>

              {/* Direct WhatsApp Quick Button */}
              <div className="pt-2">
                <a
                  href={`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(
                    'Hello Karimulla garu, I am reaching out through your website to plan an event.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform hover:scale-[1.01]"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Chat on WhatsApp ({BUSINESS_DETAILS.phone1})</span>
                </a>
              </div>

            </div>

            {/* Google Maps Embed Card */}
            <div className="rounded-2xl overflow-hidden shadow-md border border-amber-900/10 bg-white">
              <div className="p-3 bg-amber-50/70 border-b border-amber-900/10 flex items-center justify-between text-xs text-neutral-600">
                <span className="font-semibold flex items-center gap-1.5 text-[#38030B]">
                  <MapPin className="w-4 h-4 text-[#7A1526]" />
                  <span>నల్లచెరువు 12వ లైన్, గుంటూరు</span>
                </span>
                <span>Nallacheruvu, Guntur</span>
              </div>
              <iframe
                title="Karimulla Tent House Location Map - Nallacheruvu Guntur"
                src={BUSINESS_DETAILS.googleMapsEmbedUrl}
                width="100%"
                height="220"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full"
              />
            </div>

          </MotionContainer>

          {/* Right Column: Interactive Enquiry Form */}
          <MotionContainer delay={0.25} className="lg:col-span-7">
            <div className="bg-white p-7 sm:p-9 rounded-3xl shadow-xl border border-amber-900/10">
              
              <div className="mb-6">
                <h3 className="font-serif text-2xl font-bold text-[#38030B]">
                  Fast Event Booking & WhatsApp Quotation
                </h3>
                <p className="text-xs sm:text-sm text-neutral-500 mt-1">
                  Fill in your event details below. Clicking &ldquo;Send Enquiry via WhatsApp&rdquo; will format and open your custom booking request directly to Karimulla garu.
                </p>
              </div>

              {submitted && (
                <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="text-xs sm:text-sm">
                    <strong>WhatsApp Request Prepared!</strong> If WhatsApp didn&apos;t automatically open, click the button below to re-send or call Karimulla at {BUSINESS_DETAILS.phone}.
                  </div>
                </div>
              )}

              {errorMessage && (
                <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div className="text-xs sm:text-sm">{errorMessage}</div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                
                {/* Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="e.g. Ramesh Naidu / Syed Ahmed"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                      Phone / WhatsApp Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      placeholder="e.g. 98480 12345"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                    />
                  </div>
                </div>

                {/* Event Type & Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                      Type of Event
                    </label>
                    <select
                      name="eventType"
                      value={formData.eventType}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                    >
                      <option value="Wedding / Reception">Wedding / Reception</option>
                      <option value="Haldi / Mehendi / Sangeet">Haldi / Mehendi / Sangeet</option>
                      <option value="Birthday Party / Milestone">Birthday Party / Milestone</option>
                      <option value="Religious Function / Pooja">Religious Function / Pooja</option>
                      <option value="Corporate Expo / Meeting">Corporate Expo / Meeting</option>
                      <option value="Annadanam / Community Feast">Annadanam / Community Feast</option>
                      <option value="Other Function">Other Function</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                      Event Date
                    </label>
                    <div className="relative">
                      <input
                        type="date"
                        name="eventDate"
                        value={formData.eventDate}
                        onChange={handleChange}
                        className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Guests & Location */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                      Estimated Guest Count
                    </label>
                    <select
                      name="guestCount"
                      value={formData.guestCount}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                    >
                      <option value="50 - 150 guests">50 - 150 guests</option>
                      <option value="150 - 300 guests">150 - 300 guests</option>
                      <option value="300 - 600 guests">300 - 600 guests</option>
                      <option value="600 - 1,500 guests">600 - 1,500 guests</option>
                      <option value="1,500 - 3,000+ guests">1,500 - 3,000+ guests</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                      Venue / City / Town
                    </label>
                    <input
                      type="text"
                      name="venueLocation"
                      placeholder="e.g. Brodipet / Tenali / Amaravathi"
                      value={formData.venueLocation}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                    />
                  </div>
                </div>

                {/* Items Needed */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                    Items & Equipment Required
                  </label>
                  <input
                    type="text"
                    name="itemsNeeded"
                    placeholder="e.g. German Tent (40x60), 300 Chiavari chairs, Stage mandap, Sound system"
                    value={formData.itemsNeeded}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                  />
                </div>

                {/* Message */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wide mb-1.5">
                    Additional Instructions or Queries
                  </label>
                  <textarea
                    name="message"
                    rows={3}
                    placeholder="Any specific color themes, delivery timing constraints, or questions..."
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#FAF7F2] border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all"
                  />
                </div>

                {/* Submit Action */}
                <button
                  type="submit"
                  className="btn-premium btn-shine btn-maroon-glow w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#7A1526] via-[#9E1B32] to-[#5C0614] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-lg shadow-black/20 cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5 fill-current" />
                  <span>Send Enquiry to Karimulla via WhatsApp</span>
                  <Send className="w-4 h-4 ml-1" />
                </button>

                <p className="text-center text-[11px] text-neutral-500">
                  Instant response guaranteed. No spam. You talk directly with the owner Karimulla garu.
                </p>

              </form>

            </div>
          </MotionContainer>

        </div>

      </div>
    </section>
  );
};
