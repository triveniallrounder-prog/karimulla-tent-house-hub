import React, { useState, useEffect, useCallback } from 'react';
import { 
  OUR_ITEMS_CATALOG, 
  CatalogItem, 
  getProductWhatsAppUrl 
} from '../data/ourItemsData';
import { 
  MessageCircle, 
  Eye, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Check, 
  PhoneCall, 
  ShoppingBag,
  Maximize2
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useSiteData } from '../context/SiteDataContext';
import { BUSINESS_DETAILS } from '../data/rentalData';

interface OurItemsSectionProps {
  onAddToBasket?: (item: any) => void;
  onOpenBasket?: () => void;
}

export const OurItemsSection: React.FC<OurItemsSectionProps> = ({
  onAddToBasket,
  onOpenBasket,
}) => {
  const { isTelugu } = useLanguage();
  const { siteData } = useSiteData();
  const [selectedItemIndex, setSelectedItemIndex] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // WhatsApp number priority: admin site settings > rental data constant
  const phoneRaw = siteData?.settings?.phone1Raw || BUSINESS_DETAILS.phone1Raw || '919848147203';
  const phoneDisplay = siteData?.settings?.phone1 || BUSINESS_DETAILS.phone1 || '98481 47203';

  // Selected item for Lightbox modal
  const selectedItem = selectedItemIndex !== null ? OUR_ITEMS_CATALOG[selectedItemIndex] : null;

  // Handle keyboard navigation for Lightbox modal
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (selectedItemIndex === null) return;
      if (e.key === 'Escape') {
        setSelectedItemIndex(null);
      } else if (e.key === 'ArrowLeft') {
        setSelectedItemIndex((prev) => 
          prev !== null ? (prev === 0 ? OUR_ITEMS_CATALOG.length - 1 : prev - 1) : null
        );
      } else if (e.key === 'ArrowRight') {
        setSelectedItemIndex((prev) => 
          prev !== null ? (prev === OUR_ITEMS_CATALOG.length - 1 ? 0 : prev + 1) : null
        );
      }
    },
    [selectedItemIndex]
  );

  useEffect(() => {
    if (selectedItemIndex !== null) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedItemIndex, handleKeyDown]);

  const handleNext = () => {
    if (selectedItemIndex !== null) {
      setSelectedItemIndex((selectedItemIndex + 1) % OUR_ITEMS_CATALOG.length);
    }
  };

  const handlePrev = () => {
    if (selectedItemIndex !== null) {
      setSelectedItemIndex(
        selectedItemIndex === 0 ? OUR_ITEMS_CATALOG.length - 1 : selectedItemIndex - 1
      );
    }
  };

  const handleAddAndNotify = (item: CatalogItem) => {
    if (onAddToBasket) {
      onAddToBasket({
        id: item.id,
        name: item.name,
        teluguName: item.nameTelugu,
        category: item.category,
        pricePerDay: 0,
        unit: 'per day',
        selectedSize: 'Standard',
      });
      setCopiedKey(item.id);
      setTimeout(() => {
        setCopiedKey((prev) => (prev === item.id ? null : prev));
      }, 2000);
    }
  };

  // Filter items if user chooses a category, while keeping original sequence numbers
  const filteredItems = activeFilter === 'all'
    ? OUR_ITEMS_CATALOG
    : OUR_ITEMS_CATALOG.filter((i) => i.category === activeFilter);

  return (
    <section 
      id="our-items" 
      className="py-16 sm:py-24 bg-[#FCF9F5] dark:bg-[#120104] text-neutral-800 dark:text-neutral-100 border-b border-[#D4AF37]/20 transition-colors duration-300 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header: Requirement exact texts */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14 reveal-on-scroll">
          
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#7A1526]/10 dark:bg-[#D4AF37]/15 text-[#7A1526] dark:text-[#F3DE8A] text-xs font-semibold uppercase tracking-wider mb-3 border border-[#7A1526]/20 dark:border-[#D4AF37]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#9E1B32] dark:text-[#E5C158]" />
            <span className={isTelugu ? 'font-telugu' : 'font-sans'}>
              {isTelugu ? 'మా ప్రత్యేక సామాగ్రి' : 'Original Event Inventory'}
            </span>
            <span aria-hidden="true">·</span>
            <span>PDF Catalogue</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] dark:text-white tracking-tight">
            {isTelugu ? 'మా సామాగ్రి' : 'Our Items'}
          </h2>
          
          <p className="mt-2.5 text-base sm:text-lg text-neutral-600 dark:text-neutral-300 font-medium">
            {isTelugu ? 'అన్ని రకాల మోడల్స్ మరియు సైజులలో లభించును.' : 'All models and sizes available.'}
          </p>

          <p className="mt-1 text-xs sm:text-sm text-[#7A1526] dark:text-[#E5C158] font-medium">
            {isTelugu
              ? 'ఫోటోపై క్లిక్ చేసి పెద్ద సైజులో చూడవచ్చు • నేరుగా వాట్సాప్‌లో విచారించండి'
              : 'Click any photo for high-resolution preview • Instant WhatsApp enquiry with prefilled message'}
          </p>
        </div>

        {/* Category Filter Tabs (Quiet, responsive) */}
        <div className="flex items-center justify-center flex-wrap gap-2 mb-10">
          <button
            type="button"
            onClick={() => setActiveFilter('all')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-[#7A1526] text-white shadow-sm ring-2 ring-[#D4AF37]/50'
                : 'bg-white dark:bg-black/40 text-neutral-600 dark:text-neutral-300 hover:text-[#7A1526] dark:hover:text-[#F3DE8A] border border-neutral-200 dark:border-neutral-800'
            }`}
          >
            {isTelugu ? 'అన్నీ (13 వస్తువులు)' : 'All Items (13)'}
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('Furniture & Seating')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              activeFilter === 'Furniture & Seating'
                ? 'bg-[#7A1526] text-white shadow-sm ring-2 ring-[#D4AF37]/50'
                : 'bg-white dark:bg-black/40 text-neutral-600 dark:text-neutral-300 hover:text-[#7A1526] dark:hover:text-[#F3DE8A] border border-neutral-200 dark:border-neutral-800'
            }`}
          >
            {isTelugu ? 'కుర్చీలు & సీటింగ్' : 'Furniture & Seating'}
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('Linen & Bedding')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              activeFilter === 'Linen & Bedding'
                ? 'bg-[#7A1526] text-white shadow-sm ring-2 ring-[#D4AF37]/50'
                : 'bg-white dark:bg-black/40 text-neutral-600 dark:text-neutral-300 hover:text-[#7A1526] dark:hover:text-[#F3DE8A] border border-neutral-200 dark:border-neutral-800'
            }`}
          >
            {isTelugu ? 'టేబుల్ క్లాత్స్ & టెంట్లు' : 'Tents & Table Cloths'}
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('Catering Utensils')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              activeFilter === 'Catering Utensils'
                ? 'bg-[#7A1526] text-white shadow-sm ring-2 ring-[#D4AF37]/50'
                : 'bg-white dark:bg-black/40 text-neutral-600 dark:text-neutral-300 hover:text-[#7A1526] dark:hover:text-[#F3DE8A] border border-neutral-200 dark:border-neutral-800'
            }`}
          >
            {isTelugu ? 'వంట & డైనింగ్ సామాగ్రి' : 'Catering Utensils'}
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('Cooking Equipment')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              activeFilter === 'Cooking Equipment'
                ? 'bg-[#7A1526] text-white shadow-sm ring-2 ring-[#D4AF37]/50'
                : 'bg-white dark:bg-black/40 text-neutral-600 dark:text-neutral-300 hover:text-[#7A1526] dark:hover:text-[#F3DE8A] border border-neutral-200 dark:border-neutral-800'
            }`}
          >
            {isTelugu ? 'గ్యాస్ స్టవ్‌లు & భట్టీలు' : 'Gas Stoves & Cooking'}
          </button>
        </div>

        {/* Responsive Grid: 3 columns desktop, 2 on tablet, 1 on mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item) => {
            const indexInMaster = OUR_ITEMS_CATALOG.findIndex((i) => i.id === item.id);
            const waUrl = getProductWhatsAppUrl(item.name, phoneRaw);

            return (
              <div
                key={item.id}
                className="group relative flex flex-col bg-white dark:bg-[#1B0508] rounded-2xl overflow-hidden border border-neutral-200 dark:border-[#D4AF37]/25 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
              >
                {/* Sequence Number Badge (Top Left Corner) */}
                <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md text-white font-mono text-xs font-bold border border-[#D4AF37]/60 shadow-sm pointer-events-none">
                  <span className="text-[#F3DE8A]">#{item.sequence}</span>
                </div>

                {/* Zoom / Lightbox Trigger Pill (Top Right Corner) */}
                <button
                  type="button"
                  onClick={() => setSelectedItemIndex(indexInMaster)}
                  aria-label={`Open large preview of ${item.name}`}
                  className="absolute top-3 right-3 z-10 p-2 rounded-full bg-black/60 hover:bg-black/85 text-white/90 hover:text-white transition-all backdrop-blur-md cursor-pointer opacity-90 group-hover:opacity-100 group-hover:scale-105"
                  title="Click for larger preview"
                >
                  <Maximize2 className="w-4 h-4 text-[#F3DE8A]" />
                </button>

                {/* Card Top: Product Image with consistent aspect ratio, object-fit contain, white background */}
                <div 
                  onClick={() => setSelectedItemIndex(indexInMaster)}
                  className="relative w-full aspect-[4/3] bg-white dark:bg-white p-3 sm:p-4 flex items-center justify-center overflow-hidden cursor-zoom-in border-b border-neutral-100 dark:border-neutral-800"
                >
                  <img
                    src={item.image}
                    alt={item.alt}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="max-h-full max-w-full object-contain transition-transform duration-500 group-hover:scale-105 select-none"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors pointer-events-none flex items-center justify-center">
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-black/70 text-white text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 shadow-md">
                      <Eye className="w-3.5 h-3.5 text-[#F3DE8A]" />
                      <span>{isTelugu ? 'పెద్దదిగా చూడండి' : 'Preview'}</span>
                    </span>
                  </div>
                </div>

                {/* Card Body: Name, Sequence Number, Category, and Details */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-[#9E1B32] dark:text-[#F3DE8A]">
                        {isTelugu ? item.categoryTelugu : item.category}
                      </span>
                      <span className="text-[11px] font-mono text-neutral-400 dark:text-neutral-500">
                        Item {item.sequence} of 13
                      </span>
                    </div>

                    {/* Product Name (Exact as written in catalogue) */}
                    <h3 className="text-lg sm:text-xl font-bold text-[#38030B] dark:text-white group-hover:text-[#9E1B32] dark:group-hover:text-[#F3DE8A] transition-colors line-clamp-1">
                      {item.name}
                    </h3>

                    {/* Telugu Title Subtitle */}
                    <p className="text-xs sm:text-sm font-medium text-neutral-600 dark:text-neutral-300 font-telugu mt-0.5 line-clamp-1">
                      {item.nameTelugu}
                    </p>

                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                      {isTelugu ? item.descriptionTelugu : item.description}
                    </p>
                  </div>

                  {/* Actions Area: "Enquire Now" WhatsApp CTA + Optional Add to Quote */}
                  <div className="mt-5 pt-4 border-t border-neutral-100 dark:border-neutral-800/80 flex flex-col gap-2">
                    
                    {/* Primary Button: "Enquire Now" WhatsApp (Exact requirement) */}
                    <a
                      href={waUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all duration-200 transform active:scale-98 cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 text-white" />
                      <span>{isTelugu ? 'ఇప్పుడే విచారించండి (వాట్సాప్)' : 'Enquire Now'}</span>
                    </a>

                    {/* Secondary Action: Add to Quote Drawer */}
                    {onAddToBasket && (
                      <button
                        type="button"
                        onClick={() => handleAddAndNotify(item)}
                        className={`w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                          copiedKey === item.id
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-300'
                            : 'bg-neutral-50 dark:bg-white/5 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-white/10 border-neutral-200 dark:border-neutral-700'
                        }`}
                      >
                        {copiedKey === item.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{isTelugu ? 'కోట్ కు జోడించబడింది' : 'Added to Quote Basket'}</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5 text-neutral-500 dark:text-neutral-400" />
                            <span>{isTelugu ? '+ కోట్ బాస్కెట్‌కు జోడించండి' : '+ Add to Quote Basket'}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Helper Strip */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-[#38030B] to-[#5C0A1A] text-white border border-[#D4AF37]/30 shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-center md:text-left">
            <h4 className="font-serif text-lg sm:text-xl font-bold text-[#F3DE8A]">
              {isTelugu ? 'మొత్తం కేటలాగ్ పై ప్రత్యేక ఆఫర్లు & డెలివరీ' : 'Need Full Setup or Custom Package?'}
            </h4>
            <p className="text-xs sm:text-sm text-neutral-200 mt-1">
              {isTelugu
                ? 'పెళ్లిళ్లు, శుభకార్యాలు మరియు పబ్లిక్ ఈవెంట్లకు కావాల్సిన సామాగ్రి మొత్తం ఒకేచోట లభించును.'
                : 'We supply complete event tentage, dining furniture, kitchen utensils, and staging across Guntur & surrounding districts.'}
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a
              href={`tel:+${phoneRaw}`}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs sm:text-sm transition-colors shadow-sm"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call: {phoneDisplay}</span>
            </a>
            <a
              href={`https://wa.me/${phoneRaw}?text=${encodeURIComponent('Hello Karimulla Tent House, I would like to get a complete price quotation for an upcoming event.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm transition-colors shadow-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>
      </div>

      {/* FULLSCREEN LIGHTBOX PREVIEW MODAL */}
      {selectedItem && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setSelectedItemIndex(null)}
          role="dialog"
          aria-modal="true"
          aria-label={selectedItem.name}
        >
          {/* Modal Content Box */}
          <div 
            className="relative max-w-4xl w-full bg-white dark:bg-[#1A0307] rounded-2xl overflow-hidden shadow-2xl border border-[#D4AF37]/50 flex flex-col max-h-[92vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header: Item Name, Counter & Close Button */}
            <div className="px-5 py-3.5 bg-[#2B0208] text-white flex items-center justify-between border-b border-[#D4AF37]/30">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs px-2.5 py-0.5 rounded-full bg-[#D4AF37] text-[#240106] font-bold">
                  Item #{selectedItem.sequence}
                </span>
                <div>
                  <h3 className="font-serif text-base sm:text-lg font-bold text-white">
                    {selectedItem.name}
                  </h3>
                  <span className="text-xs text-[#F3DE8A] font-telugu block sm:inline">
                    {selectedItem.nameTelugu}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-neutral-300 hidden sm:inline">
                  {selectedItemIndex! + 1} of {OUR_ITEMS_CATALOG.length}
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedItemIndex(null)}
                  className="p-1.5 rounded-full bg-white/10 hover:bg-white/25 text-white transition-colors cursor-pointer"
                  aria-label="Close preview"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Main Image Area with Previous & Next controls */}
            <div className="relative flex-1 bg-neutral-100 dark:bg-black/60 flex items-center justify-center p-4 sm:p-8 min-h-[300px] sm:min-h-[460px] overflow-hidden">
              
              {/* Prev Button */}
              <button
                type="button"
                onClick={handlePrev}
                className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white shadow-lg backdrop-blur-xs transition-all cursor-pointer focus:outline-none"
                aria-label="Previous item"
                title="Previous item"
              >
                <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>

              {/* High-res Image Display */}
              <div className="w-full h-full max-h-[55vh] flex items-center justify-center">
                <img
                  src={selectedItem.image}
                  alt={selectedItem.alt}
                  className="max-w-full max-h-[55vh] object-contain rounded-lg shadow-md bg-white p-2"
                />
              </div>

              {/* Next Button */}
              <button
                type="button"
                onClick={handleNext}
                className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white shadow-lg backdrop-blur-xs transition-all cursor-pointer focus:outline-none"
                aria-label="Next item"
                title="Next item"
              >
                <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>

            {/* Modal Footer: Description & Direct WhatsApp Enquiry */}
            <div className="p-4 sm:p-5 bg-white dark:bg-[#150205] border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-left w-full sm:w-auto">
                <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300">
                  {isTelugu ? selectedItem.descriptionTelugu : selectedItem.description}
                </p>
                {selectedItem.highlights && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {selectedItem.highlights.map((h, i) => (
                      <span 
                        key={i}
                        className="text-[10px] font-medium px-2 py-0.5 rounded bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-300"
                      >
                        ✓ {h}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-end">
                <a
                  href={getProductWhatsAppUrl(selectedItem.name, phoneRaw)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{isTelugu ? 'ఈ వస్తువుపై వాట్సాప్ విచారణ' : 'Enquire on WhatsApp'}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
