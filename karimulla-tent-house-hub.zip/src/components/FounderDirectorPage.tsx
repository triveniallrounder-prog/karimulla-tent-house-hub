import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  Phone, 
  MessageCircle, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Tent, 
  Users, 
  Award, 
  Sparkles, 
  Clock, 
  HeartHandshake, 
  User, 
  Send, 
  ChevronRight,
  FileCheck,
  Star
} from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useSiteData } from '../context/SiteDataContext';
import { Sun, Moon, Crown } from 'lucide-react';

interface FounderDirectorPageProps {
  onSwitchToTentHouse: () => void;
  onSwitchToPartners: () => void;
  onSwitchToRealEstate: () => void;
  onSwitchToReviews?: () => void;
}

export const FounderDirectorPage: React.FC<FounderDirectorPageProps> = ({
  onSwitchToTentHouse,
  onSwitchToPartners,
  onSwitchToRealEstate,
  onSwitchToReviews,
}) => {
  const { isTelugu, setLanguage } = useLanguage();
  const { toggleTheme, isDark } = useTheme();
  const { siteData } = useSiteData();
  const founder = siteData?.founder;

  const [contactForm, setContactForm] = useState({
    name: '',
    phone: '',
    purpose: 'Event Tent & Equipment Booking',
    eventDate: '',
    message: ''
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name.trim() || !contactForm.phone.trim()) return;

    let text = `*DIRECT INQUIRY FOR FOUNDER & DIRECTOR*\n`;
    text += `*Prop. Shaik Karimulla (Babu) Garu*\n\n`;
    text += `*Client Name:* ${contactForm.name.trim()}\n`;
    text += `*Phone:* ${contactForm.phone.trim()}\n`;
    text += `*Purpose:* ${contactForm.purpose}\n`;
    if (contactForm.eventDate) text += `*Event Date:* ${contactForm.eventDate}\n`;
    if (contactForm.message.trim()) text += `*Message:* ${contactForm.message.trim()}\n`;
    text += `\nHello Karimulla garu, I am reaching out to you directly through your Founder & Director website. Please advise. Thank you!`;

    window.open(`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(text)}`, '_blank');
    setFormSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#FCF9F5] text-neutral-800 font-sans antialiased selection:bg-[#7A1526] selection:text-white pb-20 sm:pb-0">
      
      {/* Top Sticky Header (Compact & Mobile Responsive) */}
      <header className="sticky top-0 z-40 bg-[#38030B]/95 backdrop-blur-md shadow-lg border-b border-[#D4AF37]/30 py-2 text-white">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8 flex items-center justify-between gap-2">
          
          {/* Brand */}
          <div className="flex items-center gap-2 min-w-0 shrink">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#E5C158] to-[#B8860B] flex items-center justify-center text-[#38030B] font-bold text-base font-serif shrink-0 shadow-xs">
              K
            </div>
            <div className="min-w-0">
              <span className={`text-xs sm:text-base font-bold tracking-tight text-white block leading-tight truncate ${isTelugu ? 'font-telugu' : 'font-sans'}`}>
                {isTelugu ? 'వ్యవస్థాపకులు & డైరెక్టర్' : 'Founder & Director'}
              </span>
              <span className="text-[10px] tracking-wide text-[#E5C158] font-sans font-medium hidden md:block truncate">
                {BUSINESS_DETAILS.ownerEnglish} · Karimulla Enterprises
              </span>
            </div>
          </div>

          {/* Quick Page Nav Buttons */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            
            {/* Dark Mode / Light Mode Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              className="p-1 sm:p-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-[#F3DE8A] border border-[#D4AF37]/40 shadow-xs transition-colors cursor-pointer shrink-0"
              title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
              aria-label={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDark ? (
                <Sun className="w-3.5 h-3.5 text-amber-300" />
              ) : (
                <Moon className="w-3.5 h-3.5 text-[#F3DE8A]" />
              )}
            </button>

            {/* Language Toggle */}
            <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-[#D4AF37]/40 text-xs shrink-0">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
                  !isTelugu ? 'bg-[#D4AF37] text-[#240106] font-bold' : 'text-white/80 hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('te')}
                className={`px-1.5 py-0.5 text-[11px] rounded font-telugu transition-colors cursor-pointer ${
                  isTelugu ? 'bg-[#D4AF37] text-[#240106] font-bold' : 'text-white/80 hover:text-white'
                }`}
              >
                తెలుగు
              </button>
            </div>

            {/* Switch to Tent House Home */}
            <button
              onClick={onSwitchToTentHouse}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-[#F3DE8A] border border-[#D4AF37]/40 transition-colors cursor-pointer shrink-0"
              title="Return to Karimulla Tent House Home"
            >
              <Tent className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isTelugu ? 'హోమ్' : 'Home'}</span>
            </button>

            {/* Switch to Partners & Teams Page */}
            <button
              onClick={onSwitchToPartners}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-white border border-[#D4AF37]/40 transition-colors cursor-pointer shrink-0"
              title="View Trusted Partners & Specialized Teams"
            >
              <Users className="w-3.5 h-3.5 text-[#E5C158]" />
              <span className="hidden sm:inline">{isTelugu ? 'టీమ్స్ (3rd)' : 'Teams (3rd)'}</span>
            </button>

            {/* Switch to Reviews (4th Page) */}
            {onSwitchToReviews && (
              <button
                onClick={onSwitchToReviews}
                className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-[#F3DE8A] border border-[#D4AF37]/40 transition-colors cursor-pointer shrink-0"
                title="View Client Reviews & Ratings"
              >
                <Star className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                <span className="hidden md:inline">{isTelugu ? 'రేటింగ్స్ (4th)' : 'Reviews (4th)'}</span>
              </button>
            )}

            {/* Switch to Real Estate (Guaranteed to Never Cut Off) */}
            <button
              onClick={onSwitchToRealEstate}
              className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white shadow-xs border border-emerald-400/50 transition-transform active:scale-95 cursor-pointer shrink-0"
              title="Open Karimulla Real Estate"
            >
              <Building2 className="w-3.5 h-3.5 text-emerald-200 shrink-0" />
              <span className="hidden sm:inline font-sans">{isTelugu ? 'రియల్ ఎస్టేట్' : 'Real Estate'}</span>
              <span className="sm:hidden font-sans font-bold">RE</span>
            </button>
          </div>

        </div>
      </header>

      {/* Hero Section: Founder & Director Introduction */}
      <section className="relative py-16 sm:py-24 bg-gradient-to-b from-[#2D0208] via-[#38030B] to-[#4A040F] text-white overflow-hidden">
        <div 
          aria-hidden="true" 
          className="absolute inset-0 opacity-10 bg-[radial-gradient(#F3DE8A_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none"
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            
            {/* Left: Founder Large Portrait Frame Slot */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="w-full max-w-md p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#1C0105] to-[#38030B] border-4 border-[#D4AF37]/40 shadow-2xl text-center flex flex-col items-center">
                
                {/* Chairman / Founder Photo or Royal Insignia Crest */}
                {founder?.photo && founder?.showPhoto ? (
                  <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl overflow-hidden ring-4 ring-[#D4AF37] border-2 border-white/20 shadow-2xl mb-6 bg-[#1C0105]">
                    <img
                      src={founder.photo}
                      alt={founder.name || BUSINESS_DETAILS.ownerEnglish}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                ) : (
                  <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl bg-gradient-to-br from-[#4A040F] to-[#1C0105] ring-4 ring-[#D4AF37] border-2 border-white/20 shadow-2xl mb-6 flex flex-col items-center justify-center p-4">
                    <Crown className="w-14 h-14 text-[#F3DE8A] drop-shadow-md" />
                    <span className="text-xs font-bold text-[#F3DE8A] tracking-widest uppercase mt-2">22+ YEARS TRUST</span>
                  </div>
                )}

                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F3DE8A] text-xs font-bold uppercase tracking-wider mb-2">
                  <Award className="w-3.5 h-3.5 text-[#E5C158]" />
                  <span>వ్యవస్థాపకులు & డైరెక్టర్</span>
                </div>

                {/* Owner Names */}
                <h1 className="font-telugu text-2xl sm:text-3xl font-bold text-white leading-tight">
                  {BUSINESS_DETAILS.ownerTelugu}
                </h1>
                <p className="font-sans text-sm text-[#F3DE8A] font-semibold mt-1">
                  {BUSINESS_DETAILS.ownerEnglish}
                </p>
                <p className="text-xs text-neutral-300 font-sans mt-0.5">
                  Founder & Managing Director · Karimulla Tent House & Real Estate
                </p>

                {/* Direct Contact Badges */}
                <div className="mt-5 pt-4 border-t border-white/10 w-full space-y-2.5 text-xs">
                  <div className="flex items-center justify-center gap-2 text-white">
                    <Phone className="w-4 h-4 text-[#E5C158]" />
                    <span className="text-neutral-400">Direct Line:</span>
                    <a href={`tel:+${BUSINESS_DETAILS.phone1Raw}`} className="font-mono font-bold text-base hover:text-[#F3DE8A] transition-colors">
                      {BUSINESS_DETAILS.phone1}
                    </a>
                  </div>
                  <div className="flex items-center justify-center gap-2 text-white">
                    <Phone className="w-4 h-4 text-[#E5C158]" />
                    <span className="text-neutral-400">Alternate:</span>
                    <a href={`tel:+${BUSINESS_DETAILS.phone2Raw}`} className="font-mono font-bold text-base hover:text-[#F3DE8A] transition-colors">
                      {BUSINESS_DETAILS.phone2}
                    </a>
                  </div>
                  <div className="flex items-center justify-center gap-1.5 text-neutral-300 font-telugu text-center text-xs">
                    <MapPin className="w-3.5 h-3.5 text-[#E5C158] shrink-0" />
                    <span>{BUSINESS_DETAILS.addressTelugu}</span>
                  </div>
                </div>

                {/* WhatsApp Direct */}
                <a
                  href={`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(
                    'Hello Karimulla garu, I am reaching out to you directly regarding your event and tent services.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-transform hover:scale-[1.02] cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Chat on WhatsApp ({BUSINESS_DETAILS.phone1})</span>
                </a>

              </div>
            </div>

            {/* Right: Vision, Leadership Story, Heritage */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="space-y-2">
                <span className="text-xs uppercase tracking-widest text-[#E5C158] font-bold block">
                  Director&apos;s Message & Heritage
                </span>
                <h2 className="font-telugu text-2xl sm:text-4xl font-bold text-white leading-snug">
                  22+ సంవత్సరాల నిబద్ధత, నాణ్యత మరియు నమ్మకం
                </h2>
                <p className="text-xs sm:text-sm text-neutral-300 font-sans">
                  Serving Guntur, Vijayawada, Mangalagiri, Tenali & Coastal Andhra Since 2002
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <p className="font-telugu text-base sm:text-lg text-[#F3DE8A] leading-relaxed">
                  &ldquo;మా వద్దకు వచ్చిన ప్రతి కస్టమర్‌కు నాణ్యమైన టెంట్లు, కుర్చీలు, శుభ్రమైన వంటసామానులు, మరియు సకాలంలో సర్వీస్ అందించడమే మా ప్రథమ కర్తవ్యం. ఏ ఫంక్షన్ అయినా నమ్మకంగా మమ్మల్ని సంప్రదించగలరు.&rdquo;
                </p>
                <span className="text-xs text-neutral-300 block font-sans">
                  — <strong>{BUSINESS_DETAILS.ownerEnglish}</strong> (Founder & Director)
                </span>
              </div>

              <p className="text-sm text-neutral-200 leading-relaxed font-sans">
                Started with a vision to provide world-class event infrastructure to families, institutions, and religious organizations in Guntur, <strong>Prop. Shaik Karimulla (Babu)</strong> has guided Karimulla Tent House into the most reputed event rental house in the region. Every project, from a home birthday gathering to a 5,000-guest royal wedding pandal, receives personal supervision and direct oversight.
              </p>

              {/* 4 Leadership Pillars */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2 text-xs">
                <div className="p-3.5 rounded-xl bg-white/10 border border-white/10 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#E5C158] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Direct Personal Supervision</strong>
                    <span className="text-neutral-300">You talk directly with Karimulla garu for pricing and setup.</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/10 border border-white/10 flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-[#E5C158] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Sanitized & Clean Inventory</strong>
                    <span className="text-neutral-300">Utensils, stainless steel dabbalu, and chairs steam-cleaned.</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/10 border border-white/10 flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-[#E5C158] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Zero-Delay Punctuality</strong>
                    <span className="text-neutral-300">Setup ready at least 6 hours prior to auspicious muhurtham.</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/10 border border-white/10 flex items-start gap-2.5">
                  <HeartHandshake className="w-4 h-4 text-[#E5C158] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Honest Fair Pricing</strong>
                    <span className="text-neutral-300">No hidden fees, transparent terms, and budget packages.</span>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* Heritage & Milestones Numbers */}
      <section className="py-14 bg-white border-b border-amber-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            
            <div className="p-6 rounded-2xl bg-[#FAF7F2] border border-amber-900/10 shadow-xs">
              <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#7A1526] block tabular-nums">
                22+ Years
              </span>
              <span className="text-xs sm:text-sm font-semibold text-neutral-700 mt-1 block">
                Heritage & Trust in Guntur
              </span>
              <span className="text-[11px] text-neutral-500">Established in 2002</span>
            </div>

            <div className="p-6 rounded-2xl bg-[#FAF7F2] border border-amber-900/10 shadow-xs">
              <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#7A1526] block tabular-nums">
                3,850+
              </span>
              <span className="text-xs sm:text-sm font-semibold text-neutral-700 mt-1 block">
                Grand Events Completed
              </span>
              <span className="text-[11px] text-neutral-500">Weddings, Receptions & Galas</span>
            </div>

            <div className="p-6 rounded-2xl bg-[#FAF7F2] border border-amber-900/10 shadow-xs">
              <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#7A1526] block tabular-nums">
                14,200+
              </span>
              <span className="text-xs sm:text-sm font-semibold text-neutral-700 mt-1 block">
                Happy Families & Clients
              </span>
              <span className="text-[11px] text-neutral-500">Across Guntur District</span>
            </div>

            <div className="p-6 rounded-2xl bg-[#FAF7F2] border border-amber-900/10 shadow-xs">
              <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#7A1526] block tabular-nums">
                65,000+
              </span>
              <span className="text-xs sm:text-sm font-semibold text-neutral-700 mt-1 block">
                Equipment Inventory Items
              </span>
              <span className="text-[11px] text-neutral-500">Tents, Drums, Stoves, Chairs</span>
            </div>

          </div>
        </div>
      </section>

      {/* Two Ventures Under One Leadership */}
      <section className="py-16 sm:py-20 bg-[#FAF7F2] border-b border-amber-900/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-xs uppercase font-bold tracking-wider text-[#9E1B32]">
              Dual Business Leadership
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#38030B] mt-1">
              Two Premier Ventures Directed by Karimulla Garu
            </h2>
            <p className="text-sm text-neutral-600 mt-2">
              Serving the community with comprehensive event infrastructure and transparent real estate advisory.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Venture 1: Karimulla Tent House */}
            <div className="bg-white rounded-3xl p-7 sm:p-8 border border-amber-900/15 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-[#7A1526]/10 text-[#7A1526] flex items-center justify-center mb-5">
                  <Tent className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold text-[#9E1B32] uppercase tracking-wide">
                  Event Rentals Division
                </span>
                <h3 className="font-telugu text-2xl font-bold text-[#38030B] mt-1">
                  {BUSINESS_DETAILS.nameTelugu}
                </h3>
                <p className="font-sans text-xs text-neutral-500 font-semibold mb-3">
                  {BUSINESS_DETAILS.name}
                </p>
                <p className="font-telugu text-sm text-neutral-700 mb-3">
                  &ldquo;{BUSINESS_DETAILS.taglineTelugu}&rdquo;
                </p>
                <ul className="text-xs text-neutral-600 space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Waterproof German tents, shamianas & Mandaps</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Stainless steel Dabbalu drums (5kg to 70kg)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Commercial gas stoves, burners, benches & chiavari chairs</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={onSwitchToTentHouse}
                className="w-full py-3 px-4 rounded-xl bg-[#7A1526] hover:bg-[#5C0614] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-colors"
              >
                <span>Visit Tent House Catalog & Menu</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Venture 2: Karimulla Real Estate */}
            <div className="bg-white rounded-3xl p-7 sm:p-8 border border-emerald-500/20 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-5">
                  <Building2 className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
                  Property Advisory Division
                </span>
                <h3 className="font-telugu text-2xl font-bold text-slate-900 mt-1">
                  రియల్ ఎస్టేట్ (Karimulla Real Estate)
                </h3>
                <p className="font-sans text-xs text-neutral-500 font-semibold mb-3">
                  Directed by Prop. Shaik Karimulla (Babu) · Phone: 9030 610 877
                </p>
                <p className="font-telugu text-sm text-neutral-700 mb-3">
                  &ldquo;{BUSINESS_DETAILS.realEstateLineTelugu}&rdquo;
                </p>
                <ul className="text-xs text-neutral-600 space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>CRDA & DTCP Approved Open Plots in Amaravathi & Guntur</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Farm lands, commercial NH-16 bits, and luxury duplex villas</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>100% legal title verification, spot registration & free vehicle site visit</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={onSwitchToRealEstate}
                className="w-full py-3 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-colors"
              >
                <span>Visit Karimulla Real Estate Page</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>
      </section>

      {/* Direct Contact Form to Founder */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#2D0208] via-[#38030B] to-[#4A040F] text-white shadow-2xl border border-[#D4AF37]/30">
            <div className="text-center max-w-xl mx-auto mb-8">
              <span className="text-xs uppercase font-bold tracking-widest text-[#E5C158]">
                Direct Communication
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-1">
                Send a Direct Message to Director Karimulla Garu
              </h3>
              <p className="text-xs sm:text-sm text-neutral-300 mt-2">
                Need personal advice on large wedding arrangements or land investment? Send your details and reach out on <strong>{BUSINESS_DETAILS.phone1}</strong>.
              </p>
            </div>

            {formSubmitted && (
              <div className="mb-6 p-4 rounded-xl bg-emerald-900/60 border border-emerald-400 text-white text-xs sm:text-sm flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
                <span>Message prepared! Opening WhatsApp directly to Karimulla garu.</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase mb-1">Your Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Naidu"
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-white/10 border border-white/20 text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#E5C158]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 98480 12345"
                    value={contactForm.phone}
                    onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-white/10 border border-white/20 text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#E5C158]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase mb-1">Purpose of Contact</label>
                  <select
                    value={contactForm.purpose}
                    onChange={(e) => setContactForm({ ...contactForm, purpose: e.target.value })}
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-[#2D0208] border border-white/20 text-white focus:outline-none focus:ring-2 focus:ring-[#E5C158]"
                  >
                    <option value="Grand Wedding / Reception Setup">Grand Wedding / Reception Setup</option>
                    <option value="Waterproof German Tent Inquiry">Waterproof German Tent Inquiry</option>
                    <option value="Catering Utensils & Dabbalu Requirement">Catering Utensils & Dabbalu Requirement</option>
                    <option value="Property / Real Estate Inquiry">Property / Real Estate Inquiry</option>
                    <option value="Direct Consultation with Director">Direct Consultation with Director</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase mb-1">Approximate Event Date</label>
                  <input
                    type="date"
                    value={contactForm.eventDate}
                    onChange={(e) => setContactForm({ ...contactForm, eventDate: e.target.value })}
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-white/10 border border-white/20 text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#E5C158]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase mb-1">Your Requirements / Notes</label>
                <textarea
                  rows={3}
                  placeholder="Share any special event requirements or questions..."
                  value={contactForm.message}
                  onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                  className="w-full px-4 py-2.5 text-sm rounded-xl bg-white/10 border border-white/20 text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#E5C158]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl cursor-pointer transition-all hover:scale-[1.01]"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>Send Direct Inquiry to Director Karimulla on WhatsApp</span>
                <Send className="w-4 h-4 ml-1" />
              </button>
            </form>

          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1C0105] text-neutral-400 py-12 border-t border-white/10 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <p className="text-white font-medium">
              &copy; {new Date().getFullYear()} Karimulla Tent House & Real Estate. All rights reserved.
            </p>
            <p className="text-[11px] text-neutral-500 mt-0.5">
              Director: {BUSINESS_DETAILS.ownerEnglish} · {BUSINESS_DETAILS.addressEnglish}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={onSwitchToTentHouse} className="hover:text-white underline cursor-pointer">
              Home
            </button>
            <span>·</span>
            <button onClick={onSwitchToPartners} className="hover:text-white underline cursor-pointer">
              Partners & Teams
            </button>
            <span>·</span>
            <button onClick={onSwitchToRealEstate} className="hover:text-white underline cursor-pointer">
              Real Estate
            </button>
          </div>
        </div>
      </footer>

      {/* Floating Action on Mobile */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#38030B]/95 backdrop-blur-md border-t border-[#D4AF37]/30 p-2.5 px-4 flex items-center justify-between gap-3 shadow-2xl">
        <a
          href={`tel:+${BUSINESS_DETAILS.phone1Raw}`}
          className="flex-1 py-2.5 px-3 rounded-xl bg-[#D4AF37] text-[#240106] font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>Call: {BUSINESS_DETAILS.phone1}</span>
        </a>

        <a
          href={`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(
            'Hello Karimulla garu, I am contacting you directly regarding event services.'
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-3 rounded-xl bg-[#25D366] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm"
        >
          <MessageCircle className="w-3.5 h-3.5 fill-current" />
          <span>WhatsApp</span>
        </a>
      </div>

    </div>
  );
};
