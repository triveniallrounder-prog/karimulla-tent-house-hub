import React, { useState } from 'react';
import { 
  HelpCircle, 
  ChevronDown, 
  Phone, 
  MessageCircle, 
  ShieldCheck, 
  Clock, 
  CreditCard, 
  Truck, 
  Sparkles,
  Search
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer, MotionFadeUp } from './motion/MotionFade';

interface FaqItem {
  id: string;
  category: 'booking' | 'delivery' | 'equipment' | 'policy';
  icon: React.ElementType;
  qEn: string;
  qTe: string;
  aEn: string;
  aTe: string;
}

const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'delivery-timing',
    category: 'delivery',
    icon: Truck,
    qEn: 'What is your delivery and setup policy? How early do you arrive?',
    qTe: 'డెలివరీ మరియు సెటప్ విధానం ఏమిటి? ఈవెంట్ కంటే ఎంత ముందు వస్తారు?',
    aEn: 'We provide punctual early delivery 12 to 24 hours prior to your event start time. Our dedicated setup crew erects tents, arranges banquet chairs, sets up lighting, and arranges cooking vessels well before guests arrive so you have zero last-minute panic.',
    aTe: 'మేము మీ ఈవెంట్ ప్రారంభానికి 12 నుండి 24 గంటల ముందే అన్ని సామగ్రిని డెలివరీ చేసి సెటప్ చేస్తాము. అతిథులు రాకముందే టెంట్లు, కుర్చీలు, లైటింగ్ మరియు వంట డబ్బాలు శుభ్రంగా అమర్చబడతాయి.',
  },
  {
    id: 'deposit-payment',
    category: 'booking',
    icon: CreditCard,
    qEn: 'How much deposit is required to confirm an event date?',
    qTe: 'బుకింగ్ కన్ఫర్మ్ చేయడానికి ఎంత అడ్వాన్స్ లేదా డిపాజిట్ ఇవ్వాలి?',
    aEn: 'A nominal advance deposit of 20% to 30% is required to lock your event date and reserve the required inventory (tents, dabbalu, chairs). The remaining balance is payable upon delivery and verification on your function day. We accept UPI (PhonePe/GPay), bank transfers, and cash.',
    aTe: 'మీ తేదీ మరియు సామగ్రిని రిజర్వ్ చేయడానికి 20% నుండి 30% వరకు అడ్వాన్స్ డిపాజిట్ అవసరం. మిగిలిన మొత్తం ఈవెంట్ రోజున డెలివరీ తనిఖీ తర్వాత చెల్లించవచ్చు. ఫోన్‌పే, జీపే, బ్యాంక్ బదిలీ లేదా నగదు స్వీకరించబడుతుంది.',
  },
  {
    id: 'cancellation-policy',
    category: 'policy',
    icon: Clock,
    qEn: 'What is your cancellation and date postponement policy?',
    qTe: 'క్యాన్సిలేషన్ మరియు తేదీ మార్పు (పోస్ట్‌పోన్) విధానం ఏమిటి?',
    aEn: 'We understand that family events and weather conditions can change. If you inform us at least 5 to 7 days before the event, 100% of your deposit is credited towards any future rescheduled date within 6 months. For unforeseen medical or rain emergencies, we offer maximum flexibility.',
    aTe: 'ఈవెంట్ తేదీకి 5 నుండి 7 రోజుల ముందు తెలియజేస్తే, మీరు చెల్లించిన అడ్వాన్స్ డిపాజిట్ మొత్తాన్ని రాబోయే 6 నెలల్లోపు ఏ ఇతర తేదీకైనా 100% సర్దుబాటు చేస్తాము.',
  },
  {
    id: 'waterproof-tents',
    category: 'equipment',
    icon: ShieldCheck,
    qEn: 'Are your tents genuinely waterproof during sudden rain storms?',
    qTe: 'వర్షం పడితే టెంట్లు నిజంగా వాటర్‌ప్రూఫ్‌గా ఉంటాయా?',
    aEn: 'Yes! We stock heavy-duty German aluminum hangar tents and industrial-grade multi-layer PVC waterproof shamianas. They feature sealed seams and sloped drainage channels designed specifically to withstand sudden downpours and strong winds, keeping dining and stage areas dry.',
    aTe: 'అవును! మా వద్ద జర్మన్ టెక్నాలజీ వాటర్‌ప్రూఫ్ పీవీసీ టెంట్లు మరియు రెయిన్‌ప్రూఫ్ షామియానాలు అందుబాటులో ఉన్నాయి. వర్షం లేదా గాలి తుఫాను వచ్చినా వేదిక మరియు భోజనాల ప్రాంతంలోకి నీరు రాకుండా రక్షణ కల్పిస్తాయి.',
  },
  {
    id: 'utensils-dabbalu',
    category: 'equipment',
    icon: Sparkles,
    qEn: 'What cooking vessel sizes and Dabbalu capacities do you provide?',
    qTe: 'వంట డబ్బాలు మరియు పాత్రలు ఎన్ని సైజుల్లో లభిస్తాయి? ఎంతమందికి సరిపోతాయి?',
    aEn: 'We have 10 standard sizes of heavy stainless steel Dabbalu (from size #1 up to #10), large biryani handis, milk boilers, curry cauldrons, and high-pressure gas bhattis. We can easily cater for small gatherings of 50 people up to mega wedding feasts of 3,000+ guests. All vessels are steam-sanitized prior to delivery.',
    aTe: 'మా వద్ద 1 నుండి 10 నంబర్ల వరకు స్టెయిన్‌లెస్ స్టీల్ డబ్బాలు, బిర్యానీ హండీలు, గ్యాస్ భట్టీలు ఉన్నాయి. 50 మంది నుండి 3,000+ మంది అతిథులకు సరిపడా వంట పాత్రలను శుభ్రంగా కడిగి అందిస్తాము.',
  },
  {
    id: 'damage-policy',
    category: 'policy',
    icon: HelpCircle,
    qEn: 'What happens in case of accidental damage or missing items?',
    qTe: 'ఈవెంట్‌లో ఏవైనా కుర్చీలు లేదా వస్తువులు దెబ్బతింటే లేదా పోతే పరిస్థితి ఏమిటి?',
    aEn: 'Normal wear-and-tear or minor stains on linens are never penalized. In the rare event of lost stainless steel vessels or broken chairs, we settle with a friendly, direct conversation at nominal wholesale replacement cost with zero unreasonable penalties.',
    aTe: 'సాధారణ వినియోగంలో జరిగే చిన్నపాటి సమస్యలకు ఎటువంటి రుసుము ఉండదు. ఏదైనా వస్తువు పోయినట్లయితే హోల్‌సేల్ ధరకు మాత్రమే స్నేహపూర్వకంగా పరిష్కరించుకుంటాము.',
  },
  {
    id: 'service-radius',
    category: 'delivery',
    icon: Truck,
    qEn: 'Which locations do you service and do you provide setup labor?',
    qTe: 'మీరు ఏ ప్రాంతాలలో సేవలు అందిస్తారు? సెటప్ సిబ్బంది ఉంటారా?',
    aEn: 'We service the entire town, surrounding mandals, and neighboring villages within a 60km radius. Dedicated loading, unloading, tent erection, and teardown labor are fully handled by our experienced crew so hosts can enjoy their function.',
    aTe: 'పట్టణంతో పాటు చుట్టుపక్కల 60 కి.మీ పరిధిలోని గ్రామాలు మరియు మండలాలకు మేము రవాణా మరియు పూర్తి సెటప్ సిబ్బందితో సేవలను అందిస్తాము.',
  },
];

export const FaqSection: React.FC = () => {
  const { isTelugu } = useLanguage();
  const [openId, setOpenId] = useState<string | null>('delivery-timing');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const toggleItem = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  const filteredFaqs = FAQ_ITEMS.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesCategory;

    const matchesSearch = 
      item.qEn.toLowerCase().includes(query) ||
      item.aEn.toLowerCase().includes(query) ||
      item.qTe.toLowerCase().includes(query) ||
      item.aTe.toLowerCase().includes(query);

    return matchesCategory && matchesSearch;
  });

  return (
    <section 
      id="faq" 
      className="py-16 sm:py-24 bg-white dark:bg-[#150205] border-t border-amber-900/10 dark:border-[#D4AF37]/20 transition-colors duration-300 scroll-mt-16"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <MotionHeading className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-50 dark:bg-[#38030B] border border-amber-200 dark:border-[#D4AF37]/30 text-[#7A1526] dark:text-[#F3DE8A] text-xs font-bold uppercase tracking-wider mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-[#B8860B] dark:text-[#E5C158]" />
            <span>{isTelugu ? 'సాధారణ ప్రశ్నలు & సమాధానాలు' : 'Frequently Asked Questions'}</span>
          </div>

          <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#38030B] dark:text-white leading-tight">
            {isTelugu ? (
              <>ఈవెంట్ అద్దె <span className="text-[#9E1B32] dark:text-[#F3DE8A]">విధానాలు & సందేహాలు</span></>
            ) : (
              <>Common Event Rental <span className="text-[#9E1B32] dark:text-[#F3DE8A]">Questions & Policies</span></>
            )}
          </h2>

          <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 font-sans mt-2">
            {isTelugu 
              ? 'డెలివరీ సమయం, డిపాజిట్, క్యాన్సిలేషన్ మరియు వంట డబ్బాల గురించిన పూర్తి వివరాలు.'
              : 'Clear, transparent answers about delivery timings, booking deposits, cancellation flexibility, and tent specifications.'}
          </p>
        </MotionHeading>

        {/* Filter Chips & Search Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-8">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 p-1 rounded-xl bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 text-xs">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeCategory === 'all'
                  ? 'bg-white dark:bg-[#7A1526] text-[#7A1526] dark:text-white font-bold shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              {isTelugu ? 'అన్నీ (All)' : 'All Questions'}
            </button>
            <button
              onClick={() => setActiveCategory('delivery')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeCategory === 'delivery'
                  ? 'bg-white dark:bg-[#7A1526] text-[#7A1526] dark:text-white font-bold shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              {isTelugu ? 'డెలివరీ & సమయం' : 'Delivery & Setup'}
            </button>
            <button
              onClick={() => setActiveCategory('booking')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeCategory === 'booking'
                  ? 'bg-white dark:bg-[#7A1526] text-[#7A1526] dark:text-white font-bold shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              {isTelugu ? 'డిపాజిట్ & పేమెంట్స్' : 'Deposit & Payments'}
            </button>
            <button
              onClick={() => setActiveCategory('policy')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeCategory === 'policy'
                  ? 'bg-white dark:bg-[#7A1526] text-[#7A1526] dark:text-white font-bold shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              {isTelugu ? 'క్యాన్సిలేషన్ నిబంధనలు' : 'Cancellation & Policy'}
            </button>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isTelugu ? 'ప్రశ్నలలో వెతకండి...' : 'Search questions...'}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-neutral-50 dark:bg-white/5 border border-neutral-200 dark:border-white/10 text-neutral-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
          </div>
        </div>

        {/* Collapsible Accordion List */}
        <MotionContainer delay={0.15} className="space-y-3.5">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            const Icon = faq.icon;

            return (
              <div
                key={faq.id}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-amber-50/40 dark:bg-[#200408] border-[#D4AF37]/50 shadow-md ring-1 ring-[#D4AF37]/30'
                    : 'bg-white dark:bg-[#1A0206] border-neutral-200 dark:border-white/10 hover:border-amber-900/20 dark:hover:border-white/20'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleItem(faq.id)}
                  aria-expanded={isOpen}
                  className="w-full py-4 px-5 sm:px-6 flex items-center justify-between gap-4 text-left cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                      isOpen 
                        ? 'bg-[#7A1526] text-[#F3DE8A]' 
                        : 'bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-300'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-serif text-sm sm:text-base font-bold text-[#38030B] dark:text-white leading-snug">
                      {isTelugu ? faq.qTe : faq.qEn}
                    </span>
                  </div>

                  <div className={`p-1 rounded-full shrink-0 transition-transform duration-300 ${
                    isOpen ? 'rotate-180 bg-[#D4AF37]/20 text-[#D4AF37]' : 'text-neutral-400'
                  }`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 border-t border-amber-900/10 dark:border-white/5 animate-in fade-in duration-200">
                    <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-200 leading-relaxed font-sans">
                      {isTelugu ? faq.aTe : faq.aEn}
                    </p>
                    
                    {/* Quick Callout in response */}
                    <div className="mt-3 flex items-center gap-2 text-[11px] text-amber-800 dark:text-[#F3DE8A] font-medium">
                      <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                      <span>{isTelugu ? 'కరీముల్లా టెంట్ హౌస్ ప్రత్యక్ష హామీ' : 'Backed by Karimulla Tent House 22-year personal service guarantee'}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {filteredFaqs.length === 0 && (
            <div className="p-8 text-center bg-neutral-50 dark:bg-white/5 rounded-2xl border border-neutral-200 dark:border-white/10 text-neutral-500">
              <p className="text-sm">No matching questions found.</p>
              <button
                onClick={() => { setSearchQuery(''); setActiveCategory('all'); }}
                className="mt-2 text-xs text-[#7A1526] dark:text-[#F3DE8A] font-bold underline"
              >
                Clear search & filters
              </button>
            </div>
          )}
        </MotionContainer>

        {/* Bottom Help Banner */}
        <MotionFadeUp delay={0.2} className="mt-10 p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-[#38030B] via-[#4A040F] to-[#2D0208] text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg border border-[#D4AF37]/30">
          <div className="text-center sm:text-left">
            <h4 className="font-serif font-bold text-base sm:text-lg text-white">
              {isTelugu ? 'మీ ఈవెంట్‌కు సంబంధించిన ప్రత్యేక ప్రశ్న ఉందా?' : 'Have a custom setup or specific rental query?'}
            </h4>
            <p className="text-xs text-neutral-300 mt-0.5">
              {isTelugu 
                ? 'నేరుగా కరీముల్లా గారికి కాల్ చేసి లేదా వాట్సాప్‌లో మాట్లాడండి.'
                : 'Speak directly with Founder Karimulla garu for custom tent dimensions and bulk pricing.'}
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href={`tel:+${BUSINESS_DETAILS.phone1Raw}`}
              className="px-4 py-2 rounded-xl bg-[#D4AF37] hover:bg-[#E5C158] text-[#240106] font-bold text-xs flex items-center gap-1.5 shadow-sm transition-transform hover:scale-105"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Now</span>
            </a>
            <a
              href={`https://wa.me/${BUSINESS_DETAILS.phone1Raw}?text=${encodeURIComponent(
                'Hello Karimulla garu, I have a question about event rentals and tent setup.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-transform hover:scale-105"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>WhatsApp</span>
            </a>
          </div>
        </MotionFadeUp>

      </div>
    </section>
  );
};

export default FaqSection;
