import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, 
  Phone, 
  MessageCircle, 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Pause, 
  Sparkles, 
  User, 
  CheckCircle2, 
  ArrowRight,
  Flower2,
  Zap,
  Tent,
  UtensilsCrossed,
  Truck
} from 'lucide-react';
import { SPECIFIC_TEAMS_DATA, TeamMember } from '../data/partnersTeamData';
import { useLanguage } from '../context/LanguageContext';

interface TeamMembersAnimatedScrollProps {
  onSwitchToPartners?: () => void;
  title?: string;
  subtitle?: string;
}

export const TeamMembersAnimatedScroll: React.FC<TeamMembersAnimatedScrollProps> = ({
  onSwitchToPartners,
  title,
  subtitle,
}) => {
  const { isTelugu } = useLanguage();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeTeamFilter, setActiveTeamFilter] = useState<string>('all');
  const [isHovered, setIsHovered] = useState(false);

  // Flatten all members with their team info
  const allMembersWithTeam = React.useMemo(() => {
    const list: Array<TeamMember & { teamName: string; teamTelugu: string; teamId: string }> = [];
    SPECIFIC_TEAMS_DATA.forEach((team) => {
      team.members.forEach((m) => {
        list.push({
          ...m,
          teamName: team.name,
          teamTelugu: team.teluguName,
          teamId: team.id,
        });
      });
    });
    return list;
  }, []);

  const displayedMembers = React.useMemo(() => {
    if (activeTeamFilter === 'all') return allMembersWithTeam;
    return allMembersWithTeam.filter((m) => m.teamId === activeTeamFilter);
  }, [allMembersWithTeam, activeTeamFilter]);

  // Automated side-by-side scrolling animation
  useEffect(() => {
    if (!isPlaying || isHovered) return;

    const interval = setInterval(() => {
      const container = scrollRef.current;
      if (!container) return;

      const maxScroll = container.scrollWidth - container.clientWidth;
      if (container.scrollLeft >= maxScroll - 5) {
        // Smooth reset to start
        container.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        container.scrollBy({ left: 280, behavior: 'smooth' });
      }
    }, 3200);

    return () => clearInterval(interval);
  }, [isPlaying, isHovered]);

  const handleManualScroll = (direction: 'left' | 'right') => {
    const container = scrollRef.current;
    if (!container) return;
    const scrollAmount = direction === 'left' ? -300 : 300;
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  };

  const getTeamIcon = (teamId: string) => {
    switch (teamId) {
      case 'team-decoration':
        return <Flower2 className="w-3.5 h-3.5 text-pink-500" />;
      case 'team-lighting':
        return <Zap className="w-3.5 h-3.5 text-amber-500" />;
      case 'team-tents':
        return <Tent className="w-3.5 h-3.5 text-blue-500" />;
      case 'team-utensils':
        return <UtensilsCrossed className="w-3.5 h-3.5 text-red-500" />;
      case 'team-logistics':
        return <Truck className="w-3.5 h-3.5 text-emerald-500" />;
      default:
        return <Users className="w-3.5 h-3.5 text-[#E5C158]" />;
    }
  };

  return (
    <section className="py-16 sm:py-20 bg-[#FAF7F2] border-b border-amber-900/10 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#7A1526]/10 text-[#7A1526] text-xs font-semibold uppercase tracking-wider mb-2.5">
              <Sparkles className="w-3.5 h-3.5 text-[#7A1526]" />
              <span>{isTelugu ? 'ప్రత్యేక బృందాల సభ్యులు' : 'Animated Specialist Crew Showcase'}</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-[#38030B] tracking-tight">
              {title || (isTelugu ? 'మా నైపుణ్యం కలిగిన బృంద సభ్యులు' : 'Our Team Members (Scrolling Side-by-Side)')}
            </h2>
            <p className="text-xs sm:text-sm text-neutral-600 mt-1 max-w-xl">
              {subtitle || (isTelugu 
                ? 'డెకరేషన్, లైటింగ్, టెంట్ రిగ్గింగ్, వంట పాత్రలు మరియు రవాణా విభాగాలలో అనుభవజ్ఞులైన కళాకారులు.'
                : 'Meet our master stage mandap architects, electrical riggers, pandal fitters, and logistics fleet operators animated side-by-side.')}
            </p>
          </div>

          {/* Controls: Play/Pause + Left/Right arrows + View All Page 3 Link */}
          <div className="flex items-center gap-2 self-start md:self-end shrink-0">
            {/* Play/Pause Animation Toggle */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                isPlaying 
                  ? 'bg-amber-50 text-amber-900 border-amber-300' 
                  : 'bg-white text-neutral-600 border-neutral-200'
              }`}
              title={isPlaying ? "Pause side-by-side animation" : "Resume side-by-side animation"}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{isPlaying ? 'Auto-Scroll ON' : 'Paused'}</span>
            </button>

            {/* Left Scroll Button */}
            <button
              onClick={() => handleManualScroll('left')}
              className="p-2 rounded-xl bg-white hover:bg-neutral-100 text-[#38030B] border border-amber-900/15 shadow-xs transition-colors cursor-pointer"
              aria-label="Scroll left side-by-side"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Right Scroll Button */}
            <button
              onClick={() => handleManualScroll('right')}
              className="p-2 rounded-xl bg-white hover:bg-neutral-100 text-[#38030B] border border-amber-900/15 shadow-xs transition-colors cursor-pointer"
              aria-label="Scroll right side-by-side"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {onSwitchToPartners && (
              <button
                onClick={onSwitchToPartners}
                className="hidden lg:flex items-center gap-1 px-3.5 py-2 rounded-xl bg-[#7A1526] hover:bg-[#5C0614] text-white text-xs font-bold shadow-xs transition-transform active:scale-95 cursor-pointer ml-1"
              >
                <span>3rd Page: All Teams →</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-3 mb-6">
          <button
            onClick={() => setActiveTeamFilter('all')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              activeTeamFilter === 'all'
                ? 'bg-[#7A1526] text-white shadow-xs'
                : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200'
            }`}
          >
            All Members ({allMembersWithTeam.length})
          </button>
          {SPECIFIC_TEAMS_DATA.map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTeamFilter(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                activeTeamFilter === t.id
                  ? 'bg-[#7A1526] text-white shadow-xs'
                  : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200'
              }`}
            >
              {getTeamIcon(t.id)}
              <span>{isTelugu ? t.teluguName : t.name}</span>
            </button>
          ))}
        </div>

        {/* SIDE-BY-SIDE ANIMATED SCROLLING CONTAINER */}
        <div
          ref={scrollRef}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          onTouchStart={() => setIsHovered(true)}
          onTouchEnd={() => setIsHovered(false)}
          className="flex gap-4 sm:gap-6 overflow-x-auto scroll-smooth no-scrollbar py-2 px-1 focus:outline-none"
          tabIndex={0}
          aria-label="Side-by-side animated team members list"
        >
          {displayedMembers.map((member) => (
            <div
              key={member.id}
              className="min-w-[260px] sm:min-w-[280px] max-w-[280px] shrink-0 bg-white rounded-2xl p-4 sm:p-5 border border-amber-900/15 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between group"
            >
              <div>
                {/* Photo Upload Slot or Profile Visual */}
                <div className="relative h-36 w-full rounded-xl bg-gradient-to-br from-amber-100/60 to-stone-100 border border-dashed border-amber-300 flex flex-col items-center justify-center p-3 text-center mb-3.5 overflow-hidden group-hover:border-[#D4AF37] transition-colors">
                  {member.photo ? (
                    <img
                      src={member.photo}
                      alt={member.name}
                      className="w-full h-full object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-neutral-400 group-hover:text-[#7A1526] transition-colors">
                      <div className="w-11 h-11 rounded-full bg-white/80 border border-amber-200 flex items-center justify-center mb-1 shadow-2xs group-hover:scale-110 transition-transform">
                        <User className="w-6 h-6 text-amber-800/70" />
                      </div>
                      <span className="text-[10px] font-sans font-semibold text-neutral-500">
                        Photo Upload Slot
                      </span>
                    </div>
                  )}

                  {/* Experience Badge */}
                  <div className="absolute top-2 right-2 bg-black/75 text-[#F3DE8A] text-[9px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                    {member.experience}
                  </div>

                  {/* Team Tag */}
                  <div className="absolute bottom-2 left-2 bg-white/95 text-[#38030B] text-[9px] font-bold px-2 py-0.5 rounded-md shadow-2xs border border-amber-900/10 flex items-center gap-1">
                    {getTeamIcon(member.teamId)}
                    <span className="truncate max-w-[140px]">{member.teamName}</span>
                  </div>
                </div>

                {/* Name in Telugu & English */}
                <h4 className="font-telugu text-base sm:text-lg font-bold text-[#38030B] group-hover:text-[#7A1526] transition-colors leading-tight">
                  {isTelugu && member.teluguName ? member.teluguName : member.name}
                </h4>
                <p className="text-xs font-sans font-semibold text-neutral-600 mt-0.5">
                  {member.name}
                </p>

                {/* Role Badge */}
                <div className="mt-1.5">
                  <span className="inline-block text-[10px] font-semibold text-[#7A1526] bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/60 leading-tight">
                    {isTelugu && member.roleTelugu ? member.roleTelugu : member.role}
                  </span>
                </div>

                {/* Speciality */}
                <p className="text-[11px] text-neutral-500 mt-2.5 leading-relaxed line-clamp-2">
                  Speciality: <strong className="text-neutral-700">{member.speciality}</strong>
                </p>
              </div>

              {/* Contact Actions */}
              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center gap-2">
                <a
                  href={`tel:+${member.phoneRaw}`}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                  title={`Call ${member.name}`}
                >
                  <Phone className="w-3 h-3 text-[#7A1526]" />
                  <span>{member.phone}</span>
                </a>

                <a
                  href={`https://wa.me/${member.phoneRaw}?text=${encodeURIComponent(`Hello ${member.name}, I would like to inquire about your event ${member.role} services through Karimulla Tent House.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors"
                  title="WhatsApp"
                >
                  <MessageCircle className="w-3.5 h-3.5 fill-current" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom helper text */}
        <div className="mt-4 flex items-center justify-between text-[11px] text-neutral-500">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Smooth side-by-side animated scroll · Hover/touch card to pause</span>
          </span>
          {onSwitchToPartners && (
            <button
              onClick={onSwitchToPartners}
              className="text-[#7A1526] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>Explore all in-house team divisions</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>

      </div>
    </section>
  );
};
