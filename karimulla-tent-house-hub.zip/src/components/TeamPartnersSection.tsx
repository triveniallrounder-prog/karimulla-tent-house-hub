import React, { useState, useMemo } from 'react';
import { Phone, Users, ShieldCheck, HeartHandshake } from 'lucide-react';
import { teamProfiles, TeamProfile } from '../data/team';
import { useLanguage } from '../context/LanguageContext';
import { useSiteData } from '../context/SiteDataContext';
import { motion } from 'framer-motion';
import { MotionHeading, MotionContainer, MotionFadeUp } from './motion/MotionFade';

export const TeamPartnersSection: React.FC = () => {
  const { isTelugu } = useLanguage();
  const { siteData } = useSiteData();
  const [isPaused, setIsPaused] = useState(false);

  const partnership = siteData?.partnership;

  // Combine teammates and partners from siteData, or fallback to teamProfiles
  const combinedProfiles = useMemo(() => {
    const list: Array<{
      name: string;
      brand: string;
      role: string;
      phone: string;
      photo?: string;
      details?: string;
    }> = [];

    if (siteData?.team && siteData.team.length > 0) {
      siteData.team.forEach((t) => {
        list.push({
          name: t.name,
          brand: t.role || 'Core Team',
          role: t.role || 'Team Member',
          phone: t.phone || '00000 00000',
          photo: t.photo || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
          details: t.details,
        });
      });
    }

    if (siteData?.partners && siteData.partners.length > 0) {
      siteData.partners.forEach((p) => {
        list.push({
          name: p.name,
          brand: p.brand || p.name || 'Partner',
          role: p.role || 'Partner',
          phone: p.phone || '00000 00000',
          photo: p.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
          details: p.details,
        });
      });
    }

    if (list.length > 0) {
      return list;
    }
    return teamProfiles;
  }, [siteData?.team, siteData?.partners]);

  // We duplicate the list so that translation -50% produces a perfectly seamless loop
  const duplicatedProfiles = [...combinedProfiles, ...combinedProfiles];

  const sectionHeading = isTelugu
    ? (partnership?.headingTelugu || 'మీ ఈవెంట్‌ని పరిపూర్ణం చేసే విశ్వసనీయ భాగస్వాములు')
    : (partnership?.heading || 'Meet Our Dedicated Team & Partners');

  const sectionDesc = isTelugu
    ? (partnership?.descriptionTelugu || 'కార్యక్రమ నిర్వహణలో అనుభవజ్ఞులైన నిపుణులు, క్యాటరింగ్, లైటింగ్, డెకరేషన్ బృందం వివరాలు మరియు ఫోన్ నంబర్లు.')
    : (partnership?.description || 'Collaborating professionals ensuring flawless setups, catering logistics, shamianas, and decor services.');

  return (
    <section 
      id="team" 
      className="py-16 sm:py-24 bg-gradient-to-b from-[#FCF9F5] via-amber-50/40 to-[#FCF9F5] dark:from-[#120104] dark:via-[#1c0207] dark:to-[#120104] border-t border-b border-amber-900/10 dark:border-[#D4AF37]/20 relative overflow-hidden transition-colors duration-300 scroll-mt-16"
    >
      {/* Decorative background glows */}
      <div 
        aria-hidden="true" 
        className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-amber-400/10 dark:bg-amber-500/5 rounded-full blur-3xl pointer-events-none" 
      />
      <div 
        aria-hidden="true" 
        className="absolute top-1/2 right-1/4 -translate-y-1/2 w-96 h-96 bg-rose-500/5 rounded-full blur-3xl pointer-events-none" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10 sm:mb-14">
        {/* Section Heading with MotionFade */}
        <MotionHeading className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-100 to-amber-200/80 dark:from-[#38030B] dark:to-[#5C0614] border border-[#D4AF37]/40 text-[#7A1526] dark:text-[#F3DE8A] text-xs font-bold uppercase tracking-wider shadow-xs">
            <Users className="w-3.5 h-3.5 text-[#B8860B] dark:text-[#E5C158]" />
            <span>{isTelugu ? 'మా బృందం & విశ్వసనీయ భాగస్వాములు' : 'Our Team & Trusted Partners'}</span>
          </div>

          <h2 className="font-serif text-2xl sm:text-4xl lg:text-4xl font-bold text-[#38030B] dark:text-white tracking-tight leading-snug">
            {sectionHeading}
          </h2>

          <p className="text-sm sm:text-base text-neutral-600 dark:text-neutral-300 font-sans max-w-2xl mx-auto">
            {sectionDesc}
          </p>

          <p className="text-[11px] sm:text-xs text-neutral-400 dark:text-neutral-500 italic">
            {isTelugu
              ? '(హోవర్ లేదా టచ్ చేయడం ద్వారా స్క్రోల్‌ను పాజ్ చేయవచ్చు)'
              : '(Hover over or touch any card to pause scrolling • Tap phone to call directly)'}
          </p>
        </MotionHeading>
      </div>

      {/* Marquee Container with MotionFadeUp */}
      <MotionFadeUp delay={0.2} className="relative w-full overflow-hidden">
        {/* Left Fade Edge */}
        <div 
          aria-hidden="true"
          className="absolute left-0 top-0 bottom-0 w-12 sm:w-28 z-20 pointer-events-none bg-gradient-to-r from-[#FCF9F5] via-[#FCF9F5]/90 to-transparent dark:from-[#120104] dark:via-[#120104]/90 dark:to-transparent"
        />

        {/* Right Fade Edge */}
        <div 
          aria-hidden="true"
          className="absolute right-0 top-0 bottom-0 w-12 sm:w-28 z-20 pointer-events-none bg-gradient-to-l from-[#FCF9F5] via-[#FCF9F5]/90 to-transparent dark:from-[#120104] dark:via-[#120104]/90 dark:to-transparent"
        />

        {/* Scrolling Strip */}
        <div
          className={`flex gap-5 sm:gap-6 py-4 px-4 ${isPaused ? 'is-paused' : ''} animate-marquee-slow`}
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {duplicatedProfiles.map((profile: any, index: number) => {
            const cleanPhone = profile.phone.replace(/[^0-9]/g, '');
            const isClickablePhone = cleanPhone && cleanPhone !== '0000000000';

            return (
              <div
                key={`${profile.name}-${index}`}
                className="w-64 sm:w-72 shrink-0 bg-white dark:bg-[#1E0308] rounded-2xl p-5 sm:p-6 border border-amber-900/15 dark:border-[#D4AF37]/30 shadow-md card-premium-hover flex flex-col items-center text-center group select-none relative"
              >
                {/* 1. TOP: Partner's BRAND NAME in highlighted badge/ribbon (accent color, bold) + CONTACT NUMBER tap-to-call link */}
                <div className="w-full mb-5 pb-3.5 border-b border-amber-900/10 dark:border-[#D4AF37]/20 flex flex-col items-center">
                  {/* Brand Ribbon Badge */}
                  <div className="w-full py-1.5 px-3 rounded-xl bg-gradient-to-r from-[#7A1526] via-[#9E1B32] to-[#7A1526] text-white shadow-md mb-2 group-hover:from-[#9E1B32] group-hover:to-[#5C0614] transition-colors">
                    <span className="font-serif font-bold text-sm sm:text-base tracking-wide uppercase text-[#F3DE8A] drop-shadow-xs">
                      {profile.brand}
                    </span>
                  </div>

                  {/* Contact Number as Tap-To-Call Link (tel:) - MOST NOTICEABLE PART */}
                  <a
                    href={isClickablePhone ? `tel:${cleanPhone}` : '#'}
                    onClick={(e) => {
                      if (!isClickablePhone) {
                        e.preventDefault();
                      }
                    }}
                    className={`inline-flex items-center justify-center gap-1.5 py-1 px-3 rounded-lg text-xs sm:text-sm font-mono font-bold transition-all ${
                      isClickablePhone
                        ? 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-600/50 hover:bg-emerald-600 hover:text-white dark:hover:bg-emerald-600'
                        : 'bg-neutral-100 dark:bg-white/10 text-neutral-600 dark:text-neutral-300 border border-neutral-200 dark:border-white/10 cursor-default'
                    }`}
                    title={isClickablePhone ? `Tap to call ${profile.name} (${profile.brand})` : 'Contact number'}
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 group-hover:rotate-12 transition-transform" />
                    <span className="tabular-nums tracking-wide">{profile.phone}</span>
                  </a>
                </div>

                {/* 2. Profile picture, round or rounded square, with a gold border */}
                <div className="relative mb-3.5">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden ring-4 ring-[#D4AF37] dark:ring-[#E5C158] border-2 border-white dark:border-[#2D0208] shadow-lg group-hover:scale-105 transition-transform duration-300 bg-amber-50 dark:bg-neutral-800">
                    <img
                      src={profile.photo}
                      alt={profile.name}
                      onError={(e) => {
                        // Fallback placeholder image if URL fails
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80';
                      }}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-[#D4AF37] text-[#240106] shadow-sm">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* 3. Name below the picture */}
                <h3 className="font-serif text-lg sm:text-xl font-bold text-[#38030B] dark:text-white group-hover:text-[#9E1B32] dark:group-hover:text-[#F3DE8A] transition-colors leading-tight">
                  {profile.name}
                </h3>

                {/* 4. Small role tag (Partner or Team Member) */}
                <div className="mt-2">
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                      profile.role.toLowerCase().includes('partner')
                        ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 border-amber-300 dark:border-amber-700/60'
                        : 'bg-rose-50 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200 border-rose-200 dark:border-rose-800/60'
                    }`}
                  >
                    <HeartHandshake className="w-3 h-3" />
                    <span>{profile.role}</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </MotionFadeUp>
    </section>
  );
};

export default TeamPartnersSection;
