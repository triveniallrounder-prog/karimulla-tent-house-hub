import React, { useState, useMemo } from 'react';
import { itemsData } from '../data/items.js';
import { 
  Plus, 
  Check, 
  ShoppingBag, 
  ArrowDown, 
  Sparkles, 
  Image as ImageIcon, 
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'framer-motion';
import { useSiteData } from '../context/SiteDataContext';

interface ItemsMenuSectionProps {
  onAddToBasket?: (item: any) => void;
  onOpenBasket?: () => void;
}

export const ItemsMenuSection: React.FC<ItemsMenuSectionProps> = ({
  onAddToBasket,
  onOpenBasket,
}) => {
  const { isTelugu } = useLanguage();
  const { siteData } = useSiteData();
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const [addedItemKey, setAddedItemKey] = useState<string | null>(null);

  const visibleItems = useMemo(() => {
    if (siteData && siteData.items && siteData.items.length > 0) {
      return siteData.items.filter((item) => item.visible !== false);
    }
    return itemsData.mainItems;
  }, [siteData]);

  const scrollToDetails = (targetId: string) => {
    setActiveItem(targetId);
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      const bottomSection = document.getElementById('item-details-section');
      if (bottomSection) {
        bottomSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleAddToCart = (item: {
    id: string;
    telugu: string;
    english: string;
    category?: string;
    selectedSize?: string;
  }) => {
    const key = item.selectedSize ? `${item.id}-${item.selectedSize}` : item.id;
    
    if (onAddToBasket) {
      onAddToBasket({
        id: key,
        name: `${item.telugu} ${item.english}`,
        teluguName: item.telugu,
        category: item.category || 'Rental Item',
        pricePerDay: 0,
        unit: 'per day',
        selectedSize: item.selectedSize || '',
      });
    }

    setAddedItemKey(key);
    setTimeout(() => {
      setAddedItemKey((prev) => (prev === key ? null : prev));
    }, 2000);
  };

  return (
    <section id="items-menu" className="py-20 sm:py-24 bg-[#FAF7F2] dark:bg-[#150205] border-b border-amber-900/10 dark:border-[#D4AF37]/20 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="text-center max-w-3xl mx-auto mb-12 sm:mb-16"
        >
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#7A1526]/10 dark:bg-[#D4AF37]/20 text-[#7A1526] dark:text-[#F3DE8A] text-xs font-semibold uppercase tracking-wider mb-3 border border-[#7A1526]/20 dark:border-[#D4AF37]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#9E1B32] dark:text-[#E5C158]" />
            <span className="font-telugu">సామాగ్రి జాబితా</span>
            <span>·</span>
            <span>Items Menu</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] dark:text-white tracking-tight">
            {isTelugu ? 'కరీముల్లా టెంట్ హౌస్ సామగ్రి కేటలాగ్' : 'Karimulla Tent House Items Menu'}
          </h2>
          <p className="mt-3 text-base text-neutral-600 dark:text-neutral-300 font-sans">
            {isTelugu 
              ? 'మీ ఈవెంట్‌కు అవసరమైన టెంట్లు, డబ్బాలు, కుర్చీలు మరియు సామగ్రిని ఎంచుకుని నేరుగా కార్ట్‌కి చేర్చండి.'
              : 'Explore rental items below, choose your required sizes or options, and tap "Add to Cart" to build your custom rental order.'}
          </p>
        </motion.div>

        {/* TOP SECTION: Main Items (8 cards in 2 cols mobile, 4 cols desktop) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, delay: 0.15, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="mb-20"
        >
          <div className="flex items-center justify-between mb-6 px-1">
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#38030B] dark:text-white flex items-center gap-2">
              <span>{isTelugu ? 'ముఖ్య సామగ్రి' : 'Main Items'}</span>
              <span className="text-xs font-sans font-medium text-neutral-500 dark:text-neutral-300 bg-amber-100/70 dark:bg-white/10 px-2.5 py-0.5 rounded-full border border-amber-300 dark:border-white/10">
                {visibleItems.length} {isTelugu ? 'రకాలు' : 'Items'}
              </span>
            </h3>
            <span className="text-xs text-neutral-500 dark:text-neutral-400 hidden sm:inline">
              {isTelugu ? 'సైజులు చూసి కార్ట్‌కి చేర్చండి' : 'Select options and click Add to Cart'}
            </span>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {visibleItems.map((item, index) => {
              const isAdded = addedItemKey === item.id;
              const displayImage = item.image || ((item as any).images && (item as any).images[0]) || '';

              return (
                <div
                  key={item.id}
                  className={`group bg-white dark:bg-[#1E0308] rounded-2xl overflow-hidden border border-amber-900/15 dark:border-[#D4AF37]/30 shadow-sm card-premium-hover flex flex-col justify-between reveal-on-scroll stagger-delay-${(index % 8) + 1}`}
                >
                  <div>
                    {/* Image Slot / Container */}
                    <div className="relative h-40 sm:h-48 w-full bg-white dark:bg-white flex flex-col items-center justify-center p-2 text-center overflow-hidden border-b border-amber-900/10 dark:border-white/10">
                      {displayImage ? (
                        <img
                          src={displayImage}
                          alt={`${item.telugu} ${item.english}`}
                          className="w-full h-full object-contain select-none transition-transform duration-300 group-hover:scale-105"
                          loading="lazy"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-amber-900/50 group-hover:text-[#7A1526] transition-colors p-2">
                          <div className="w-12 h-12 rounded-full bg-neutral-100 border border-amber-200 flex items-center justify-center mb-2 shadow-xs group-hover:scale-110 transition-transform">
                            <ImageIcon className="w-6 h-6 text-amber-800/60" />
                          </div>
                          <span className="text-[11px] font-sans font-medium text-neutral-400">
                            Photo Upload Slot
                          </span>
                        </div>
                      )}

                      {/* Sequential Number Tag */}
                      <div className="absolute top-2.5 left-2.5 w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-[#38030B] dark:bg-[#D4AF37] text-[#F3DE8A] dark:text-[#240106] text-xs font-bold font-mono flex items-center justify-center shadow-md">
                        {item.number || index + 1}
                      </div>

                      {item.hasDetails && (
                        <div className="absolute top-2.5 right-2.5 bg-amber-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                          {isTelugu ? 'సైజులు ఉన్నాయి' : 'Sizes Inside'}
                        </div>
                      )}
                    </div>

                    {/* Card Content */}
                    <div className="p-4 sm:p-5 text-center">
                      <h4 className="font-telugu text-lg sm:text-xl font-bold text-[#38030B] dark:text-white group-hover:text-[#7A1526] dark:group-hover:text-[#F3DE8A] transition-colors leading-tight">
                        {item.telugu}
                      </h4>
                      <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 font-sans mt-1 font-medium">
                        {item.english}
                      </p>
                    </div>
                  </div>

                  {/* Card Action - ADD TO CART BUTTON (No Enquiry Button) */}
                  <div className="p-3 sm:p-4 pt-0">
                    {item.hasDetails ? (
                      <button
                        onClick={() => scrollToDetails(item.targetId)}
                        className="btn-premium btn-shine w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#7A1526] to-[#5C0614] hover:from-[#9E1B32] hover:to-[#7A1526] text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer group-hover:shadow-md"
                      >
                        <ShoppingBag className="w-3.5 h-3.5 text-[#F3DE8A]" />
                        <span>{isTelugu ? 'సైజులు & కార్ట్' : 'View Sizes & Add'}</span>
                        <ArrowDown className="w-3.5 h-3.5 group-hover:translate-y-0.5 transition-transform" />
                      </button>
                    ) : (
                      <button
                        onClick={() => handleAddToCart({
                          id: item.id,
                          telugu: item.telugu,
                          english: item.english,
                          category: item.category,
                        })}
                        className={`btn-premium btn-shine w-full py-2.5 px-3 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                          isAdded
                            ? 'bg-emerald-600 text-white shadow-md'
                            : 'bg-gradient-to-r from-[#7A1526] to-[#5C0614] hover:from-[#9E1B32] hover:to-[#7A1526] text-white shadow-xs'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-white" />
                            <span>{isTelugu ? 'కార్ట్‌కి చేర్చబడింది ✓' : 'Added to Cart ✓'}</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5 text-[#F3DE8A]" />
                            <span>{isTelugu ? 'కార్ట్‌కి చేర్చండి' : 'Add to Cart'}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* BOTTOM SECTION: Item Details with Size Chips */}
        <div id="item-details-section" className="pt-6 border-t-2 border-amber-900/15 dark:border-[#D4AF37]/20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="text-center max-w-2xl mx-auto mb-10"
          >
            <span className="text-xs font-bold uppercase tracking-wider text-[#9E1B32] dark:text-[#F3DE8A]">
              {isTelugu ? 'అందుబాటులో ఉన్న సైజులు & కొలతలు' : 'Specifications & Available Sizes'}
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#38030B] dark:text-white mt-1">
              {isTelugu ? 'సైజుల వారీగా కార్ట్‌కి చేర్చండి' : 'Item Details & Direct Size Add to Cart'}
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 mt-1">
              {isTelugu 
                ? 'ఏ సైజునైనా ట్యాప్ చేసి మీ ఆర్డర్ కార్ట్‌కి నేరుగా చేర్చండి.' 
                : 'Select any size below to instantly add it to your rental order cart.'}
            </p>
          </motion.div>

          <div className="space-y-8">
            
            {/* 1) డబ్బాలు (Dabbalu / Drums or Boxes) */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
              id="details-dabbalu"
              className={`p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#1E0308] border shadow-md transition-all duration-300 ${
                activeItem === 'details-dabbalu'
                  ? 'border-[#D4AF37] ring-2 ring-[#D4AF37]/50 shadow-xl'
                  : 'border-amber-900/15 dark:border-[#D4AF37]/30'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-amber-900/10 dark:border-white/10">
                <div className="flex items-center gap-3.5">
                  <img 
                    src="/images/products/11-drums.jpg" 
                    alt="డబ్బాలు Drums" 
                    className="w-14 h-14 rounded-xl object-contain bg-white border border-amber-200 dark:border-white/20 p-1 shadow-sm shrink-0" 
                  />
                  <div>
                    <span className="text-xs font-bold text-[#9E1B32] dark:text-[#F3DE8A] uppercase tracking-wider block">
                      Catering & Storage Vessels
                    </span>
                    <h4 className="font-telugu text-xl sm:text-2xl font-bold text-[#38030B] dark:text-white mt-0.5">
                      1) డబ్బాలు (Dabbalu / Drums or Boxes)
                    </h4>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                      Hygienic stainless steel drums for biryani, cooking, water, and food storage.
                    </p>
                  </div>
                </div>

                <div className="inline-flex items-center gap-1.5 self-start sm:self-center px-3 py-1 rounded-full bg-amber-50 dark:bg-white/10 text-amber-900 dark:text-amber-200 border border-amber-200 dark:border-white/10 text-xs font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-700 dark:text-amber-300" />
                  <span>10 Standard Sizes</span>
                </div>
              </div>

              {/* Sizes Row of Chips with Add to Cart Buttons */}
              <div>
                <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wide block mb-3">
                  {isTelugu ? 'సైజు ఎంచుకుని కార్ట్‌కి చేర్చండి (Add to Cart):' : 'Select Size to Add to Cart:'}
                </span>
                
                <div className="flex flex-wrap gap-2.5 sm:gap-3">
                  {itemsData.itemDetails.dabbalu.sizes.map((sizeObj, idx) => {
                    const itemKey = `dabbalu-${sizeObj.label}`;
                    const isAdded = addedItemKey === itemKey;

                    return (
                      <button
                        key={sizeObj.label}
                        onClick={() => handleAddToCart({
                          id: 'dabbalu',
                          telugu: 'డబ్బాలు',
                          english: `(Dabbalu ${sizeObj.label})`,
                          category: 'Catering & Utensils',
                          selectedSize: sizeObj.label,
                        })}
                        className={`group flex items-center gap-2 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl border transition-all duration-200 cursor-pointer active:scale-95 shadow-xs ${
                          isAdded
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                            : 'bg-gradient-to-r from-amber-50 to-white dark:from-[#26050C] dark:to-[#180206] text-neutral-800 dark:text-white hover:text-white hover:from-[#7A1526] hover:to-[#5C0614] border-amber-900/20 dark:border-[#D4AF37]/30'
                        }`}
                        title={`Add డబ్బాలు ${sizeObj.label} to Cart`}
                      >
                        <span className={`w-5 h-5 rounded-full text-[11px] font-bold flex items-center justify-center font-mono ${
                          isAdded
                            ? 'bg-white/30 text-white'
                            : 'bg-amber-200/80 dark:bg-white/10 group-hover:bg-white/20 text-[#38030B] dark:text-[#F3DE8A]'
                        }`}>
                          {idx + 1}
                        </span>
                        <span className="font-mono font-bold text-sm sm:text-base tabular-nums">
                          {sizeObj.label}
                        </span>
                        {isAdded ? (
                          <Check className="w-3.5 h-3.5 text-white ml-0.5" />
                        ) : (
                          <Plus className="w-3.5 h-3.5 text-[#9E1B32] dark:text-[#F3DE8A] group-hover:text-white ml-0.5" />
                        )}
                        <span className="text-[10px] font-sans font-bold uppercase tracking-wider opacity-80">
                          {isAdded ? 'Added' : 'Add'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </motion.div>

            {/* 2) Tents (Water Proof Tents Available) */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
              id="details-tents"
              className={`p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#1E0308] border shadow-md transition-all duration-300 ${
                activeItem === 'details-tents'
                  ? 'border-[#D4AF37] ring-2 ring-[#D4AF37]/50 shadow-xl'
                  : 'border-amber-900/15 dark:border-[#D4AF37]/30'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-amber-900/10 dark:border-white/10">
                <div className="flex items-center gap-3.5">
                  <img 
                    src="/images/products/05-quilts.jpg" 
                    alt="టెంట్లు Waterproof Tents" 
                    className="w-14 h-14 rounded-xl object-contain bg-white border border-amber-200 dark:border-white/20 p-1 shadow-sm shrink-0" 
                  />
                  <div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-700 text-white text-[11px] font-bold mb-1 shadow-xs">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Water Proof Tents Available</span>
                    </div>

                    <h4 className="font-telugu text-xl sm:text-2xl font-bold text-[#38030B] dark:text-white">
                      2) Tents (Water Proof Tents Available)
                    </h4>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                      Heavy-duty waterproof PVC and shamiana setups suitable for lawns, functions, and rain protection.
                    </p>
                  </div>
                </div>

                <div className="inline-flex items-center gap-1 text-xs text-neutral-600 dark:text-neutral-300 bg-neutral-100 dark:bg-white/10 px-3 py-1.5 rounded-lg border border-neutral-200 dark:border-white/10 self-start sm:self-center">
                  <span>Customizable dimensions on request</span>
                </div>
              </div>

              {/* Tents Sizes Chips with Add to Cart */}
              <div>
                <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wide block mb-3">
                  {isTelugu ? 'టెంట్ సైజు ఎంచుకుని కార్ట్‌కి చేర్చండి:' : 'Available Tent Sizes (Tap to Add to Cart):'}
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  {itemsData.itemDetails.tents.sizes.map((sizeObj) => {
                    const itemKey = `tents-${sizeObj.label}`;
                    const isAdded = addedItemKey === itemKey;

                    return (
                      <button
                        key={sizeObj.label}
                        onClick={() => handleAddToCart({
                          id: 'tents',
                          telugu: 'వాటర్‌ప్రూఫ్ టెంట్లు',
                          english: `(Waterproof Tent ${sizeObj.label} ft)`,
                          category: 'Tents & Canopies',
                          selectedSize: `${sizeObj.label} ft`,
                        })}
                        className={`group p-4 rounded-2xl border transition-all duration-200 flex items-center justify-between cursor-pointer active:scale-98 text-left shadow-xs ${
                          isAdded
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                            : 'bg-gradient-to-br from-amber-50/60 to-white dark:from-[#26050C] dark:to-[#180206] text-neutral-800 dark:text-white hover:from-[#7A1526] hover:to-[#5C0614] hover:text-white border-amber-900/20 dark:border-[#D4AF37]/30 hover:shadow-lg'
                        }`}
                      >
                        <div>
                          <span className={`text-[11px] uppercase tracking-wider font-semibold block ${
                            isAdded ? 'text-emerald-100' : 'text-amber-800 dark:text-[#F3DE8A] group-hover:text-[#F3DE8A]'
                          }`}>
                            Tent Size
                          </span>
                          <span className="font-mono font-extrabold text-lg sm:text-xl text-[#38030B] dark:text-white group-hover:text-white">
                            {sizeObj.label} ft
                          </span>
                        </div>

                        <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                          isAdded
                            ? 'bg-white text-emerald-900'
                            : 'bg-[#7A1526] dark:bg-[#D4AF37] group-hover:bg-[#D4AF37] text-white dark:text-[#240106] group-hover:text-[#240106]'
                        }`}>
                          {isAdded ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>Added</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3.5 h-3.5" />
                              <span>Add to Cart</span>
                            </>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </motion.div>

            {/* Other Items Quick Add to Cart List */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
              className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-stone-50 to-amber-50/50 dark:from-[#1A0206] dark:to-[#120104] border border-amber-900/15 dark:border-[#D4AF37]/30"
            >
              <div className="mb-6">
                <span className="text-xs font-bold text-[#9E1B32] dark:text-[#F3DE8A] uppercase tracking-wider block">
                  Additional Cooking & Event Rentals
                </span>
                <h4 className="font-serif text-xl sm:text-2xl font-bold text-[#38030B] dark:text-white mt-0.5">
                  {isTelugu ? 'గ్యాస్ స్టవ్‌లు, ప్లేట్లు, బెంచీలు & కుర్చీలు కార్ట్‌కి చేర్చండి' : 'Gas Stoves, Plates, Benches, Chairs, Lightings & Fans'}
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {itemsData.itemDetails.otherItems.map((item) => {
                  const isAdded = addedItemKey === item.id;

                  return (
                    <div
                      key={item.id}
                      id={item.id}
                      className="p-4 rounded-xl bg-white dark:bg-[#200408] border border-amber-900/10 dark:border-white/10 shadow-xs flex items-center justify-between gap-3"
                    >
                      <div>
                        <span className="font-telugu font-bold text-sm sm:text-base text-[#38030B] dark:text-white block">
                          {item.title}
                        </span>
                        <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block mt-0.5">
                          {item.badge}
                        </span>
                      </div>

                      <button
                        onClick={() => handleAddToCart({
                          id: item.id,
                          telugu: item.title,
                          english: item.badge,
                          category: 'Event Equipment',
                        })}
                        className={`px-3 py-2 rounded-lg font-semibold text-xs flex items-center gap-1.5 shrink-0 transition-all cursor-pointer ${
                          isAdded
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'bg-gradient-to-r from-[#7A1526] to-[#5C0614] hover:from-[#9E1B32] hover:to-[#7A1526] text-white shadow-xs'
                        }`}
                        title={`Add ${item.title} to Cart`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5 text-[#F3DE8A]" />
                            <span>Add to Cart</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </motion.div>

          </div>

        </div>

      </div>
    </section>
  );
};

export default ItemsMenuSection;
