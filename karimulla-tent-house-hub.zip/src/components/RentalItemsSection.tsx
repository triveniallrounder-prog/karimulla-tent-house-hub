import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  Check, 
  MessageCircle, 
  Sparkles, 
  SlidersHorizontal,
  Info,
  Image as ImageIcon,
  CheckCircle2,
  ShoppingBag
} from 'lucide-react';
import { itemsData } from '../data/items.js';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { BasketItem } from './QuoteBasketDrawer';
import { motion } from 'framer-motion';
import { useSiteData } from '../context/SiteDataContext';

interface RentalItemsSectionProps {
  basketItems: BasketItem[];
  onAddToBasket: (item: any) => void;
  onOpenBasket: () => void;
}

const CATEGORIES = [
  { label: 'All Items (అన్నీ)', value: 'All' },
  { label: 'Catering & Utensils (వంటసామానులు)', value: 'Catering & Utensils' },
  { label: 'Tents & Canopies (వాటర్‌ప్రూఫ్ టెంట్లు)', value: 'Tents & Canopies' },
  { label: 'Seating & Furniture (కుర్చీలు & బెంచీలు)', value: 'Seating & Furniture' },
  { label: 'Lighting & Cooling (లైటింగ్ & కూలింగ్)', value: 'Lighting & Cooling' },
];

export const RentalItemsSection: React.FC<RentalItemsSectionProps> = ({
  basketItems,
  onAddToBasket,
  onOpenBasket,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected sizes state for items with size options (e.g. Dabbalu, Tents)
  const [selectedSizes, setSelectedSizes] = useState<{ [itemId: string]: string }>({
    dabbalu: '50 kgs',
    tents: '30 × 15'
  });

  // Quantities for each item card
  const [itemQuantities, setItemQuantities] = useState<{ [itemId: string]: number }>({
    dabbalu: 1,
    tents: 1,
    'gas-stove': 1,
    'stove-plates': 2,
    benches: 10,
    chairs: 50,
    lightings: 1,
    fans: 4
  });

  const { siteData } = useSiteData();
  const masterItems = useMemo(() => {
    if (siteData && siteData.items && siteData.items.length > 0) {
      return siteData.items.filter((item) => item.visible !== false);
    }
    return itemsData.mainItems;
  }, [siteData]);

  const filteredItems = useMemo(() => {
    return masterItems.filter((item) => {
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = 
        !q ||
        item.telugu.includes(q) ||
        item.english.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.specs && item.specs.toLowerCase().includes(q));
      return matchesCategory && matchesSearch;
    });
  }, [masterItems, selectedCategory, searchQuery]);

  const getItemBasketQty = (itemId: string) => {
    const found = basketItems.find((b) => b.item.id === itemId);
    return found ? found.quantity : 0;
  };

  const handleSelectSize = (itemId: string, sizeLabel: string) => {
    setSelectedSizes((prev) => ({ ...prev, [itemId]: sizeLabel }));
  };

  const handleQtyChange = (itemId: string, delta: number) => {
    setItemQuantities((prev) => {
      const current = prev[itemId] || 1;
      const updated = Math.max(1, current + delta);
      return { ...prev, [itemId]: updated };
    });
  };

  const handleAddRequirement = (item: any) => {
    const size = selectedSizes[item.id] || '';
    const qty = itemQuantities[item.id] || 1;

    const basketItemObj = {
      id: size ? `${item.id}-${size.replace(/\s+/g, '')}` : item.id,
      name: `${item.telugu} ${item.english}`,
      teluguName: item.telugu,
      category: item.category,
      pricePerDay: item.price ? Number(item.price) : 0,
      unit: item.unit || 'per unit / day',
      description: item.description,
      specs: item.specs,
      image: item.image,
      selectedSize: size
    };

    // Call onAddToBasket with quantity
    for (let i = 0; i < qty; i++) {
      onAddToBasket(basketItemObj);
    }
  };

  const handleDirectWhatsApp = (item: any) => {
    const size = selectedSizes[item.id];
    const qty = itemQuantities[item.id] || 1;
    
    let text = `Hello Karimulla Tent House, I need "${item.telugu} ${item.english}"`;
    if (size) {
      text += ` (Size: ${size})`;
    }
    text += ` - Quantity: ${qty}.`;
    text += ` Please share the rental quotation and availability for my event.`;

    window.open(`https://wa.me/${BUSINESS_DETAILS.phoneRaw}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <section id="rental-catalogue" className="py-20 sm:py-24 bg-[#FAF7F2] border-b border-amber-900/10 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="text-center max-w-3xl mx-auto mb-10 sm:mb-12"
        >
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#7A1526]/10 text-[#7A1526] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#9E1B32]" />
            <span className="font-telugu">అద్దె సామాగ్రి మరియు రిక్వైర్‌మెంట్ క్యాటలాగ్</span>
            <span>·</span>
            <span>Requirement Catalogue</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#38030B] tracking-tight">
            Rental Items & Requirement Catalogue
          </h2>
          <p className="mt-3 text-base text-neutral-600 font-sans">
            Select your event rental requirements from our catalog. Same trusted equipment inventory, clean and maintained, delivered directly to your venue in Guntur & surrounding areas.
          </p>
        </motion.div>

        {/* Filter Controls Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.5, delay: 0.1, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="space-y-4 mb-8"
        >
          
          {/* Search + Quick Basket Indicator */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="శోధించండి / Search Dabbalu, Tents, Chairs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-sm rounded-xl bg-white border border-amber-900/15 focus:outline-none focus:ring-2 focus:ring-[#7A1526] focus:border-transparent transition-all shadow-xs"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-neutral-600 cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Quick Basket Summary Button */}
            {basketItems.length > 0 && (
              <button
                onClick={onOpenBasket}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-[#7A1526] bg-amber-100 hover:bg-amber-200 rounded-xl border border-amber-300 transition-colors shadow-xs cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Requirement List: {basketItems.length} items added</span>
                <span className="font-bold underline">Review List →</span>
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat.value;
              return (
                <button
                  key={cat.value}
                  onClick={() => setSelectedCategory(cat.value)}
                  className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-xl whitespace-nowrap transition-all duration-150 cursor-pointer ${
                    isActive
                      ? 'bg-[#7A1526] text-white shadow-md shadow-[#7A1526]/20 font-semibold'
                      : 'bg-white text-neutral-700 hover:bg-amber-50 hover:text-neutral-900 border border-amber-900/10'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

        </motion.div>

        {/* Results Metadata */}
        <div className="flex items-center justify-between text-xs text-neutral-500 mb-6 px-1">
          <span>Showing {filteredItems.length} rental inventory catalogue items</span>
          <span className="font-telugu">అన్ని రకాల ఈవెంట్స్ & ఫంక్షన్లకు లభించును</span>
        </div>

        {/* Catalogue Cards Grid (8 Exact Items) */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-amber-900/10 p-8">
            <SlidersHorizontal className="w-10 h-10 text-neutral-400 mx-auto mb-3" />
            <h3 className="font-serif text-lg font-bold text-neutral-800">No matching items found</h3>
            <p className="text-sm text-neutral-500 mt-1">Try resetting your search query or choosing another category.</p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 text-xs font-semibold text-[#7A1526] bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100 cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {filteredItems.map((item) => {
              const currentBasketQty = getItemBasketQty(item.id);
              const cardQty = itemQuantities[item.id] || 1;
              const chosenSize = selectedSizes[item.id];

              return (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl overflow-hidden border border-amber-900/15 shadow-sm card-premium-hover flex flex-col justify-between group reveal-on-scroll"
                >
                  <div>
                    {/* Photo Upload Container (Picture slot ready for upload) */}
                    <div className="relative h-44 w-full bg-gradient-to-br from-amber-100/70 via-stone-100 to-amber-50 flex flex-col items-center justify-center p-4 text-center overflow-hidden border-b border-amber-900/10">
                      {item.image ? (
                        <img
                          src={item.image}
                          alt={`${item.telugu} ${item.english}`}
                          className="w-full h-full object-cover img-zoom-hover"
                          loading="lazy"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-amber-900/50 group-hover:text-[#7A1526] transition-colors p-2">
                          <div className="w-12 h-12 rounded-full bg-white/80 border border-amber-200 flex items-center justify-center mb-1.5 shadow-xs group-hover:scale-110 transition-transform">
                            <ImageIcon className="w-6 h-6 text-amber-800/60" />
                          </div>
                          <span className="text-[11px] font-sans font-medium text-neutral-400">
                            Photo Upload Slot
                          </span>
                        </div>
                      )}

                      {/* Number Tag */}
                      <div className="absolute top-3 left-3 w-7 h-7 rounded-full bg-[#38030B] text-[#F3DE8A] text-xs font-bold font-mono flex items-center justify-center shadow-md">
                        0{item.number}
                      </div>

                      {/* Category / Badge */}
                      <div className="absolute top-3 right-3 bg-amber-500/90 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
                        {item.badge || item.category}
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-4 sm:p-5">
                      <h3 className="font-telugu text-xl font-bold text-[#38030B] group-hover:text-[#7A1526] transition-colors leading-tight">
                        {item.telugu}
                      </h3>
                      <p className="font-sans text-xs text-amber-950 font-semibold mt-0.5">
                        {item.english}
                      </p>

                      <p className="text-xs text-neutral-600 mt-2 leading-relaxed">
                        {item.description}
                      </p>

                      <div className="mt-2.5 pt-2.5 border-t border-neutral-100 text-[11px] text-neutral-500 flex items-start gap-1">
                        <Info className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                        <span>{item.specs}</span>
                      </div>

                      {/* Interactive Size Chips (For Dabbalu and Tents) */}
                      {item.sizes && item.sizes.length > 0 && (
                        <div className="mt-3.5 pt-3 border-t border-amber-900/10">
                          <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block mb-1.5">
                            Select Size / Capacity:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {item.sizes.map((s: any) => {
                              const isSelected = chosenSize === s.label;
                              return (
                                <button
                                  key={s.label}
                                  onClick={() => handleSelectSize(item.id, s.label)}
                                  className={`text-[11px] px-2 py-0.5 rounded-md font-medium transition-all cursor-pointer ${
                                    isSelected
                                      ? 'bg-[#7A1526] text-white shadow-xs font-bold ring-1 ring-[#7A1526]'
                                      : 'bg-neutral-100 text-neutral-700 hover:bg-amber-100 border border-neutral-200'
                                  }`}
                                >
                                  {s.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                    </div>
                  </div>

                  {/* Card Actions & Requirement Selector */}
                  <div className="p-4 sm:p-5 pt-0 border-t border-amber-900/5 mt-2 space-y-3">
                    
                    {/* Rate Display + Quantity Selector */}
                    <div className="flex items-center justify-between pt-2">
                      <div>
                        <span className="text-[10px] text-neutral-500 block uppercase font-medium">Rate:</span>
                        <span className="text-xs font-semibold text-[#7A1526]">
                          {item.price ? `₹${item.price}` : 'Quote on Request'}
                        </span>
                      </div>

                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-neutral-500 font-medium">Qty:</span>
                        <div className="flex items-center border border-neutral-300 rounded-lg bg-neutral-50">
                          <button
                            onClick={() => handleQtyChange(item.id, -1)}
                            className="w-6 h-6 flex items-center justify-center text-xs font-bold hover:bg-neutral-200 rounded-l transition-colors cursor-pointer"
                            aria-label="Decrease quantity"
                          >
                            -
                          </button>
                          <span className="w-7 text-center text-xs font-mono font-bold">
                            {cardQty}
                          </span>
                          <button
                            onClick={() => handleQtyChange(item.id, 1)}
                            className="w-6 h-6 flex items-center justify-center text-xs font-bold hover:bg-neutral-200 rounded-r transition-colors cursor-pointer"
                            aria-label="Increase quantity"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Action: Add to Cart (No Enquiry button) */}
                    <div className="pt-1">
                      {currentBasketQty > 0 ? (
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => handleAddRequirement(item)}
                            className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1 shadow-xs transition-all active:scale-[0.98] cursor-pointer"
                            title="Add another to Cart"
                          >
                            <Plus className="w-3.5 h-3.5 text-white" />
                            <span>Add More ({currentBasketQty})</span>
                          </button>
                          <button
                            onClick={onOpenBasket}
                            className="py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-semibold text-xs flex items-center justify-center gap-1 shadow-xs transition-all active:scale-[0.98] cursor-pointer"
                            title="Open Cart Drawer"
                          >
                            <ShoppingBag className="w-3.5 h-3.5 text-[#F3DE8A]" />
                            <span>View Cart</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleAddRequirement(item)}
                          className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#7A1526] to-[#5C0614] hover:from-[#9E1B32] hover:to-[#7A1526] text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-[0.98] cursor-pointer hover:shadow-md"
                          title="Add to Event Rental Cart"
                        >
                          <Plus className="w-3.5 h-3.5 text-[#F3DE8A]" />
                          <span>Add to Cart</span>
                        </button>
                      )}
                    </div>

                  </div>

                </div>
              );
            })}
          </motion.div>
        )}

        {/* Bottom Banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="mt-14 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#38030B] via-[#4A040F] to-[#5C0614] text-white flex flex-col md:flex-row items-center justify-between gap-6 border border-[#D4AF37]/30 shadow-xl"
        >
          <div className="space-y-1 text-center md:text-left">
            <span className="text-xs uppercase tracking-widest text-[#E5C158] font-bold">
              Custom Event Packages
            </span>
            <h3 className="font-telugu text-xl sm:text-2xl font-bold text-white">
              పెళ్లిళ్లు, ఫంక్షన్లు, బర్త్‌డేలకు సంపూర్ణ అద్దె సామాగ్రి సెటప్
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-xl font-sans">
              Need complete catering drums, waterproof tents, chiavari chairs, dining benches, high-flame burners, and lighting setup together? Contact Karimulla garu for custom event package quotes.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
            {basketItems.length > 0 && (
              <button
                onClick={onOpenBasket}
                className="w-full sm:w-auto px-5 py-3 rounded-xl bg-white hover:bg-neutral-100 text-[#38030B] font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>View Selected Items ({basketItems.length})</span>
              </button>
            )}

            <a
              href={`https://wa.me/${BUSINESS_DETAILS.phoneRaw}?text=${encodeURIComponent(
                'Hello Karimulla garu, I need a complete event setup quote for tent house rental items in Guntur.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B8860B] hover:from-[#E5C158] hover:to-[#D4AF37] text-[#240106] font-bold text-xs sm:text-sm shadow-md transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>WhatsApp: {BUSINESS_DETAILS.phone1}</span>
            </a>
          </div>
        </motion.div>

      </div>
    </section>
  );
};
