import React from 'react';
import { Award, CheckCircle, Clock, ShieldCheck, HeartHandshake, Phone, MapPin, Star, Crown } from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import germanTentImg from '../assets/images/waterproof_german_tent_1790867016343.jpg';
import { motion } from 'framer-motion';
import { useSiteData } from '../context/SiteDataContext';

export const AboutSection: React.FC = () => {
  const { siteData } = useSiteData();
  const founder = siteData?.founder;
  const settings = siteData?.settings;

  const ownerNameTelugu = founder?.nameTelugu || BUSINESS_DETAILS.ownerTelugu;
  const ownerNameEnglish = founder?.name || BUSINESS_DETAILS.ownerEnglish;
  const ownerTitleTelugu = founder?.titleTelugu || 'వ్యవస్థాపకుడు మరియు యజమాని';
  const ownerTitleEnglish = founder?.title || 'Founder & Proprietor';
  const phone1 = founder?.phone1 || settings?.phone1 || BUSINESS_DETAILS.phone1;
  const phone1Raw = founder?.phone1Raw || settings?.phone1Raw || BUSINESS_DETAILS.phone1Raw;
  const phone2 = founder?.phone2 || settings?.phone2 || BUSINESS_DETAILS.phone2;
  const phone2Raw = founder?.phone2Raw || settings?.phone2Raw || BUSINESS_DETAILS.phone2Raw;
  const yearsExp = founder?.experienceYears || 22;
  return (
    <section id="about" className="py-20 sm:py-24 bg-[#FCF9F5] dark:bg-[#120104] border-b border-amber-950/10 dark:border-[#D4AF37]/20 transition-colors duration-300 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Visual Showcase + Leadership Badge Card (Slide-up & Fade-in) */}
          <motion.div 
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.65, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="lg:col-span-5 space-y-6"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-[#F3DE8A]/30">
              <img
                src={germanTentImg}
                alt="Karimulla Tent House German Pagoda and Shamiana Setup"
                className="w-full h-72 sm:h-80 object-cover brightness-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#38030B]/70 via-[#38030B]/15 to-transparent" />
              
              <div className="absolute bottom-4 left-5 right-5 text-white">
                <span className="text-xs uppercase tracking-widest text-[#E5C158] font-semibold font-telugu">
                  {BUSINESS_DETAILS.addressTelugu}
                </span>
                <p className="font-telugu text-lg sm:text-xl font-bold mt-0.5 text-white">
                  {BUSINESS_DETAILS.nameTelugu}
                </p>
                <p className="text-xs text-neutral-200 mt-0.5 font-telugu">
                  {BUSINESS_DETAILS.taglineTelugu}
                </p>
              </div>
            </div>

            {/* Owner Profile Card (Without photo by default with royal seal, or with photo if admin configured) */}
            <div className="p-5 rounded-2xl bg-white dark:bg-[#1E0308] border border-amber-900/15 dark:border-[#D4AF37]/30 shadow-md card-premium-hover flex items-center gap-4">
              {founder?.photo && founder?.showPhoto ? (
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-[#D4AF37] shadow-lg shrink-0">
                  <img
                    src={founder.photo}
                    alt={ownerNameEnglish}
                    className="w-full h-full object-cover object-top img-zoom-hover"
                  />
                </div>
              ) : (
                /* Prestigious Royal Insignia Crest */
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-[#7A1526] via-[#4A040F] to-[#2D0208] border-2 border-[#D4AF37] shadow-lg shrink-0 flex flex-col items-center justify-center p-2 text-center anim-pulse-glow">
                  <Crown className="w-6 h-6 text-[#F3DE8A]" />
                  <span className="text-[9px] font-bold text-[#F3DE8A] tracking-wider uppercase mt-1 animated-gradient-gold">
                    {yearsExp}+ YRS
                  </span>
                </div>
              )}

              {/* Owner Details */}
              <div className="flex-1">
                <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-[#38030B] text-[#9E1B32] dark:text-[#F3DE8A] text-[10px] font-bold uppercase tracking-wider mb-1">
                  <Award className="w-3 h-3 text-[#D4AF37]" />
                  <span>{ownerTitleEnglish}</span>
                </div>
                <h4 className="font-telugu text-lg sm:text-xl font-bold text-[#38030B] dark:text-white mt-0.5 leading-snug">
                  {ownerNameTelugu}
                </h4>
                <p className="font-sans text-xs text-neutral-600 dark:text-neutral-300 font-medium">
                  {ownerNameEnglish}
                </p>
                <div className="flex flex-wrap items-center gap-2 mt-2 pt-2 border-t border-neutral-100 dark:border-white/10 text-xs">
                  <a
                    href={`tel:+${phone1Raw}`}
                    className="inline-flex items-center gap-1 font-mono font-semibold text-[#7A1526] dark:text-[#F3DE8A] hover:underline"
                  >
                    <Phone className="w-3 h-3 text-[#D4AF37]" />
                    <span>{phone1}</span>
                  </a>
                  {phone2 && (
                    <>
                      <span className="text-neutral-300">·</span>
                      <a
                        href={`tel:+${phone2Raw}`}
                        className="inline-flex items-center gap-1 font-mono font-semibold text-[#7A1526] dark:text-[#F3DE8A] hover:underline"
                      >
                        <Phone className="w-3 h-3 text-[#D4AF37]" />
                        <span>{phone2}</span>
                      </a>
                    </>
                  )}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Editorial & Heritage (Slide-up & Fade-in) */}
          <motion.div 
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.65, delay: 0.15, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="space-y-2">
              <div className="text-xs uppercase font-semibold tracking-wider text-[#9E1B32] dark:text-[#F3DE8A]">
                Our Story & Heritage
              </div>
              <h2 className="font-telugu text-2xl sm:text-3xl lg:text-4xl font-bold text-[#38030B] dark:text-white tracking-tight leading-snug">
                {BUSINESS_DETAILS.ownerTelugu} గారి ఆధ్వర్యంలో 22 ఏళ్ల విశ్వసనీయ సేవలు
              </h2>
              <p className="font-sans text-sm text-neutral-500 dark:text-neutral-400">
                Two Decades of Creating Memorable Celebrations with Royal Hospitality
              </p>
            </div>

            <p className="text-sm sm:text-base text-neutral-700 dark:text-neutral-300 leading-relaxed font-telugu">
              {BUSINESS_DETAILS.taglineTelugu} - వివాహాలు, శుభకార్యాలు, మరియు భారీ ఆధ్యాత్మిక కార్యక్రమాలకు కావాల్సిన వాటర్‌ప్రూఫ్ టెంట్లు, నాణ్యమైన వంట డబ్బాలు, కుర్చీలు మరియు లైటింగ్ సదుపాయాలు మా వద్ద నమ్మకంతో లభించును.
            </p>

            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed font-sans">
              From grand wedding mandaps and heavy stainless steel cooking drums (డబ్బాలు) to waterproof German pagoda canopies, banquet seating, and emergency power lighting—Karimulla Tent House has been the trusted backbone for thousands of auspicious family milestones.
            </p>

            {/* Guarantees Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/60 dark:bg-white/5 border border-amber-900/10 dark:border-white/10">
                <ShieldCheck className="w-5 h-5 text-[#9E1B32] dark:text-[#F3DE8A] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#38030B] dark:text-white">100% All-Weather Rainproof Tents</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-0.5">German hangar-grade multi-layer PVC shamianas keep functions dry during sudden rains.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/60 dark:bg-white/5 border border-amber-900/10 dark:border-white/10">
                <Clock className="w-5 h-5 text-[#9E1B32] dark:text-[#F3DE8A] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#38030B] dark:text-white">Punctual 12-Hour Early Setup</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-0.5">Our dedicated setup crew finishes hours ahead so you have zero stress.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/60 dark:bg-white/5 border border-amber-900/10 dark:border-white/10">
                <CheckCircle className="w-5 h-5 text-[#9E1B32] dark:text-[#F3DE8A] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#38030B] dark:text-white">Spotless Hygiene & Linens</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-0.5">Every chair cover, table frill, and utensil set is sanitized and freshly pressed.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/60 dark:bg-white/5 border border-amber-900/10 dark:border-white/10">
                <HeartHandshake className="w-5 h-5 text-[#9E1B32] dark:text-[#F3DE8A] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#38030B] dark:text-white">Fair & Transparent Rates</h3>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-0.5">Clear per-day rates with no surprise last-minute add-ons or hidden fees.</p>
                </div>
              </div>
            </div>

            {/* Direct Address Banner */}
            <div className="p-4 rounded-xl bg-amber-100/60 dark:bg-[#38030B]/60 border-l-4 border-[#7A1526] text-xs sm:text-sm text-[#38030B] dark:text-neutral-200 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#7A1526] dark:text-[#F3DE8A] shrink-0" />
              <span>
                <strong>చిరునామా:</strong> <span className="font-telugu">{BUSINESS_DETAILS.addressTelugu}</span> ({BUSINESS_DETAILS.addressEnglish})
              </span>
            </div>

            {/* Homepage Section Smooth Scroll Links */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <a
                href="#reviews"
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#7A1526] hover:bg-[#5C0614] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all hover:scale-[1.02]"
              >
                <Star className="w-3.5 h-3.5 text-[#E5C158] fill-[#E5C158]" />
                <span>Customer Ratings & Reviews (4.9★) →</span>
              </a>

              <a
                href="#team"
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white dark:bg-[#1E0308] hover:bg-neutral-50 dark:hover:bg-[#2A050D] text-[#7A1526] dark:text-[#F3DE8A] border border-[#7A1526]/30 dark:border-[#D4AF37]/40 font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all hover:scale-[1.02]"
              >
                <HeartHandshake className="w-3.5 h-3.5 text-[#9E1B32] dark:text-[#E5C158]" />
                <span>Our Team & Partners →</span>
              </a>
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default AboutSection;
