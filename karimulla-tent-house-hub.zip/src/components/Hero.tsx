import React from 'react';
import { MessageCircle, FileText, Sparkles, MapPin, Award, ShieldCheck } from 'lucide-react';
import { BUSINESS_DETAILS } from '../data/rentalData';
import { useLanguage } from '../context/LanguageContext';
import { useSiteData } from '../context/SiteDataContext';
import heroImg from '../assets/images/hero_grand_tent_1790867003430.jpg';
import { motion } from 'framer-motion';

export const Hero: React.FC = () => {
  const { isTelugu } = useLanguage();
  const { siteData } = useSiteData();
  const settings = siteData?.settings;

  const phone1Raw = settings?.phone1Raw || BUSINESS_DETAILS.phone1Raw;
  const bannerImage =
    settings?.heroBannerImage && !settings.heroBannerImage.startsWith('/src/assets/')
      ? settings.heroBannerImage
      : heroImg;
  const addressText = isTelugu 
    ? (settings?.addressTelugu || BUSINESS_DETAILS.addressTelugu)
    : (settings?.addressEnglish || BUSINESS_DETAILS.addressEnglish);
  const siteName = settings?.siteName || BUSINESS_DETAILS.name;
  const siteNameTelugu = settings?.siteNameTelugu || BUSINESS_DETAILS.nameTelugu;
  const taglineTelugu = settings?.taglineTelugu || BUSINESS_DETAILS.taglineTelugu;
  const heroSubheading = settings?.heroSubheading || 'Grand Celebrations, Weddings, Religious Functions & Catering Events Across Guntur';

  const whatsappUrl = `https://wa.me/${phone1Raw}?text=${encodeURIComponent(
    'Hello Karimulla garu, I am planning an event and would like to get a quote for tent and equipment rental.'
  )}`;

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden bg-[#240106] bg-animated-ambient"
    >
      {/* Background Image with Parallax and Scrim */}
      <div className="absolute inset-0 z-0 parallax-layer" data-parallax-speed="0.12">
        <motion.img
          initial={{ scale: 1.15, opacity: 0.85 }}
          animate={{ scale: 1.05, opacity: 1 }}
          transition={{ duration: 1.6, ease: 'easeOut' }}
          src={bannerImage}
          alt="Karimulla Tent House Royal Wedding Tent and Shamiana Setup"
          className="w-full h-full object-cover object-center brightness-110 contrast-[1.03]"
          referrerPolicy="no-referrer"
          loading="eager"
        />
        {/* Layered Scrim Gradients */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#240106]/65 via-[#240106]/45 to-[#38030B]/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#240106]/75 via-transparent to-[#240106]/35" />
      </div>

      {/* Floating Ambient Blurred Orbs (CSS Keyframe Animations) */}
      <div 
        aria-hidden="true" 
        className="absolute top-1/4 left-1/12 w-80 h-80 rounded-full bg-[#D4AF37]/15 blur-3xl pointer-events-none anim-float-1" 
      />
      <div 
        aria-hidden="true" 
        className="absolute bottom-1/4 right-1/12 w-96 h-96 rounded-full bg-[#7A1526]/30 blur-3xl pointer-events-none anim-float-2" 
      />
      <div 
        aria-hidden="true" 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-120 h-120 rounded-full bg-[#E5C158]/10 blur-[100px] pointer-events-none anim-pulse-glow" 
      />

      {/* Decorative Traditional Floral Border Overlay */}
      <div 
        aria-hidden="true" 
        className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-[#B8860B] via-[#F3DE8A] to-[#B8860B] z-10 opacity-70"
      />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center my-auto">
        
        {/* Editorial Sub-kicker */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#F3DE8A] text-xs sm:text-sm font-medium tracking-wide mb-6 backdrop-blur-md shadow-lg"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#E5C158] animate-pulse" />
          <span className={isTelugu ? 'font-telugu' : 'font-sans'}>
            {addressText}
          </span>
        </motion.div>

        {/* Main Business Name with Word-by-Word Reveal & Animated Gradient Text */}
        <div className="mb-4">
          {isTelugu ? (
            <>
              <h1 className="font-telugu text-3xl sm:text-5xl md:text-6xl font-extrabold text-[#F3DE8A] block drop-shadow-md tracking-tight leading-tight">
                {siteNameTelugu.split(' ').map((word, idx) => (
                  <span
                    key={idx}
                    className="word-reveal-item mr-2.5 last:mr-0 animated-gradient-gold"
                    style={{ animationDelay: `${0.15 + idx * 0.1}s` }}
                  >
                    {word}
                  </span>
                ))}
              </h1>
              <span className="font-serif text-lg sm:text-2xl text-white/90 font-medium block mt-1.5 opacity-90">
                ({siteName})
              </span>
            </>
          ) : (
            <>
              <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl font-extrabold text-[#F3DE8A] block drop-shadow-md tracking-tight leading-tight">
                {siteName.split(' ').map((word, idx) => (
                  <span
                    key={idx}
                    className="word-reveal-item mr-2.5 last:mr-0 animated-gradient-gold"
                    style={{ animationDelay: `${0.15 + idx * 0.1}s` }}
                  >
                    {word}
                  </span>
                ))}
              </h1>
              <span className="font-sans text-sm sm:text-base text-neutral-300 font-medium block mt-1.5">
                Premier Tent House & Event Equipment Rentals · Guntur
              </span>
            </>
          )}
        </div>

        {/* Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="max-w-3xl mx-auto mb-8 sm:mb-10"
        >
          <p className="font-telugu text-lg sm:text-2xl md:text-3xl font-semibold text-white leading-relaxed text-balance bg-gradient-to-r from-white via-[#FDFBF3] to-amber-100 bg-clip-text drop-shadow-xs">
            &ldquo;{taglineTelugu}&rdquo;
          </p>
          <p className="text-xs sm:text-sm text-neutral-300 font-sans mt-2 tracking-wide">
            {heroSubheading}
          </p>
        </motion.div>

        {/* Primary Call to Action Buttons with Lift, Shine Sweep, and Gold Glow */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.55, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto mb-10"
        >
          <a
            href="#contact"
            className="btn-premium btn-shine btn-gold-glow w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-[#D4AF37] via-[#E5C158] to-[#B8860B] text-[#240106] font-bold text-sm sm:text-base shadow-xl border border-[#F3DE8A]/40 flex items-center justify-center gap-2 cursor-pointer"
          >
            <FileText className="w-4 h-4 text-[#240106]" />
            <span>{isTelugu ? 'కోటేషన్ పొందండి' : 'Get a Quote'}</span>
          </a>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-premium btn-shine w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-sm sm:text-base shadow-xl shadow-emerald-950/40 hover:shadow-emerald-500/30 border border-emerald-400/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 fill-current" />
            <span>{isTelugu ? 'వాట్సాప్ చేయండి' : 'WhatsApp Us'}</span>
          </a>
        </motion.div>

        {/* Trust Badges Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="pt-8 border-t border-white/10 grid grid-cols-2 md:grid-cols-4 gap-4 text-neutral-300 text-xs sm:text-sm"
        >
          <div className="flex items-center justify-center gap-2">
            <Award className="w-4 h-4 text-[#F3DE8A] shrink-0" />
            <span>22+ {isTelugu ? 'ఏళ్ల అనుభవం' : 'Years Heritage'}</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#F3DE8A] shrink-0" />
            <span>{isTelugu ? 'వాటర్‌ప్రూఫ్ టెంట్లు' : 'Waterproof Tents'}</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <MapPin className="w-4 h-4 text-[#F3DE8A] shrink-0" />
            <span>{isTelugu ? 'గుంటూరు అంతటా డెలివరీ' : 'Guntur City & Districts'}</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4 text-[#F3DE8A] shrink-0" />
            <span>3,850+ {isTelugu ? 'ఈవెంట్లు పూర్తి' : 'Events Done'}</span>
          </div>
        </motion.div>

      </div>
    </section>
  );
};

export default Hero;
