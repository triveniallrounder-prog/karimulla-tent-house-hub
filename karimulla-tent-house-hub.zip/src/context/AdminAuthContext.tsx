import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';

interface AuthResponse {
  success: boolean;
  error?: string;
  remainingSeconds?: number;
}

interface AdminAuthContextType {
  isAuthenticated: boolean;
  adminUser: string | null;
  adminToken: string | null;
  sessionExpiresIn: number; // in seconds
  isLockedOut: boolean;
  lockoutRemainingSeconds: number;
  needsSetup: boolean;
  configuredViaEnv: boolean;
  isStatusLoading: boolean;
  checkAuthStatus: () => Promise<void>;
  setupOwner: (username: string, password: string) => Promise<AuthResponse>;
  login: (user: string, pass: string) => Promise<AuthResponse>;
  changePassword: (currentPassword: string, newUsername: string, newPassword: string) => Promise<AuthResponse>;
  logout: () => Promise<void>;
  extendSession: () => Promise<void>;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Strictly in-memory session token (never stored in localStorage or sessionStorage)
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [adminUser, setAdminUser] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [sessionExpiresIn, setSessionExpiresIn] = useState<number>(30 * 60);
  const [isLockedOut, setIsLockedOut] = useState<boolean>(false);
  const [lockoutRemainingSeconds, setLockoutRemainingSeconds] = useState<number>(0);
  const [needsSetup, setNeedsSetup] = useState<boolean>(false);
  const [configuredViaEnv, setConfiguredViaEnv] = useState<boolean>(false);
  const [isStatusLoading, setIsStatusLoading] = useState<boolean>(false);

  const countdownIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Clean up any legacy browser-stored tokens on mount
  useEffect(() => {
    try {
      localStorage.removeItem('karimulla_admin_token');
      localStorage.removeItem('karimulla_admin_username');
      sessionStorage.removeItem('karimulla_admin_token');
      sessionStorage.removeItem('karimulla_admin_username');
    } catch {
      // ignore storage restrictions
    }
  }, []);

  // Only called when the hidden /admin route is visited
  const checkAuthStatus = useCallback(async () => {
    setIsStatusLoading(true);
    try {
      const res = await fetch('/api/auth/status');
      if (res.ok) {
        const data = await res.json();
        setNeedsSetup(Boolean(data.needsSetup));
        setConfiguredViaEnv(Boolean(data.configuredViaEnv));
      }
    } catch {
      // ignore network error
    } finally {
      setIsStatusLoading(false);
    }
  }, []);

  // Logout handler
  const logout = useCallback(async () => {
    if (adminToken) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${adminToken}` },
        });
      } catch {
        // ignore network error during logout
      }
    }
    setAdminToken(null);
    setAdminUser(null);
    setIsAuthenticated(false);
    setSessionExpiresIn(30 * 60);
  }, [adminToken]);

  // Session auto-logout countdown (30 minutes of inactivity)
  useEffect(() => {
    if (!isAuthenticated) return;

    countdownIntervalRef.current = setInterval(() => {
      setSessionExpiresIn((prev) => {
        if (prev <= 1) {
          if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
          logout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, [isAuthenticated, logout]);

  // Lockout countdown timer
  useEffect(() => {
    if (!isLockedOut || lockoutRemainingSeconds <= 0) return;

    const timer = setInterval(() => {
      setLockoutRemainingSeconds((prev) => {
        if (prev <= 1) {
          setIsLockedOut(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isLockedOut, lockoutRemainingSeconds]);

  // Extend / Refresh session on server
  const extendSession = useCallback(async () => {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${adminToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSessionExpiresIn(data.expiresInSeconds || 30 * 60);
        setConfiguredViaEnv(Boolean(data.configuredViaEnv));
      } else if (res.status === 401) {
        await logout();
      }
    } catch {
      // Keep server as source of truth
    }
  }, [adminToken, logout]);

  // One-time First-Run Owner Setup
  const setupOwner = async (usernameInput: string, passwordInput: string): Promise<AuthResponse> => {
    try {
      const res = await fetch('/api/auth/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: usernameInput, password: passwordInput }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setAdminToken(data.token);
        setAdminUser(data.username);
        setIsAuthenticated(true);
        setNeedsSetup(false);
        setSessionExpiresIn(data.expiresInSeconds || 30 * 60);
        return { success: true };
      }

      if (res.status === 403) {
        setNeedsSetup(false);
      }
      return { success: false, error: data.error || 'Failed to complete owner setup.' };
    } catch {
      return { success: false, error: 'Could not reach authentication server.' };
    }
  };

  // Owner Sign In
  const login = async (usernameInput: string, passwordInput: string): Promise<AuthResponse> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: usernameInput, password: passwordInput }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setAdminToken(data.token);
        setAdminUser(data.username);
        setIsAuthenticated(true);
        setSessionExpiresIn(data.expiresInSeconds || 30 * 60);
        setIsLockedOut(false);
        setLockoutRemainingSeconds(0);
        return { success: true };
      }

      if (res.status === 409) {
        setNeedsSetup(true);
      }

      if (res.status === 429) {
        setIsLockedOut(true);
        setLockoutRemainingSeconds(data.remainingSeconds || 900);
        return { success: false, error: data.error, remainingSeconds: data.remainingSeconds };
      }

      return { success: false, error: data.error || 'Authentication failed. Please check owner credentials.' };
    } catch {
      return { success: false, error: 'Could not connect to authentication server.' };
    }
  };

  // Change Owner Password
  const changePassword = async (
    currentPassword: string,
    newUsername: string,
    newPassword: string
  ): Promise<AuthResponse> => {
    if (!adminToken) {
      return { success: false, error: 'Active owner session required.' };
    }
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ currentPassword, newUsername, newPassword }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        if (data.username) setAdminUser(data.username);
        return { success: true };
      }
      return { success: false, error: data.error || 'Could not update owner credentials.' };
    } catch {
      return { success: false, error: 'Failed to communicate with server.' };
    }
  };

  return (
    <AdminAuthContext.Provider
      value={{
        isAuthenticated,
        adminUser,
        adminToken,
        sessionExpiresIn,
        isLockedOut,
        lockoutRemainingSeconds,
        needsSetup,
        configuredViaEnv,
        isStatusLoading,
        checkAuthStatus,
        setupOwner,
        login,
        changePassword,
        logout,
        extendSession,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
};

export const useAdminAuth = (): AdminAuthContextType => {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
};
