import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  DEFAULT_SITE_DATA, 
  SiteData, 
  ProductItem, 
  FounderData, 
  Teammate, 
  Partner, 
  PartnershipData, 
  WebsiteSettings 
} from '../data/defaultSiteData';
import { useAdminAuth } from './AdminAuthContext';

interface SiteDataContextType {
  siteData: SiteData;
  isLoading: boolean;
  refreshData: () => Promise<void>;
  updateSiteData: (patch: Partial<SiteData>) => Promise<{ success: boolean; error?: string }>;
  updateItems: (items: ProductItem[]) => Promise<{ success: boolean; error?: string }>;
  updateFounder: (founder: FounderData) => Promise<{ success: boolean; error?: string }>;
  updateTeam: (team: Teammate[]) => Promise<{ success: boolean; error?: string }>;
  updatePartners: (partners: Partner[]) => Promise<{ success: boolean; error?: string }>;
  updatePartnership: (partnership: PartnershipData) => Promise<{ success: boolean; error?: string }>;
  updateSettings: (settings: WebsiteSettings) => Promise<{ success: boolean; error?: string }>;
  importBackup: (backupData: SiteData) => Promise<{ success: boolean; error?: string }>;
  resetToDefaults: () => Promise<{ success: boolean; error?: string }>;
}

const SiteDataContext = createContext<SiteDataContextType | undefined>(undefined);

const LOCAL_STORAGE_DATA_KEY = 'karimulla_live_site_data';

export const SiteDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { adminToken } = useAdminAuth();

  // Initialize with saved local state or default seed for zero-flash load
  const [siteData, setSiteData] = useState<SiteData>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_DATA_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.items && parsed.founder && parsed.settings) {
          // If cached items do not have images or have outdated length, prefer fresh defaults
          if (!parsed.items[0]?.image || parsed.items.length < DEFAULT_SITE_DATA.items.length) {
            localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(DEFAULT_SITE_DATA));
            return DEFAULT_SITE_DATA;
          }
          return parsed;
        }
      }
    } catch {
      // ignore
    }
    return DEFAULT_SITE_DATA;
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Fetch latest data from server
  const refreshData = useCallback(async () => {
    try {
      const res = await fetch('/api/public/data');
      if (res.ok) {
        const data = await res.json();
        if (data && data.items) {
          setSiteData(data);
          try {
            localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(data));
          } catch {
            // ignore
          }
        }
      }
    } catch (err) {
      console.warn('Could not fetch server data, utilizing cached/default data:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Save changes to server and commit verified state
  const updateSiteData = async (patch: Partial<SiteData>): Promise<{ success: boolean; error?: string }> => {
    if (!adminToken) {
      return { success: false, error: 'Owner authentication required.' };
    }

    const nextData: SiteData = {
      ...siteData,
      ...patch,
      lastUpdated: new Date().toISOString()
    };

    try {
      const res = await fetch('/api/admin/data', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify(nextData)
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        return { success: false, error: errData.error || 'Server rejected changes.' };
      }

      const resData = await res.json();
      const committed = resData.data || nextData;
      setSiteData(committed);
      try {
        localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(committed));
      } catch {
        // storage quota fallback
      }
      return { success: true };
    } catch {
      return { success: false, error: 'Could not reach server. Changes were not saved.' };
    }
  };

  const updateItems = (items: ProductItem[]) => updateSiteData({ items });
  const updateFounder = (founder: FounderData) => updateSiteData({ founder });
  const updateTeam = (team: Teammate[]) => updateSiteData({ team });
  const updatePartners = (partners: Partner[]) => updateSiteData({ partners });
  const updatePartnership = (partnership: PartnershipData) => updateSiteData({ partnership });
  const updateSettings = (settings: WebsiteSettings) => updateSiteData({ settings });

  const importBackup = async (backupData: SiteData): Promise<{ success: boolean; error?: string }> => {
    if (!adminToken) {
      return { success: false, error: 'Owner authentication required.' };
    }
    try {
      const res = await fetch('/api/admin/backup/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`
        },
        body: JSON.stringify({ backup: backupData })
      });

      if (res.ok) {
        const data = await res.json();
        const committed = data.data || backupData;
        setSiteData(committed);
        try {
          localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(committed));
        } catch {
          // ignore
        }
        return { success: true };
      } else {
        const err = await res.json().catch(() => ({}));
        return { success: false, error: err.error || 'Failed to import backup.' };
      }
    } catch {
      return { success: false, error: 'Could not reach server to restore backup.' };
    }
  };

  const resetToDefaults = async (): Promise<{ success: boolean; error?: string }> => {
    if (!adminToken) {
      return { success: false, error: 'Owner authentication required.' };
    }
    try {
      const res = await fetch('/api/admin/reset', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      });

      if (res.ok) {
        setSiteData(DEFAULT_SITE_DATA);
        try {
          localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(DEFAULT_SITE_DATA));
        } catch {
          // ignore
        }
        return { success: true };
      }
      const err = await res.json().catch(() => ({}));
      return { success: false, error: err.error || 'Server reset failed.' };
    } catch {
      return { success: false, error: 'Could not reach server to reset data.' };
    }
  };

  return (
    <SiteDataContext.Provider
      value={{
        siteData,
        isLoading,
        refreshData,
        updateSiteData,
        updateItems,
        updateFounder,
        updateTeam,
        updatePartners,
        updatePartnership,
        updateSettings,
        importBackup,
        resetToDefaults
      }}
    >
      {children}
    </SiteDataContext.Provider>
  );
};

export const useSiteData = (): SiteDataContextType => {
  const context = useContext(SiteDataContext);
  if (!context) {
    throw new Error('useSiteData must be used within a SiteDataProvider');
  }
  return context;
};
