import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { DEFAULT_SITE_DATA } from './src/data/defaultSiteData.ts';
import type { SiteData } from './src/data/defaultSiteData.ts';

// Load environment variables (server-side only)
dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Body parser with generous limit for compressed base64 image uploads
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

// -------------------------------------------------------------
// 1. Storage & Persistence Setup
// -------------------------------------------------------------
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'site-data.json');
const AUTH_FILE = path.join(DATA_DIR, 'admin-auth.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface StoredOwnerAuth {
  username: string;
  passwordHash: string;
  createdAt: string;
  updatedAt: string;
}

function loadSiteData(): SiteData {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && parsed.items && parsed.founder && parsed.settings) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading site data file, falling back to default:', err);
  }
  saveSiteData(DEFAULT_SITE_DATA);
  return DEFAULT_SITE_DATA;
}

function saveSiteData(data: SiteData): void {
  try {
    data.lastUpdated = new Date().toISOString();
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write site-data.json:', err);
    throw new Error('Failed to save data to storage.');
  }
}

function loadOwnerAuth(): StoredOwnerAuth | null {
  try {
    if (fs.existsSync(AUTH_FILE)) {
      const raw = fs.readFileSync(AUTH_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.username === 'string' && typeof parsed.passwordHash === 'string') {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading owner auth store:', err);
  }
  return null;
}

function saveOwnerAuth(auth: StoredOwnerAuth): void {
  fs.writeFileSync(AUTH_FILE, JSON.stringify(auth, null, 2), { encoding: 'utf-8', mode: 0o600 });
}

// -------------------------------------------------------------
// 2. Owner-Only Authentication, Lockout & Security
// -------------------------------------------------------------
// Priority:
// 1. Server environment secrets (process.env.ADMIN_PASSWORD) — overrides claimed file if set.
// 2. Claimed owner credential hash stored in data/admin-auth.json (salted bcrypt, 12 rounds).
// 3. If neither exists, /admin enters one-time Owner Setup mode until claimed.

let cachedEnvPassSource = '';
let cachedEnvPassHash = '';

function getEnvPasswordHash(): string | null {
  const envPass = process.env.ADMIN_PASSWORD?.trim();
  if (!envPass) return null;
  if (envPass !== cachedEnvPassSource) {
    cachedEnvPassSource = envPass;
    // Support either an already-hashed bcrypt string or plaintext secret in server env
    cachedEnvPassHash = envPass.startsWith('$2') ? envPass : bcrypt.hashSync(envPass, 12);
  }
  return cachedEnvPassHash;
}

function isConfiguredViaEnv(): boolean {
  return Boolean(process.env.ADMIN_PASSWORD?.trim());
}

function isOwnerConfigured(): boolean {
  return isConfiguredViaEnv() || loadOwnerAuth() !== null;
}

function verifyOwnerCredentials(inputUser: string, inputPassword: string): boolean {
  if (typeof inputUser !== 'string' || typeof inputPassword !== 'string') return false;
  const cleanUser = inputUser.trim().toLowerCase();
  if (!cleanUser || !inputPassword) return false;

  const envHash = getEnvPasswordHash();
  if (envHash) {
    const envUser = (process.env.ADMIN_USERNAME || 'owner').trim().toLowerCase();
    // Constant-time-safe user check + bcrypt password verification
    if (cleanUser !== envUser) return false;
    try {
      return bcrypt.compareSync(inputPassword, envHash);
    } catch {
      return false;
    }
  }

  const stored = loadOwnerAuth();
  if (!stored) return false;

  if (cleanUser !== stored.username.trim().toLowerCase()) return false;
  try {
    return bcrypt.compareSync(inputPassword, stored.passwordHash);
  } catch {
    return false;
  }
}

// URL validation to block unsafe schemes (javascript:, data:text/html, etc.)
function isSafeUrl(url: unknown, allowImageDataUri = false): boolean {
  if (typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (!trimmed) return true; // empty optional field
  if (trimmed.startsWith('/')) return !trimmed.startsWith('//');
  if (allowImageDataUri && /^data:image\/(png|jpe?g|webp|gif);base64,[a-zA-Z0-9+/=]+$/i.test(trimmed)) {
    return true;
  }
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

function sanitizeIncomingSiteData(data: any): SiteData {
  if (data.founder?.socialLinks) {
    const sl = data.founder.socialLinks;
    if (!isSafeUrl(sl.instagram)) sl.instagram = '';
    if (!isSafeUrl(sl.facebook)) sl.facebook = '';
  }
  if (data.founder?.photo && !isSafeUrl(data.founder.photo, true)) {
    data.founder.photo = '';
  }
  if (Array.isArray(data.items)) {
    data.items = data.items.map((item: any) => ({
      ...item,
      image: isSafeUrl(item.image, true) ? item.image : '',
      images: Array.isArray(item.images) ? item.images.filter((img: unknown) => isSafeUrl(img, true)) : [],
    }));
  }
  if (Array.isArray(data.team)) {
    data.team = data.team.map((member: any) => ({
      ...member,
      photo: isSafeUrl(member.photo, true) ? member.photo : '',
    }));
  }
  if (Array.isArray(data.partners)) {
    data.partners = data.partners.map((partner: any) => ({
      ...partner,
      photo: isSafeUrl(partner.photo, true) ? partner.photo : '',
      website: isSafeUrl(partner.website) ? partner.website : '',
    }));
  }
  if (data.settings?.heroBannerImage && !isSafeUrl(data.settings.heroBannerImage, true)) {
    data.settings.heroBannerImage = '';
  }
  return data as SiteData;
}

// In-memory brute-force lockout tracking
interface AttemptInfo {
  count: number;
  lastAttempt: number;
  lockedUntil?: number;
}
const loginAttempts = new Map<string, AttemptInfo>();
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes lockout

// In-memory session store: token -> { username, expiresAt, createdAt }
interface SessionData {
  username: string;
  expiresAt: number;
  createdAt: number;
}
const activeSessions = new Map<string, SessionData>();
const SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes auto-logout

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') return forwarded.split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}

// Apply strict no-index and no-cache headers on admin routes and auth APIs
function noIndexSecurityHeaders(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive, nosnippet');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
}

app.use(['/admin', '/admin/*', '/api/auth', '/api/auth/*', '/api/admin', '/api/admin/*'], noIndexSecurityHeaders);

// Auth middleware enforcing valid Bearer token & 30-min inactivity expiry
function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization'] || req.headers['x-admin-token'];
  let token = '';

  if (typeof authHeader === 'string') {
    if (authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7).trim();
    } else {
      token = authHeader.trim();
    }
  }

  if (!token) {
    res.status(401).json({ error: 'Access denied. Owner authentication required.' });
    return;
  }

  const session = activeSessions.get(token);
  if (!session) {
    res.status(401).json({ error: 'Invalid or expired session. Please sign in again.' });
    return;
  }

  const now = Date.now();
  if (now > session.expiresAt) {
    activeSessions.delete(token);
    res.status(401).json({ error: 'Session expired after 30 minutes of inactivity. Please sign in again.' });
    return;
  }

  // Slide 30-minute expiration window on activity
  session.expiresAt = now + SESSION_TIMEOUT_MS;
  (req as any).adminSession = session;
  next();
}

// -------------------------------------------------------------
// 3. API Routes
// -------------------------------------------------------------

// Public: Get live website data (zero admin info exposed)
app.get('/api/public/data', (_req: Request, res: Response) => {
  try {
    const data = loadSiteData();
    res.json(data);
  } catch {
    res.status(500).json({ error: 'Failed to retrieve site data.' });
  }
});

// Auth: Check if owner account needs first-run setup (returns only safe booleans)
app.get('/api/auth/status', (_req: Request, res: Response) => {
  res.json({
    needsSetup: !isOwnerConfigured(),
    configuredViaEnv: isConfiguredViaEnv(),
  });
});

// Auth: One-time first-run Owner Claim / Setup (locks automatically once claimed or env configured)
app.post('/api/auth/setup', (req: Request, res: Response) => {
  if (isOwnerConfigured()) {
    res.status(403).json({ error: 'Owner account is already configured. Please sign in instead.' });
    return;
  }

  const { username, password } = req.body || {};
  const cleanUser = typeof username === 'string' ? username.trim() : '';
  const cleanPass = typeof password === 'string' ? password : '';

  if (cleanUser.length < 3 || cleanUser.length > 40) {
    res.status(400).json({ error: 'Owner username must be between 3 and 40 characters.' });
    return;
  }
  if (cleanPass.length < 8 || cleanPass.length > 128) {
    res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    return;
  }

  const nowIso = new Date().toISOString();
  const passwordHash = bcrypt.hashSync(cleanPass, 12);

  saveOwnerAuth({
    username: cleanUser,
    passwordHash,
    createdAt: nowIso,
    updatedAt: nowIso,
  });

  // Automatically start an authenticated owner session
  const now = Date.now();
  const token = crypto.randomBytes(32).toString('hex');
  activeSessions.set(token, {
    username: cleanUser,
    expiresAt: now + SESSION_TIMEOUT_MS,
    createdAt: now,
  });

  res.status(201).json({
    success: true,
    token,
    username: cleanUser,
    expiresInSeconds: Math.floor(SESSION_TIMEOUT_MS / 1000),
  });
});

// Auth: Owner Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  if (!isOwnerConfigured()) {
    res.status(409).json({ error: 'Owner credentials have not been set up yet. Complete first-time setup.' });
    return;
  }

  const { username, password } = req.body || {};
  const ip = getClientIp(req);
  const now = Date.now();

  // Check lockout
  const attempt = loginAttempts.get(ip) || { count: 0, lastAttempt: now };
  if (attempt.lockedUntil && now < attempt.lockedUntil) {
    const remainingSeconds = Math.ceil((attempt.lockedUntil - now) / 1000);
    res.status(429).json({
      error: `Too many failed login attempts. Locked for security. Try again in ${remainingSeconds} seconds.`,
      remainingSeconds,
    });
    return;
  }

  const valid = verifyOwnerCredentials(username, password);

  if (!valid) {
    attempt.count += 1;
    attempt.lastAttempt = now;

    if (attempt.count >= MAX_ATTEMPTS) {
      attempt.lockedUntil = now + LOCKOUT_MS;
      loginAttempts.set(ip, attempt);
      res.status(429).json({
        error: 'Too many incorrect attempts (5/5). Access locked for 15 minutes.',
        remainingSeconds: 15 * 60,
      });
      return;
    }

    loginAttempts.set(ip, attempt);
    const attemptsLeft = MAX_ATTEMPTS - attempt.count;
    res.status(401).json({
      error: `Invalid owner username or password. (${attemptsLeft} attempt${attemptsLeft === 1 ? '' : 's'} remaining before lockout)`,
    });
    return;
  }

  loginAttempts.delete(ip);

  const token = crypto.randomBytes(32).toString('hex');
  const stored = loadOwnerAuth();
  const sessionUser = isConfiguredViaEnv()
    ? (process.env.ADMIN_USERNAME || 'owner').trim()
    : (stored?.username || String(username).trim());

  activeSessions.set(token, {
    username: sessionUser,
    expiresAt: now + SESSION_TIMEOUT_MS,
    createdAt: now,
  });

  res.json({
    success: true,
    token,
    username: sessionUser,
    expiresInSeconds: Math.floor(SESSION_TIMEOUT_MS / 1000),
  });
});

// Auth: Change Owner Password (requires active owner session)
app.post('/api/auth/change-password', requireAdmin, (req: Request, res: Response) => {
  if (isConfiguredViaEnv()) {
    res.status(400).json({
      error: 'Password is managed via server environment secrets (ADMIN_PASSWORD). Update it in your environment configuration.',
    });
    return;
  }

  const stored = loadOwnerAuth();
  if (!stored) {
    res.status(400).json({ error: 'Owner account record not found.' });
    return;
  }

  const { currentPassword, newUsername, newPassword } = req.body || {};
  if (typeof currentPassword !== 'string' || !bcrypt.compareSync(currentPassword, stored.passwordHash)) {
    res.status(401).json({ error: 'Current password is incorrect.' });
    return;
  }

  const cleanPass = typeof newPassword === 'string' ? newPassword : '';
  if (cleanPass.length < 8 || cleanPass.length > 128) {
    res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    return;
  }

  const nextUser = typeof newUsername === 'string' && newUsername.trim().length >= 3
    ? newUsername.trim()
    : stored.username;

  saveOwnerAuth({
    username: nextUser,
    passwordHash: bcrypt.hashSync(cleanPass, 12),
    createdAt: stored.createdAt,
    updatedAt: new Date().toISOString(),
  });

  // Update active session username
  const session = (req as any).adminSession as SessionData;
  session.username = nextUser;

  res.json({
    success: true,
    username: nextUser,
    message: 'Owner credentials updated and securely hashed.',
  });
});

// Auth: Validate session / Me
app.get('/api/auth/me', requireAdmin, (req: Request, res: Response) => {
  const session = (req as any).adminSession;
  const remainingSeconds = Math.max(0, Math.floor((session.expiresAt - Date.now()) / 1000));
  res.json({
    authenticated: true,
    username: session.username,
    expiresInSeconds: remainingSeconds,
    configuredViaEnv: isConfiguredViaEnv(),
  });
});

// Auth: Logout
app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers['authorization'] || req.headers['x-admin-token'];
  if (typeof authHeader === 'string') {
    const token = authHeader.replace('Bearer ', '').trim();
    activeSessions.delete(token);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// Admin: Get current data
app.get('/api/admin/data', requireAdmin, (_req: Request, res: Response) => {
  try {
    const data = loadSiteData();
    res.json(data);
  } catch {
    res.status(500).json({ error: 'Failed to read data.' });
  }
});

// Admin: Update complete site data or section
app.put('/api/admin/data', requireAdmin, (req: Request, res: Response) => {
  try {
    const incomingData = req.body;
    if (!incomingData || typeof incomingData !== 'object') {
      res.status(400).json({ error: 'Invalid data payload provided.' });
      return;
    }

    const current = loadSiteData();
    const sanitized = sanitizeIncomingSiteData({
      ...current,
      ...incomingData,
      lastUpdated: new Date().toISOString(),
    });

    saveSiteData(sanitized);
    res.json({ success: true, message: 'Changes saved successfully and are now live!', data: sanitized });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to save changes.' });
  }
});

// Admin: Export backup
app.get('/api/admin/backup/export', requireAdmin, (_req: Request, res: Response) => {
  try {
    const data = loadSiteData();
    const filename = `karimulla-tent-house-backup-${new Date().toISOString().split('T')[0]}.json`;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(JSON.stringify(data, null, 2));
  } catch {
    res.status(500).json({ error: 'Failed to export backup.' });
  }
});

// Admin: Import backup
app.post('/api/admin/backup/import', requireAdmin, (req: Request, res: Response) => {
  try {
    const { backup } = req.body || {};
    if (!backup || !backup.items || !backup.settings) {
      res.status(400).json({ error: 'Invalid backup file structure. Missing items or settings.' });
      return;
    }

    const sanitized = sanitizeIncomingSiteData(backup);
    saveSiteData(sanitized);
    res.json({ success: true, message: 'Backup imported and applied successfully!', data: sanitized });
  } catch {
    res.status(500).json({ error: 'Failed to import backup.' });
  }
});

// Admin: Reset to default seed
app.post('/api/admin/reset', requireAdmin, (_req: Request, res: Response) => {
  try {
    saveSiteData(DEFAULT_SITE_DATA);
    res.json({ success: true, message: 'Site data successfully restored to factory defaults.', data: DEFAULT_SITE_DATA });
  } catch {
    res.status(500).json({ error: 'Failed to reset site data.' });
  }
});

// -------------------------------------------------------------
// 4. Vite Dev Server / Production Static Serving
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
